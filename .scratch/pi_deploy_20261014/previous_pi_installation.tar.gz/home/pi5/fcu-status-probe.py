import asyncio,json,time
from aiohttp import ClientSession
async def main():
 async with ClientSession() as s:
  state=await (await s.get('http://127.0.0.1:8899/api/state')).json()
  if state['runtime']=='Stopped':
   r=await s.post('http://127.0.0.1:8899/api/connect',json={'profile_id':'router-udp'});print('connect',r.status)
  async with s.ws_connect('http://127.0.0.1:8899/ws') as ws:
   last={};end=time.monotonic()+7
   while time.monotonic()<end:
    msg=await asyncio.wait_for(ws.receive_json(),2)
    if msg.get('kind')=='telemetry':
     last=msg['data']
     if last.get('safety',{}).get('fcu_connected') and last.get('power',{}).get('volt'):break
   print(json.dumps({'mission':last.get('mission'),'flight':last.get('flight'),'gps':last.get('gps'),'power':last.get('power'),'safety':last.get('safety'),'devices':last.get('devices'),'sample_age_s':last.get('sample_age_s')},indent=2))
  print('check',json.dumps(await (await s.get('http://127.0.0.1:8899/api/check')).json()))
asyncio.run(main())
