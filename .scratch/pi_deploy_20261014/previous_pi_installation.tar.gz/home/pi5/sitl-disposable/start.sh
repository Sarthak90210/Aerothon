#!/bin/bash
set -euo pipefail
ROOT=/home/pi5/sitl-disposable
if [[ -f "$ROOT/supervisor.pid" ]] && kill -0 "$(cat "$ROOT/supervisor.pid")" 2>/dev/null; then
  echo 'Environment already running'; exit 1
fi
nohup "$ROOT/venv/bin/python" "$ROOT/supervisor.py" > "$ROOT/logs/supervisor.log" 2>&1 < /dev/null &
echo $! > "$ROOT/supervisor.pid"
echo 'Started. Laptop UDP 192.168.137.1:14550; local UDP 127.0.0.1:14551'
