#!/bin/bash
set -euo pipefail
ROOT=/home/pi5/sitl-disposable
if [[ -f "$ROOT/supervisor.pid" ]]; then
  pid=$(cat "$ROOT/supervisor.pid")
  if [[ -r /proc/$pid/cmdline ]] && tr '\0' ' ' < /proc/$pid/cmdline | grep -q "$ROOT/supervisor.py"; then
    kill -TERM "$pid"
    echo 'Stopping temporary SITL and MAVProxy'
  else
    echo 'Environment is not running'
  fi
fi
