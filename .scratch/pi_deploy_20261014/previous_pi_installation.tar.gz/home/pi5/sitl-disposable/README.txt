Disposable ArduCopter SITL environment
Firmware: official ArduCopter 4.7.1, ARM Linux static SITL binary
Python: isolated venv, MAVProxy 1.8.75
Model: quad, simulation speed 1x
Home: 12.9692,79.1559,220,0 (simulated location)
SITL -> MAVProxy: UDP 127.0.0.1:14560
MAVProxy -> laptop: UDP 192.168.137.1:14550
MAVProxy -> local tools: UDP 127.0.0.1:14551
Start: /home/pi5/sitl-disposable/start.sh
Stop: /home/pi5/sitl-disposable/stop.sh
All temporary simulator files are under /home/pi5/sitl-disposable.
Stop before deleting this directory later. No boot autostart was added.
A persistent Python supervisor keeps SITL's parent alive and manages both processes.
Verified on laptop: 229 MAVLink packets and 3 heartbeats, system 1/component 1.
