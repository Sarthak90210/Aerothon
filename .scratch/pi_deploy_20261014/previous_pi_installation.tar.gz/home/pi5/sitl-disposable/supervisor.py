import os, signal, subprocess, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
children=[]
def stop(signum=None, frame=None):
    for proc in reversed(children):
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
    time.sleep(2)
    for proc in reversed(children):
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGKILL)
    raise SystemExit(0)
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
commands=[('sitl',[str(ROOT/'bin/arducopter'),'--model','quad','--speedup','1','--defaults',str(ROOT/'copter.parm'),'--home','12.9692,79.1559,220,0','--serial0=udpclient:127.0.0.1:14560']),('mavproxy',[str(ROOT/'venv/bin/mavproxy.py'),'--non-interactive','--master=udpin:127.0.0.1:14560','--out=udp:192.168.137.1:14550','--out=udp:127.0.0.1:14551','--aircraft=temporary','--state-basedir='+str(ROOT/'run')])]
for name,cmd in commands:
    log=open(ROOT/'logs'/f'{name}.log','w')
    proc=subprocess.Popen(cmd,cwd=ROOT/'run',stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    children.append(proc)
    (ROOT/f'{name}.pid').write_text(str(proc.pid))
    time.sleep(2)
while True:
    if any(p.poll() is not None for p in children):
        print('A child exited; stopping environment',flush=True)
        stop()
    time.sleep(1)
