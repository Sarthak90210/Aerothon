# Independent evidence review, 2026-10-06

This review reads saved files only. It does not run flight software, change
recorded evidence, decode video again or feed evaluation truth to the drone.
The production run owner handles final grading and the next trials.

Machine-readable checks are in:

- `evidence_review_receipt_model_20261006.json`
- `evidence_review_bannerfix_cut_20261006.json`
- `evidence_review_bannerfix_final_20261006.json`

The separate `evidence_review_readonly_20261006.py` uses the Python standard
library and never imports ROS, simulator or drone modules. It refuses to
overwrite a review report.

## Closed receipt-model run

Run: `logs/reliability_render_my_world_s20261003_receipt_model_20261006/`.
The calm standard seed 20261003 completed and disarmed, but it is an
acceptance failure. The independent grade passes 21/22 checks; flight time
is 965.0 s against the unchanged 900 s requirement. Minimum native corridor
clearance is 0.723653985717438 m and restricted-zone clearance is
1.6350752361946306 m.

I reopened the archive and independently hashed every source entry against
its archive manifest. All 752 source/helper files match, and that manifest
matches the source and qualification manifests recorded with the flight.
All 53 runtime assets match their recorded hashes, including 32 captured
parameter files. ZIP SHA256:
`797e68a560739bfdff78830fe42b43b00cf965a7a31ff08f84fce9c0d7ad0b67`.

The copied world matches the preserved standard world SHA256
`2789929a82aaea474dfa3ab92e3616f9eb74da67f16660e5cb8301084546289b`.
The frozen profile copy and original profile both hash to
`ab8a664dce960bf046ec77354c9dc431777bfec5e909b005b78bcf07188f8b13`.

Delivery reached DONE on attempt 1 at decision stamp 696.6 s, recorded at
696.801 s. It inferred touchdown and detachment, then confirmed sustained
unloaded effort after estimated payout reached 0.0 m. The decision effort
is 0.40658325 and its telemetry independently passes the recorded stability
criteria. Raw FCU outputs [1660, 1614, 1658, 1617] at capture 696.777 s
recompute to normalized mean squared effort 0.40656225, below the frozen
0.415636489282869 threshold. Their age is 0.024 s at that recorded sample,
and the aircraft was armed.

`visual_ground_support_inferred` is false, with zero corroborating visual
frames. `provisional_probe_used` is false. This is motor-priority confirmation,
not dual-channel confirmation. Commanded winch travel has no encoder; zero
estimated payout does not measure the physical hook position. No usable
current measurement is established by this evidence. PWM effort is not amps
or measured thrust.

Separately saved post-flight comparison records native ground contact at
676.423 s, a retraction probe at 680.173 s, and zero payload movement over
167 native samples through confirmation. Those numbers evaluate the inference;
they were not its inputs.

Search QR/red delivered rates are 18.132404304/18.209595803 Hz in simulated
time and 4.282733012/4.300953354 Hz in host time. P95 simulated latency is
0.238/0.234 s. P95 processing wall time is 0.028185831/0.013822555 s. Both
detectors report zero invalid capture events. These time bases must remain
labelled; host rates cannot be presented as simulated rates or Pi rates.

The existing video verification reports a decoded 1014.851 s capture-timed
video, 3360 original frames plus the final hold. Last camera capture is
1024.0 s; the first recorded disarmed mission result is 1023.765 s and the
last onboard record at 1024.567 s is disarmed. The recording reaches disarm.
This review checks the timestamps and saved verification, without another
video decode.

Both saved decision-input audits pass with no missing nodes or forbidden
subscriptions. Their stated scope is the direct subscriptions of mission,
winch and navigation nodes, including dynamic TF/native odometry exclusion.
The native contact-release component has no ROS interface; its contact input
and detach publication use Gazebo transport. The payload detector reads camera
images, and the winch adapter publishes commanded travel while leaving ground
and release status unknown. These are supported isolation claims. The graph
snapshots alone are not a continuous audit of every process or possible
transitive publisher.

## Newer bannerfix recording stopped before disarm

Run: `logs/reliability_render_my_world_s20261003_bannerfix_20261006/`.
Its recorded mission result is FAILED at 896.0 s: return-corridor STUCK at
x=13.19. After the run owner exported and graded the saved data, the independent
grade passes 16/22 checks. Failed checks are return traversal, never above the
corridor, expected flight mode, landing at take-off, 0.70 m corridor clearance,
and complete recording through disarm. Native corridor minimum is
0.6842457669223637 m; restricted-zone minimum is 1.626468465646198 m.

The recorded armed interval is 870.9 s and ends while still armed. It cannot
qualify the complete 900 s flight-duration requirement. Delivery independently
passes fresh motor qualification at decision 692.8 s. Raw PWM
[1660, 1615, 1659, 1616] recomputes effort 0.4068905 with age 0.026 s at
recorded confirmation 692.905 s. Ground support is again visually unconfirmed,
and estimated hook payout is zero. Separate post-flight truth records contact
at 674.013 s and the probe at 676.678 s, with zero payload motion over 163
native samples through motor confirmation.

| Last actual evidence | Simulated timestamp |
| --- | ---: |
| Onboard journal record | 929.515 s |
| FCU pose and velocity capture/receipt | 929.511 s |
| Raw FCU motor outputs | 929.479 s |
| FCU flight-state capture/receipt | 928.529 s |
| Camera capture; recorded at 929.315 s | 929.2 s |
| Independent aircraft truth | 929.477 s |
| Independent payload truth | 929.500 s |
| Native contact journal | 929.475 s |
| Mission flight command | 896.001 s |
| Winch command | 692.801 s |

The last flight-state message is armed, RTL. Final FCU pose is approximately
(0.05291, 0.06557, 6.01243) m in local coordinates; vertical velocity is
-0.49289 m/s. Independent aircraft truth remains airborne at 5.94187 m.
There are 168 recorded onboard samples after the first failed result at
896.057 s; none records a disarmed state. The payload truth remains on the
ground at z=0.104999883 m. The recorder log ends with ExternalShutdownException.

The run's `runner_exit_code.txt` contains 0. That value does not establish
mission completion or disarm. Exporting the available video cannot recover
the missing landing/disarm evidence. Report this recording as partial and
retain the mission failure and exact cut boundary.

The saved export now reports 919.951 s against the 919.95 s captured interval,
3124 original frames plus the final hold, and successful decoding. It ends at
capture 929.2 s while the aircraft remains airborne. The decoder result verifies
the available partial video, not a complete mission recording.

I independently verified its 752 archived source/helper files and 53 runtime
assets. ZIP SHA256:
`3c7ce74100b3b7b9c90733fbb9fdef28414cdd5195e325bd01017e49e8e5a236`.

## Evidence and documentation gaps

- The separate calibration recordings contain 83 loaded and 90 unloaded
  effort samples. Their recomputed means and sample deviations exactly match
  the frozen profile, and labelled sampling configurations agree on motor
  channels and PWM range. They do not contain source/runtime manifests from
  capture time. Their onboard journals retain derived effort and stability
  telemetry, rather than raw RCOut channel messages. Acceptance flight raw
  PWM independently corroborates the unloaded decision, but the original
  calibration has weaker provenance than the later acceptance recordings.
  Future recalibration should use the same raw motor/configuration/source
  recording discipline before freezing another profile.
- Issue 05's top resolution previously described older passes without a
  current-source qualifier. This review corrects only that issue. Issue 04's
  top resolution and issue 07's closure wording still refer to earlier
  acceptance passes; any final progress summary should qualify those by their
  archived source. The top of status.md and FIELD_READINESS.md already make
  that distinction.
- The payload-node docstring says the camera must confirm ground support.
  Current motor-priority behaviour and CONTEXT.md differ. Correct that comment
  when production source is next intentionally changed; do not change a frozen
  qualification source just to edit wording.
- FIELD_READINESS.md's older go/no-go section names the worst-preset wind
  envelope. Current issue 15 does not qualify coupled delayed-gust operation.
  Treat those numbers as proposed conditions pending actual campaign and
  hardware qualification; do not present them as an accepted flight envelope.

## Pending simulation checklist

- [ ] Fix the latest feasible-course return failure using its onboard evidence;
  retain the full failure and the partial-recording cut record.
- [ ] Repeat the full offline suite on the final production source. The saved
  1336-pass, 3-skip result predates the latest banner change.
- [ ] Obtain complete current-source calm standard seed 20261003 and seed
  1001 runs with every unchanged independent check passing, motor qualification,
  home landing, disarm, full camera timeline and exact source/runtime archive.
- [ ] Verify both targeted source manifests match each other and current drone
  source before the navigation campaign; older passing archives do not open
  that gate for changed code.
- [ ] Reassess issue 15's coupled delay/gust failures on the final source and
  report failures on feasible geometry as failures.
- [ ] Execute seeds 1-5 and calm/field/worst/random across all 10 current world
  fixtures: 200 requested cases. Geometrically blocked cases are classifications,
  never traversal passes. Preserve all successful and failed run evidence.
- [ ] Repeat rendered standard, shipped, rotated and split-corridor acceptance
  with measured detector rates and full recordings through disarm.
- [ ] Keep headless navigation, rendered perception and motor-confirmed delivery
  qualification separate in reports.

The off-axis world still matches SHA256
`bd842c00f4918857094f6d669910142143903cf5c1385b686c98c011bc2b3537`.
Its saved Euclidean 0.70 m expansion audit reports a wall-to-wall barrier;
the two gaps 1.21/1.09 m are below the required 1.40 m. Saved grid bottlenecks
are 0.45 m at 5 cm and 0.4375 m at 2.5 cm. It remains an infeasibility
regression, not a required traversal success.

## Deferred hardware and flights

`docs/HARDWARE_QUALIFICATION_RECORD.md` marks every device, velocity response,
load signal and failsafe unqualified. It requires measured wiring, camera and
lidar orientation/rates, real servo and winch travel, raw evidence, a pass
criterion before each trial, and reviewer acceptance. Initial electrical and
actuator checks are props-off. Props-off checks cannot qualify loaded/unloaded
hover effort; separate actual hover trials must do that.

The staged record covers hover, one gate, outbound corridor, return corridor,
delivery and the full mission, with review before advancement. All are deferred.
No connected hardware or staged-flight work was performed by this review.
The existing claw, motor-priority policy, and three-attempt full estimated
stow followed by unconfirmed continuation remain the agreed scope.

## Full offline repeat on measurement-time alignment source

The later full repeat used the detached owned job
`logs/reliability_full_measurement_time_owned_20261006/`, ROS domain 221.
It completed with exit 0: 1340 tests passed, 3 skipped in 869.56 s. Python
syntax, shell syntax, XML/YAML parsing, frontend TypeScript checking and Vite
build all passed. Vite emitted the existing warning about chunks over 500 kB.

The independently recorded 755-file source/test/fixture/wrapper snapshot
matches after the suite, with no changed, added or removed files. Evidence:

- `logs/reliability_full_measurement_time_20261006.log`
- `logs/reliability_full_measurement_time_report_20261006.json`
- `logs/reliability_full_measurement_time_source_20261006.json`

The three skipped final cases are real-corpus banner detection by lighting,
QR decoding rate by condition, and the pixels-per-module envelope. The corpus
directory contains only `expected.json`, with no photographs. These skips
leave real-camera performance unqualified.

This repeat qualifies the frozen measurement-time alignment source for offline
checks. Required rendered acceptance and campaigns remain pending. Any later
production change requires the relevant offline checks again; these results
do not establish a rendered clearance pass or a hardware pass.
