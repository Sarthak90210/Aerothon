# Headless observation, handover and terminal recording fixes

Status: ready-for-agent

The current headless simulator now publishes its integrated wind-inclusive motion, retains its active position/takeoff controller until a delayed raw velocity packet arrives, and records actual terminal state through disarm. The changes are limited to `sim/headless_world.py` and the new `sim/test_headless_observation_contract.py`. Wind generation, actuator response, obstacle/contact geometry, clearance, mission decisions and the frozen baseline snapshot were not modified.

## Reproduced failures and checks

`logs/reliability_headless_observation_red_20261007.log` records **6 failed, 1 passed in 2.62 s** before the source fixes. The new tests reproduce:

- FCU velocity omits the wind residual present in physical displacement.
- Position control is cleared 0.4 s before the raw packet arrives.
- Takeoff control is also cleared before packet arrival.
- A physical disarm between periodic publications leaves the last native row armed.
- A time-limit cut omits the actual final sample.
- A completed state stops immediately rather than allowing a terminal publication drain.

The first related green selection in `logs/reliability_headless_observation_green_20261007.log` records **23 passed in 2.46 s**, on ROS domain 225. Review then identified that caching velocity before ground clamp/contact correction omitted the completed physical step's motion. Two new edge regressions reproduce that problem in `logs/reliability_headless_terminal_motion_red_20261007.log`: **2 failed, 7 passed in 2.21 s**. The final related selection in `logs/reliability_headless_observation_final_green_20261007.log` records **25 passed in 1.98 s**, including all 9 new tests, 7 existing raw-command delay/frame checks, 4 headless occlusion checks and 5 existing qualification-evidence checks. `scripts/run_tests.sh` discovers all `sim/` tests, so the new file is included in the next full suite. This review does not claim that suite or any fresh campaign has passed.

The tests invoke the actual physical step, setpoint callbacks, controller selection, publication methods and runtime loop on a bare fixture. They compare FCU motion with measured per-step displacement while changing wind, verify that repeat publication does not call the wind generator again, and verify local ENU vectors with a rotated aircraft. Terminal tests deliberately disarm on the first physical step, between normal publication intervals, and check actual emitted State messages with `recorded_disarm`. The tests exercise publication and recording order; they do not establish DDS delivery latency or rendered camera performance.

## Final behavior

The physical integration retains its original `(self.v + drift)*DT` update. At the end of each completed physics step, after ground clamping and contact response, the simulator caches `(final_position-start_position)/DT` in `ground_velocity`. FCU publication reads that measurement rather than advancing stochastic wind. Wind-inactive steps replace the cache with their current motion. The velocity header names `map`, matching the headless pose's local ENU frame. Its timestamp identifies the end of the measured timestep, and its value is the average ground velocity over that completed interval. Contact response and trajectory remain unchanged; a contact still fails independent grading.

The raw callback only queues valid velocity packets. Controller selection clears the former position/takeoff target when the queued packet is actually due, preserving the previous controller during the declared 0.4 s transport interval. Body velocity still converts once using the receipt heading. Position callbacks retain the existing immediate-position-update model and cancel pending raw velocity; this work does not claim a complete measured model of position-packet transport or simultaneous stream arbitration.

State messages now have actual simulation capture timestamps. On a completed result with a physically disarmed grounded aircraft, the runtime publishes its real final FCU state and native row immediately, then keeps normal simulation-clock/publication processing active for 1 s before a final flush. The drain resets if completion conditions cease. Repeated native samples at the same timestamp are avoided. A simulation time limit records the actual state, including armed=true when that is the state; it never invents landing or disarm. No old CSV, onboard record or grade was rewritten.

Stable source hashes after the green selection:

- `sim/headless_world.py`: `1bfe2d74b838bff5cd0da270dcce57b08db53c408e0eea2f902a84d9d3619bd0`.
- `sim/test_headless_observation_contract.py`: `e69088f4555df7781ea4c116708e79ed593bfcd58e3c27a84aa1996e46f2bfc4`.

## FCU hold semantics and limits

The installed ArduPilot source at `/home/sarthak/ardupilot/ArduCopter/` shows that `ModeGuided::hold_position()` uses zero velocity and acceleration targets. Its velocity controller retains XY position stabilization unless GUIDED_OPTIONS bit 4 disables it; bit 5 disables velocity stabilization. A MAVROS velocity target is a ground-velocity request to the FCU, not a direct motor/actuator velocity. The offline first-order fixture adds residual wind after its commanded component and does not reproduce that FCU position stabilization.

The archived parameter overlays do not record a GUIDED_OPTIONS value. Therefore this review does not establish the live FCU option setting or a measured hold response. The finite delayed-gust fixture failures remain control regressions in their declared model. They do not directly prove that the real FCU's zero-velocity interface cannot hold position. The companion's safe hold/release policy and stopping certificate still require independent qualification. The other diagnosis agent owns those scratch experiments.

## Closed baseline provenance

`closed_baseline_byte_review_20261007.json` independently rechecks the closed campaign snapshot and both qualified archives. Both ZIP SHA values match, both 756-entry archived manifests are identical, all 756 snapshot bytes match, and there are no missing files, mismatches or symlinks. The 14 recorded import origins/hashes and 10 separately recorded material asset hashes match; nine text/PNG assets have separate campaign-setup provenance, while `qr_matrices.json` was already archived. The active frozen snapshot was not edited to apply these fixes.

The closed `logs/reliability_navigation_baseline_matrix_assets_20261006/report.json` records **200 requested, 160 executed, 0 navigation passes and 40 classified without flight**, with source unchanged and owned exit code 1. The aggregate records 38 flights with contacts, 110 FAILED, 45 ABORTED_RTL and 5 ABORTED_LAND. Twenty editor-test combinations were classified invalid; twenty preserved off-axis combinations were classified geometrically infeasible at 0.70 m. None of the feasible combined-control failures was reclassified as geometry failure.

The three additional rendered baseline courses failed before runtime capture or mission startup, as preserved in `logs/reliability_baseline_rendered_courses_20261006/report.json`. They provide no traversal or rendered detector-rate qualification. The source-qualified calm standard pair remains separate archived evidence. Headless characterization cannot qualify rendered perception or motor delivery; the corrected headless source requires fresh campaign evidence after the full suite.
