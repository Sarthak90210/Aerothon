The current source still fails the two combined disturbance and command-delay diagnostics. Dirty lidar seed 0 first violates 0.70 m at 5.20 s and contacts in the 6.05 s integration step. Late scans seed 1 first violate clearance at 6.05 s and contact at 7.85 s. Their FCU velocity samples have zero receipt age, so the timestamp correction cannot change these cases.

The critical distinction is between zero commanded actuator velocity and zero ground velocity. At dirty-trace time 4.70 s the aircraft still has 0.8055 m native clearance, but every candidate certificate, including raw zero, is rejected. The node sends raw zero. Ground velocity has a -0.1104 m/s cross-corridor component, and the measured disturbance continues changing. Clearance falls through 0.70 m at 5.20 s. Once the origin falls below the unchanged 0.725 m planning threshold, every movement correctly fails certification. Permitting an escape from that origin would not address the earlier loss of a viable hold.

The certificate predicts a later zero-ground braking goal. That terminal goal requires active disturbance cancellation. The existing fallback can instead publish zero actuator velocity, which does not provide that terminal response. A point-valued derivative forecast also does not qualify its uncertainty or prove a viable later hold remains available. These are safety assumptions that need explicit controller state and operating-envelope treatment; neither a narrower-clearance fallback nor a blind reverse is an acceptable repair.

Three scratch-only certificate changes were evaluated one at a time. None fixed the physical trajectory:

- Waiting one extra transport delay before the terminal hold, dirty seed 0, contact at 6.05 s, minimum logged pre-integration clearance 0.4079594577 m.
- Modelling a terminal raw-zero command with the remaining disturbance, dirty seed 0, contact at 16.25 s, minimum logged clearance 0.4052673046 m.
- Requiring certification for the measured, frozen and reversed disturbance-rate forecasts, dirty seed 0, contact at 6.20 s, minimum logged clearance 0.4117007766 m.

The rate-alternatives probe first had a scratch indentation error, retained in its original log; retry 1 is the actual physical result. The first proactive-hold launch had a scratch missing-import error, also retained. No result from either setup error is treated as a physical trial.

A conservative position-hold prototype stops corridor entry before its projected delay and uncertainty reserve is consumed. It latches the aircraft's own measured position, commands a bounded position correction, and passes every output through the unchanged production motion certificate. It does not consume obstacle geometry or fixture truth. The diagnostic reserve is 0.70 m plus 0.025 m, measured ground speed times the declared transport delay, and half the existing 0.8 m/s² derivative cap times the squared delay-plus-response interval. The derivative cap is not a qualified physical uncertainty bound. This is an explicit diagnostic assumption.

The hold prototype maintained physical clearance through 20 s in both cases:

- Dirty seed 0, minimum actual clearance 1.0624550893 m, held near the FCU-latched entry position [8.3, 0.0].
- Late seed 1, minimum actual clearance 1.0677889690 m, held near [8.3011080747, -0.0051461967].

Both runs intentionally fail traversal with a 20 s timeout. They demonstrate a bounded safe hold, not a traversal pass, rendered qualification, or a general wind guarantee. The policy has not been installed in production. A future implementation should make ACTIVE_HOLD explicit before terminal safety is lost, distinguish it from raw zero, publish its reason, preserve fresh observation checks, and integrate its mission failure handling. The uncertainty bound and position response require qualification. The calm rendered return must still be verified independently.

The commands are `bash .scratch/simulation-reliability/check_certificate_terminal_20261006.sh --policy POLICY --kind dirty --seed 0 --out NEW.json` and `bash .scratch/simulation-reliability/check_proactive_position_hold_20261006.sh --kind dirty|late --seed 0|1 --out NEW.json`. These wrappers use offline ROS domain 220. Every JSON output includes current source hashes, the command receipt basis, full decisions and independent physical clearance. Exact prototype versions are stored by SHA-256 under `.scratch/simulation-reliability/terminal_prototype_source_archive_20261006/`.

Physical outputs are `logs/reliability_gust_dirty_delayed_terminal_hold_20261006.{json,log}`, `logs/reliability_gust_dirty_terminal_raw_zero_20261006.{json,log}`, `logs/reliability_gust_dirty_rate_alternatives_retry1_20261006.{json,log}`, `logs/reliability_gust_dirty_proactive_hold_retry1_20261006.{json,log}` and `logs/reliability_gust_late_proactive_hold_20261006.{json,log}`. Original error logs and baseline failures remain preserved. Production controller, planner, tests and existing helpers were not modified during this diagnosis.
