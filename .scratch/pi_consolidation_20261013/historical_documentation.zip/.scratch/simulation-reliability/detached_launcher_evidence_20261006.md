# Detached launcher evidence

The new launch_owned_job_20261006.py helper uses Python argument arrays, not a
composed shell command. It creates a detached supervisor and a separate command
process group, redirects their output to task-owned files and returns after
startup. A job directory must be new. status.json records the supervisor and
command PID, process group, kernel start-time ticks and Linux boot ID.

The stop command refuses a reused PID or a process that is no longer the recorded
group leader. It sends TERM to the verified command group, so foreground runner
processes stop and Bash can execute its cleanup trap. The supervisor remains
outside that group and records the final status and exact exit code. After the
chosen grace period, KILL is limited to the still-verified command group.

Three harmless checks ran on 2026-10-06. No Gazebo, SITL, repository tests, builds, installs
or hardware processes were started.

1. launcher_smoke_finish_20261006 returned RUNNING to its launch client in about
   0.38 wall seconds. Its independent eight-second sleeper later exited with
   code 7. The supervisor persisted FAILED, exit_code=7 and exit_code.txt=7.
   Its output log includes both the startup and completion messages. This
   demonstrates survival after normal tool-client exit.
2. launcher_smoke_stop_20261006 started a sixty-second sleeper. A separate
   invocation stopped only its recorded group and persisted STOPPED with code
   -15. Both launch and stop calls returned in under one second.
3. launcher_smoke_trap_job_20261006 ran a Bash fixture with a separately detached
   sleeper and a foreground sleeper. Scoped TERM ended the foreground command,
   its EXIT trap ran and stopped the escaped child group. trap_cleanup.txt
   records the executed cleanup. Final status was STOPPED/-15.

Existing acceptance runner cleanup remains unchanged. This helper does not
guarantee survival across a WSL shutdown, machine reboot, supervisor kill or a
tool that forcibly kills all descendant process groups. A forced KILL can
prevent a command's cleanup trap from finishing. In that case, check that job's
stack.log for its recorded owned stack PGID and verify ownership before any
separate cleanup. Never kill a global simulator pattern.

Example future launch from the repository PowerShell working directory:

```powershell
wsl -d Ubuntu -- /usr/bin/python3 .scratch/simulation-reliability/launch_owned_job_20261006.py start --job logs/reliability_owned_next_20261006 --cwd . -- /usr/bin/bash scripts/run_recorded_acceptance.sh sim/worlds/my_world.json 20261003 logs/reliability_render_my_world_s20261003_next_20261006 logs/delivery_profile_20261005.json
```

The launch helper writes output.log, supervisor.log, job.json, status.json and
exit_code.txt beneath that task-owned job directory. The unchanged recording
runner retains all flight evidence beneath its separate run output directory.
Choose fresh directories and a source snapshot appropriate to the next fix.

Read status or explicitly stop that example job:

```powershell
wsl -d Ubuntu -- /usr/bin/python3 .scratch/simulation-reliability/launch_owned_job_20261006.py status --job logs/reliability_owned_next_20261006
wsl -d Ubuntu -- /usr/bin/python3 .scratch/simulation-reliability/launch_owned_job_20261006.py stop --job logs/reliability_owned_next_20261006 --grace 30
```

The same launcher can run the prepared, gated navigation-matrix script after
both current-source full rendered standard acceptances pass. It does not bypass
the campaign gate or the rendered runner's singleton check.
