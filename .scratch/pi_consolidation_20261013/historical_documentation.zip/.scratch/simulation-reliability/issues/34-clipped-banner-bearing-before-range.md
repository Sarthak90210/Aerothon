# Centre repeated clipped identity before area-based distance assessment

Status: ready-for-agent
Resolution: bearing regression and 139 related checks pass; guarded integration running
Parent: ../spec.md

An actual onboard frame at capture 742.9 s is matched exactly with detector
detail in logs/reliability_split_pristine_alignment_frame_20261007. Its
board is cropped by the image edge. Alignment still uses partial pixel
area to judge distance before centring the bearing.

The candidate requires existing multi-frame confidence and enough clipped
captures, then turns at the current position anchor to centre that bearing.
Normal range assessment, lidar alignment and gate crossing remain required.
The cropped area is not a measured distance and does not authorize movement.

The actual _dwell method fails before and passes after. All 139 banner sweep,
orbit, capture, camera gate and return-search checks pass. The seven-file
review also includes provisional camera red edges, stop-before-replan
handling and their tests. Integration requires previous actual disarm,
closed source archive and the unchanged 835-file source before any write.

Evidence: logs/reliability_clipped_banner_bearing_regressions_owned_20261007,
logs/reliability_rendered_perception_review_patch_20261007 and
logs/reliability_early_red_clipped_bearing_integration_20261007.
