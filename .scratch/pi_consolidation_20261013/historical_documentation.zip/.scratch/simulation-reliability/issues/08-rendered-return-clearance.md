# Rendered return-corridor clearance failure

Status: ready-for-agent
Resolution: archived source passed both seeds; current-source fresh return failed, issue 16 open
Parent: ../spec.md

Current update: the changed disturbance certificate's fresh standard seed
20261003 failed with STUCK and 0.680769329 m clearance. Prior two passing runs
below are archived-source evidence. Current qualification and broader
campaigns are gated on resolving issue 16.

2026-10-06: both full standard acceptances pass all 22 checks. Independent
minimum corridor clearances are 0.741457867 m for seed 20261003 and
0.762468206 m for seed 1001. Both recorded input graphs exclude simulator
decision inputs during navigation, and both recordings continue through disarm.
The unchanged off-axis world remains geometrically infeasible at 0.70 m.
Known gust failures remain separate and open under issue 10.

## Evidence

The standard world, calm seed 20261003 retry 2, reports STUCK on return at
t=952.8 s. Independent native aircraft truth first crosses below 0.70 m at
t=932.212 s beside obstacle 0, while the navigator reports 0.7761 m.
The minimum is 0.54835 m at t=951.675 s beside obstacle 1, before abort.
See `logs/reliability_render_my_world_s20261003_retry2_20261005/clearance_failure_attribution.json`.

The CAD and onboard URDF mount the lidar 0.139 m forward of base_link.
Capture-time registration currently applies aircraft translation and yaw
without this sensor extrinsic. Controller compensation also publishes
nonzero hold commands after a path becomes blocked. Both need regression
evidence; the extrinsic omission alone does not prove the full failure cause.

## Required result

Use onboard sensor mounting information to register returns at capture time.
Require available, valid mounting and aircraft pose data. Do not use native
simulator positions in decisions. Preserve 0.70 m throughout motion, hold
and recovery. Reproduce the tight standard return course in a focused
rendered trial before repeating full acceptance.

Keep this issue open until independent grading verifies traversal and
clearance in the unchanged feasible course.

## Comments

2026-10-06 full standard calm seed 20261003 retry 4 PASSED all 22 acceptance
checks, with 0.741457867 m minimum corridor clearance and full below-wall
return traversal. Flight duration was 864.1 s, ending disarmed at home.
Seed 1001 and broader weather qualification remain. Prior failures are retained.

2026-10-06 delay-aware rendered trial PASSED. The unchanged standard world,
calm seed 20261003, completed full below-wall return traversal at 0.717000770 m
independent minimum clearance. Landed and disarmed. Initial and navigation-time
input audits passed. Verified full video is 132.801 s. Evidence:
`logs/reliability_render_return_delay_20261006/RESULT.md`. Keep the issue open
until full mission acceptance and the remaining weather regressions pass.

2026-10-06 latest: Mounted-link retry 2 progressed roughly 3.3 m but failed at
0.444372 m independent clearance. Its new raw lidar record enables actual
scan replay. Onboard command-response fitting estimates 0.37824 s transport
delay, omitted by the observer and braking model. Two minimized regressions
fail before the fix; 90 focused checks pass after command delay is added.
Delayed closed-loop and rendered traversal qualification remain pending.
All source, configuration, native truth and full video are preserved.

2026-10-06: Lidar registration now consumes onboard base_link mounting TF and
full capture-time attitude. Unknown transforms and stale capture poses hold.
Compensated holds receive the same continuous clearance check as travel.
The first focused rendered trial failed without traversing: the mounted
sensor's rear shadow disconnected aircraft centre from the first free cell.
A narrow occupied body-to-sensor link resolves that graph defect without
admitting blind reverse paths. Independent navigation clearance in that
stationary trial was 1.03826 m. Its setup descent touched the banner, which
remains recorded as a failure; the next setup descends before crossing.

The next stress rerun exposed three gust failures in the split corridor.
Replay shows over-predicted compensation rejected toward the opposite wall,
then replaced by raw zero, losing current wind cancellation. A certified
current-disturbance hold is being verified. Rendered traversal remains open.

08 October continuation: V14 retained mild-weather seed 3 found the QR at
676.4 s, then failed return alignment and the unchanged 900 s limit. Recorded
operator RTL, connected disarm, zero fixture contacts/fence breaches and all
original failed grades are closed in
logs/reliability_reduced_scope_v14_source_20261008/targeted_diagnostic_closed_review.json.
Its level-camera top-cropped lettering was observed during yaw settlement,
before the dwell epoch. A real-leaf red control reproduced the ignored capture.
V15 applies the existing three-distinct-fresh-capture, 0.5 m same-XY raise
(maximum three) during settlement and retries the captured world bearing.
258 relevant checks pass; no current-source rendered acceptance yet.

08 October continuation: V16 passed all five targeted navigation cases,
including field seeds 1/2/3 and retained mild-weather random seeds 3/4, with
unchanged .70 m corridor acceptance, zero contacts/fence breaches and actual
disarm. Its full offline suite passed 1,535 tests and all syntax/configuration/
frontend checks; three empty real-photograph corpus tests were skipped.
V16 rendered split was safely interrupted for contact-recording evidence
failure before return traversal; it is not a rendered return pass. V17 changes
only passive winch-arrival recording and its regression tests. Controller and
return fixes are byte-identical. Exact-source verification is active; all five
rendered acceptances and the reduced 96-flight campaign remain required.

08 October V18/V19 continuation: V18 fields 1/2/3 passed all 13 navigation
checks with .741351961/.716641203/.729317782 m minimum corridor clearance,
normal timing and actuator response, zero contacts/fence breaches and actual
disarm. Retained mild random 3 still failed return/time. V17's two-worker
recording contains 15 distinct identified horizontal clips during return yaw
settlement; it is not a full camera capture history. The real AlignToBanner
leaf reproduced the ignored four-capture framing seam. V19 applies the
existing 2 m/shared two-attempt backoff during turning using fresh identified
capture-associated direction only. It supplies no range or crossing permission.
92 focused return/capture/gate/clearance and 98 integrated component checks
pass; the normal startup's 11 imports match the 922-file freeze. V19 targeted
trials are active. No final offline/native/campaign acceptance is claimed.

08 October V19/V20 continuation: All five V19 cases passed both corridor
traversals, QR search, .70 m clearance and the 900 s limit. Field 2 and mild
random 3 still failed home landing (1.67/2.19 m); those failed grades and actual
disarms are closed. The actual built tree returned at 5 m, below its landing
leaf's 6.98 m tracking floor and 8.48 m acquisition height, so it committed
before visual acquisition. V20 wires home return to that existing derived
height. The real built-tree red control and 230 focused green checks are
archived. V20's 11 normal-startup imports match its 923-file freeze. All five
same-source targeted trials are active; final native acceptance remains open.

08 October V21 continuation: V20 fields 1/2/3 and mild random 4 passed navigation; mild random 3 still exceeded 900 seconds. All actually disarmed with zero contacts/fence breaches. V21 recovers the observed return-search delay by starting the existing bounded guarded orbit after three stable fresh whole-region captures. Actual-leaf red and 124 focused green checks are archived, and all 11 normal-startup imports match the freeze. Five same-source trials are active. No final offline/native/campaign acceptance yet.

08 October V22 continuation: V21 early-orbit candidate rejected after retained failures. Four cases actually disarmed; mild random 4 simulator ended with last telemetry armed, so final disarm is unverified. V22 retains the full initial search sweep before using stable whole-region observations for an existing guarded orbit, and pauses transient gate capture gaps with unchanged .30 s freshness/.08 m/s braking thresholds. Actual-leaf reds and 287 focused greens archived; 11 startup imports match. Five same-source trials active; final acceptance remains open.

08 October V23 continuation: V22 field seeds 1/2/3 actually disarmed; field 2 passed navigation with precise landing. Mild random 3 failed time/return, preserving actual RTL/disarm. Its 41.70 m high return leg took 70.64 s at retained .60 m/s search cap. The actual built-tree lease regression failed. V23 restores a bounded prior navigation cap only after high-altitude/nadir/fresh-pose prerequisites and FCU acknowledgement. 272 focused checks and 11 startup imports match the freeze. New trials queued after final V22 disarm; no native/campaign acceptance yet.

08 October V24 continuation: V23 closed 3/5 navigation passes; field 3 and mild random 3 time failures preserved, all actually disarmed and no contacts/fence breaches. High return speed restoration shortened transit to about 11 s but camera framing still failed. The actual FindReturnBanner leaf reproduced FORWARD bottom crop/BANNER top crop oscillation. V24 uses at most three camera-only bracket angles via the existing numeric protocol, validates measured settlement, and still rejects clipped range. 314 focused checks and 11 startup imports match the freeze. Five same-source trials active; no final offline/native/campaign acceptance yet.

08 October V25: V24 closed four navigation passes; all actually disarmed and zero contacts/fence breaches. Mild random 3 actual clearance 0.6948520402727778 m remains FAIL. V25 fixes actual premature clipped-backoff transit cancellation, with 297 focused passes and 11 normal-startup imports matching 931-file freeze. Two isolated corridor probes passed but did not reproduce runtime; no speculative clearance change. Five V25 targeted trials active. No accepted source, native final acceptance or campaign qualification. Strong/delayed failures unresolved and excluded.

08 October V26: V25 closed four navigation passes; all actually disarmed and zero contacts/fence breaches. Mild random 3 QR found, return search 190.85 s, corridor 0.6849396857248734 m/time/mode FAIL preserved. Actual leaf reproduced side-crop retry consuming centred vertical framing. Actual frozen V25 certificate reproduced .6990529898953362 m clearance with modest .06 m/s helpful response error, normal .20 s budget/.6 s response/zero queue. V26 separates framing classes and enforces both disturbance and zero-disturbance predictions. 122 integrated and 24 normal navigation/timing checks pass; 11 normal-startup imports match 933-file freeze. Five two-worker targeted trials active; no accepted source or reduced qualification yet. Strong/delayed failures unresolved and excluded.

08 October V27: V26 field 2 passed navigation with .7318246284671641 m corridor clearance and actual disarm. Mild random 3 QR found but return handover failed; automatic RTL and actual disarm preserved. Actual built mission red reproduced generic .60 m climb completing below next .30 m guard. V27 specific return climb uses .20 m tolerance, retaining 10 m height and all prerequisites. 226 focused checks and 11 startup imports match 934-file freeze. Priority V27 trial uses safely closed domain 41 while second worker waits for V26 to close domain 40. Five passes still required; failed batches stop unflown queue and never interrupt armed flights. No accepted source or campaign qualification.

08 October V28: V26 closed four navigation passes/one failed altitude handover. V27 closed field 2 navigation PASS .7354888194818544 m corridor clearance, mild random 3 search/time FAIL; both actual disarm, zero contact/fence; three unflown cancelled. Original failure reviews retained. Actual orbit search seam RED showed camera tilt and exhausted second look leaking to later vantages. V28 restarts each guarded orbit view level with its own second look/fresh dwell; altitude, speed, guards and thresholds unchanged. 93 focused PASS, 11 startup imports, 935-file final freeze. All targeted/native/campaign qualification remains pending.

08 October V29: V28 field 2/3 navigation PASS and actual disarm; mild random 3 return search improved to 15.15 s but gate-crossing timeout/contact FAIL, .4034108728140693 m corridor clearance; two wall contacts, RTL and actual disarm retained; two unflown cancelled. Actual gate/normal physics/streamed guard regression reproduced crossing contact. Fresh signed FCU displacement confirmation retains distance, heading, tolerance, freshness, ACKs and braking limits. 20.8 s replay PASS .9145067912135068 m zero contact; 91 focused checks and 11 startup hashes match 938-file freeze. Rejected settle-window/damping probes archived, not adopted. Five targeted cases rerun; all native/campaign qualification pending.

08 October V30: V29 closed one navigation pass and two 900-second timing failures; zero contacts/fence breaches, both corridor checks passed, all three actually disarmed; two unflown cancelled. Mild3 minimum .7230623482323127 m. Landing capture-gap regression reproduced immediate climb toward old marker fix before existing grace expired. V30 retains visual horizontal correction while holding current height during brief gaps; original prolonged-loss recovery remains. 52 focused checks pass; 939-file freeze and all 11 startup hashes verified. Five targeted flights active, no accepted source/full suite/rendered/campaign claim.


## V32 hazard-hold checkpoint

V31 field 2/3 passed navigation and disarmed. Mild random 3 passed corridor at .7372377792461882 m, but failed restricted-zone clearance at 1.2139113263915782 m. Original failure is retained. V32 revalidates latched search anchors against new observed paint and certifies escape through the existing router, stopping if blocked. 99 focused checks pass; whole-flight and rendered acceptance remain pending. Issue remains open.
