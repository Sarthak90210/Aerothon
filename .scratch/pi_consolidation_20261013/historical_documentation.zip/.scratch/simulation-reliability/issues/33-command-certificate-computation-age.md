# Include computation time before command receipt

Status: ready-for-agent
Resolution: 4 contract and 29 zero-computation fixture checks pass; live repeats running
Parent: ../spec.md

Accepted commands in the recorded independent-clock trials were published
up to 0.18 s after the certificate began. The isolated repair includes a
0.20 s computation budget in receipt heading and translation. It stops
new translation/yaw when the deadline expires or flight observations age
during computation, while retaining already transmitted packets.

The actual publication-path regression fails 3/4 before and passes 4/4
after. The initial unchanged 29-test run passes 28 and fails a handover
assertion in a fixture with a clock frozen during computation. A separate
wrapper explicitly declares computation budget zero for those fixtures,
with transport 0.4 s, response 0.6 s, sensor/geometry data and assertions
unchanged. All 29 then pass. Independent-clock mission repeats retain the
0.20 s budget. Both results are preserved. No gust qualification is claimed.

Evidence: logs/reliability_command_deadline_source_20261007 and
logs/reliability_command_deadline_zero_time_checks_owned_20261007.
Archive SHA-256 fa239ceba76e5ad03d34229197703bcd5972389111d76ec7a1c9b0df7ac164b9.
Production controller remains unchanged.

The first two independent-clock repeats pass all 13 navigation checks.
Field seed 4 maintains 0.7535757057 m corridor and 2.1850712636 m exclusion
clearance, 793.6 s airborne; field seed 5 maintains 0.7268959644 m corridor
and 2.2240712636 m exclusion clearance. Both have no contacts and finish
disarmed. Calm seed 5 is still running. These navigation-only runs omit
delivery, and cannot qualify rendered perception or motor confirmation.
Seven remaining calm/field seeds are prepared behind a guard requiring all
three focus passes including the 0.725 m planning reserve.


All three focused trials now close with 0.725 m planning reserve, all 13 navigation checks and actual disarm. Field 5 flight time is 811.3 s; calm 5 is 867.7 s with 0.7450852403 m clearance. All frozen archive/source/assets/evidence hashes were checked in closed_batch_review.json. The guarded extended seven-case batch is running. Its first two completed calm seeds pass navigation: seed 1, 873.9 s and 0.7281882368 m; seed 2, 868.3 s and 0.7471970874 m. Production integration remains pending; the headless gate substitution and mandatory diagnostic-path startup were identified in the production review. A staged optional-recorder main passes both normal and explicit-recording startup/cleanup checks, after reproducing the original KeyError. No production source was changed by that review.
