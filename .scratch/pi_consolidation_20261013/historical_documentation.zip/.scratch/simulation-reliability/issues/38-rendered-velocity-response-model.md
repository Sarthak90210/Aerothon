# Qualify the rendered velocity response and restore viable corridor braking

Status: ready-for-agent
Type: bug
Parent: ../spec.md

The integrated split return from the archived FCU entry still fails. The first
stationary-entry trial has native minimum 0.678049 m; the trace repeat has
0.685551 m. Both recoveries exhaust and actual connected FCU disarm is recorded.
Camera timeline and input audit pass. Neither is full mission acceptance.

At trace decision 134.5 s, observed clearance is 0.745744 m. The controller
certifies a body command [0.765327, 0.146450] m/s with 0.615 s packet-wait
forecast. Its estimated wind is [-0.023971, 0.141108] m/s and rate
[-0.061666, 0.259164] m/s2. By 134.75 s observed clearance falls below the
unchanged 0.725 m planning threshold. All subsequent hold/travel certificates
are refused, followed by three unsuccessful recovery attempts. The certificate
assumes a future response that this native trajectory does not establish.

Postflight first-order identification, using only recorded own packets and
FCU motion, fits the training segment best at 0.225 s lag and 1.6201 s response;
held-out acceleration RMSE is 0.16519 m/s2. The declared 0.4 s delay fit has
0.22352 m/s2 held-out error and a nonphysical response coefficient. These are
empirical model-mismatch observations, NOT a transport calibration or a future
gust bound. Noise, FCU position stabilization and acceleration limits may
invalidate a simple first-order fit. No controller parameters were changed.

An unchanged-controller native repeat now records message 85 (FCU target
local) at a requested 20 Hz to distinguish processed target timing from
measured response. Requests change telemetry only; no parameters or flight
targets are written by the observer. Own command, FCU target, pose and velocity
are captured separately. The observer source/hash and request result are saved.

Evidence:
- logs/reliability_render_split_return_integrated_stationary_20261007
- logs/reliability_render_split_return_integrated_trace_20261007
- logs/reliability_render_split_return_fcu_echo_20261007 (closed FAILED, 0.691816 m)

Next: close/verify the echo recording through disarm, associate unique own
packet signatures with FCU target snapshots, compare declared and observed
response without confusing absolute GPS offset with displacement error, and
construct a minimal failing certificate regression before changing the model.
Retain 0.70 m clearance, 0.025 m planning reserve, observation restrictions,
physical gust/delay fixtures and all original failed results. Calibrated or
candidate success must be requalified on final-source full missions.

Closed target echo and causal reproduction:
- Connected FCU disarm at 161.059 s; native minimum 0.6918155791 m.
- 421 unique first target matches, no unmatched velocity echoes; median lag
  upper observation 0.048 s, p95 0.057 s. This is not a future receipt bound.
- logs/reliability_causal_delay_mismatch_closed_review_20261007/review.json
  archives the actual controller AST and deterministic zero-wind fixture.
  Exact 0.4 s observer versus physical 0.05 s creates false lateral wind
  -0.2351466 m/s and rate -0.8 m/s2. Predicted 0.919309 m clearance is approved;
  physical minimum is 0.406778 m. Both matched-model controls reject the pulse.
- Requiring the identical packet to pass a zero-disturbance forecast repairs
  that counterexample, but dirty0 contacts at 6.5 s and late1 at 16.9 s.
  logs/reliability_no_favorable_disturbance_coupled_retry_20261007/summary.json
  remains rejected, not adopted. Original transform indentation error is
  preserved separately as infrastructure failure, not a flight result.
- Frozen native guard checkout has controller SHA256
  ee144216f8fc59fd9b9d444166491003516183155fff6d011c0c0f4caab5a30f, with
  root controller unchanged. Native focused diagnostic is pending.

Native guard diagnostic closed: TRIAL_COMPLETE at 169.087 s, connected disarm
175.93 s; 7/7 focused checks PASS, independent minimum 0.702153582 m. Six-node
live audit, runtime archives, source hashes and actual controller import
resolution verified. Frozen archive SHA256
4895b236a82d6d3a159654fc6ca5146da88f76cd902c8aed7a0e95e9798b699d.
No production adoption: the same guard still fails dirty0 and late1 contacts.
Full mission, perception, delivery, moving handover and repeated seeds are
not qualified by this stationary-entry diagnostic.

Queue-preview compensation corrects the deterministic inverse-response algebra
for a linear disturbance at physical .4 s receipt (old acceleration error
0.266667 m/s2, candidate approximately zero). It still contacts dirty0 at 6.9 s
and late1 at 7.8 s. Combined separate-actuator forecast plus queue preview also
contacts; full outputs are preserved under the respective coupled directories.
Neither candidate is installed. Nominal algebra does not qualify gust response.


Latest closed tests: monotonic escape source passes 1442 tests, 3 skipped,
and all offline checks, verified against its unchanged 900-file archive.
Field seed2 finds the target at 601.70 simulated seconds (previous source
707.15) but fails return alignment and lands/disarms at 998.5 s airborne.
It has no obstacle contacts/fence breaches. Its 1.169191 m corridor minimum
does not qualify return traversal, which was not completed. Source/assets
and actual FCU disarm are verified; rendered cameras and motor delivery are
explicitly unqualified for this object-level trial.

Recorded-pose return projection corrected to the runtime 0.851919 rad HFOV:
all ten early alignment captures give zero geometrically admissible headings
on the 45-degree sweep, while the 15-degree sweep supplies admissible views.
The level camera misses the board vertically; a 20-degree look sees it.
The original 60-degree replay is retained as invalid runtime configuration,
not a qualification result. Geometry is only a detection precondition.
An isolated fine-framing candidate adds one bounded finer sweep, restoring
the look angle only above gate height, before physical relocation. It retains
the original lettering, freshness, range and lidar checks. Four component
controls pass. Its 901-file archive SHA256 is
dec801079383efa322d64caecc60da2850ead40253b8a40cb72725c27ae641df.
Field seed2 is active under logs/reliability_fine_return_framing_field_s2_navigation_20261007.
An initial launcher registration path error occurred after the valid freeze;
the existing archive was preserved and registration completed separately.

Derivative-cap-only gust diagnostic: dirty0 contacts at 6.1 s, late1 at 19.0 s;
logged preintegration minima 0.402512/0.408085 m. The exact baseline/candidate
and runner are archived in logs/reliability_derivative_cap_1_6_coupled_20261007.
Baseline class methods match current root; its startup wrapper differs.
Candidate rejected. No wider lidar filter or clearance reduction is installed.
No accepted final source or 200-case qualification exists.

07 October later continuation:
Latest continuation: the 903-file arrival-anchor/framing candidate passes
field seed 1, all navigation checks, 816.3 s airborne, corridor minimum
0.758250277 m, red minimum 2.298071264 m, zero independent fixture contacts,
both corridors and actual connected disarm. Source/assets/archive verified.
Seed 2 is running against the SAME archive; seed 3 remains pending.
Archive SHA256: 9431676002ac84aabb134924689a945a19eadee0837822cec2e3f1c7331c18c2.
These are object-level navigation trials, without rendered/motor qualification.

The preceding scoped/fine source passed seeds 2 and 3 (800.8/881.4 s),
but seed 1 exceeded time at 915.3 s; it cannot be adopted. The camera-focus
source then failed seed 1 gate braking and contacted the board during RTL
at 825.24 s. Its legacy geometric contact checkbox passed incorrectly;
the unchanged run.json contact record and closed review explicitly reject
contact-free qualification. Earlier grade files remain preserved.
The real gate crossing regression fails before the measured-arrival anchor
fix, then 227 gate/fail-closed/router tests pass with the fix. Independent
headless contact grading fails five controls before correction; 20 contact
and campaign controls pass afterward. All fixture contacts must be supplied;
missing or malformed evidence cannot qualify an empty contact history.

Native contact coverage is also incomplete in earlier acceptance recordings:
evaluation_contacts.jsonl covers PAYLOAD contacts only. New passive sensors
cover each directly collidable CAD vehicle link without changing collision
geometry or mass; two structural tests pass. A normal-startup unarmed native
smoke is testing actual native topics and ground-contact canary recording.
No mission qualification is claimed for this smoke. Existing 22/22 split
guard result remains an unchanged legacy grade, not proof of new body-contact
qualification. Future final rendered runs must include vehicle contact truth.

The scoped escape root offline archive passed 1443 tests, 3 skipped, and all
syntax/configuration/frontend checks. Archive SHA256:
8f01ab5ca6fe9ae2572bae62f6e38a6998aab016075dfc1b5eac6eb6f37db70f.
Root has changed since that checkpoint (arrival braking and contact evidence);
a new full offline run is required. No accepted final source exists.

The recent 1 s empirical reserve gust diagnostic is rejected: dirty0 and
late1 both time out without traversal; late1 minimum clearance is 0.500754 m.
The dirty-calm regression also stalls (0.822993 m minimum). Original failed
launch guard logs are retained separately. No wider lidar filter, reduced
clearance, empirical recent-reserve policy or faster delay is installed.
Strong coupled gusts remain unresolved. All five final rendered acceptance
cases, corrected 200-case campaign and accepted-source report remain pending.

08 October reduced-scope instruction:
08 October reduced scope supersedes the original qualification target.
Strong-gust and artificially delayed-control work is deferred, unresolved,
and excluded; all existing failures remain archived. The original 200-case
campaign will not be claimed. Concrete weather filtering selects 120 of the
200 original world/preset/seed entries and excludes 80: mean wind >4 m/s
or gust >2 m/s, outside the existing moderate field preset. Exact selected
and excluded rows are in planned_campaign_scope.json. Feasibility auditing
may classify some selected entries without flight; such entries are not passes.

Normal mission startup now contains the camera-only clipped-bearing retry,
one bounded finer return sweep, measured-arrival gate braking, the native
zero-disturbance admission guard and independent native aircraft contact
grading. Aircraft geometry, mass, thin-obstacle filtering and clearance
thresholds remain unchanged. The contact recorder subscribes to actual
entity-scoped native channels, verifies publisher liveness, records skid
contacts and unsubscribes before teardown. The unarmed clean-shutdown smoke
passes with all seven vehicle channels, 25 native clock heartbeats and 258
contact rows; earlier topic and teardown failures are preserved.
Native contact grading requires a preflight skid-to-home-pad canary,
continuous publisher/clock coverage through flight, and no unexpected
vehicle contacts. Missing or malformed evidence fails qualification.

103 focused integration checks pass. Both ROS packages build and six installed
decision modules resolve to the exact root source; startup import hashes are
archived. The first reduced trial source c57104... inadvertently coupled
removal of the physical queue to an override of the controller timing model.
All three field seed trials failed (return/time, contacts in 1 and 2); they are
preserved, never qualification passes. V2 changes only the fixture setup:
physical extra queue 0 s, controller timing model unchanged at .4 s,
normal physical actuator response .6 s and computation budget .20 s.
The 909-file V2 archive SHA256 is
bc63e99f846ee8e3f712e8364ff22835855b7c992bd8d1b53e49ed06ad758966.
V2 field seeds 1/2/3 and the full native split acceptance are running in
parallel. No accepted final source exists. One final full offline suite,
all five rendered acceptances, the selected reduced campaign and final
accepted-source report remain pending; additional fixes will invalidate any
different-source passes. Detector rates from object-level trials are not
rendered perception qualification.
