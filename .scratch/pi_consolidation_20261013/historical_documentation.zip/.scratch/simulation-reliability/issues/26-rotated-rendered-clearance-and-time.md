# Rotated rendered search loses red margin and return search exceeds flight budget

Status: ready-for-agent
Resolution: failures archived; camera and timing diagnosis in progress
Parent: ../spec.md

The full rb_rotated calm seed 20261003 flight completes delivery and disarm but
passes only 20 of 22 checks. Flight time is 1149.9 s against 900 s. Restricted-zone
clearance is 1.1590944096 m against 1.50 m. Corridor clearance, actual motor-based
delivery, independent input audits, complete camera and source/runtime archives pass.

The first red-margin failure is SEARCH_QR at t=205.810, minimum at 206.640. Raw
RED arrives at 205.387; confirmed exclusions at 205.634. Camera inspection shows
the partially cropped white-bordered red board entering the image before it
survives the 0.50 m feature filter. Fresh 17 Hz detector delivery alone does not
qualify usable forward observation distance or stopping before that outer edge.
Test early partial-boundary evidence separately from persistent confirmed zones;
preserve red-QR and other decoy rejection. Do not use evaluation coordinates as input.

RETURN_GATE_SEARCH lasts 618.205 s. An early lettering sighting from the zone side
is discarded because its area-derived stand-off is outside the expanded zone.
The scratch observed-vantage candidate holds the measured camera vantage for the
following lidar alignment and preserves outside-vantage/clipped/outbound rejection.
Its component passes; full rendered qualification is still required. Explore route
ordering using the existing vantage set and measured observer, not hidden gate truth.

Evidence: logs/reliability_render_rb_rotated_s20261003_observation_repairs_20261007;
its source archive SHA-256 is bc1bd15bd1dbf65a9b8603b10fdd4cd3be42c900a91298d942fb59feb32d2df5.
flight_budget_review_20261007.json, red_clearance_review_20261007.json and
red_detector_timing_review_20261007.json preserve separate evaluation and sensor timing.
Split-corridor acceptance is active on unchanged producer source. Hardware is deferred.

## Direct continuation — 7 October

The camera-only partial-boundary candidate detects the visible cropped red and
connected white backing at capture 205.05 s, approximately 0.30 s before the
original usable red output. Replay now uses the frozen runtime 0.851919 rad
camera field of view and nearest capture-time FCU pose; the earlier nominal
60-degree and preceding-pose calibration reports remain separate. The replay
is not a flight pass or exact original callback-order reconstruction.
All 432 labelled controlled red-ink QR fixtures are rejected. They are image
unit fixtures, not native observations or delivery evidence. No candidate
exclusion has been supplied to a drone. Required next checks are actual stopping
margin, provisional-evidence lifetime, conflict handling and complete rendered
false-positive/mission trials.

The adjacent-vantage route candidate preserves the entire original viewpoint
multiset, outward headings and first observation, and deterministically reduces
geometric travel from 305.096 m to 97.188 m in the rotated example; the split
example reduces 211.357 m to 86.598 m. This ranks observations only: LegRouter
still checks every executed segment. Neither shorter geometric travel nor
the measured-vantage sighting component is rendered acceptance.

Evidence: logs/reliability_partial_red_boundary_replay_intrinsics_20261007.json,
logs/reliability_partial_red_qr_fixtures_20261007.json and
logs/reliability_return_vantage_order_candidate_20261007.json. Production
decision source is still frozen while the split rendering runs.


Latest rotated seed 20261003 closes 18/22 FAILED with 1070.1 s airborne
and 1.48 m minimum red clearance. Actual RTL landing/disarm and camera closure
are recorded. Operator requested the normal abort guard after 900 s had already
been irrecoverably exceeded; intervention is recorded in operator_recovery_20261007.json.
Return traversal, unexpected mode, time and red clearance remain failed.
Motor-priority delivery confirms after full retraction. Final source acceptance
is pending; this run cannot qualify the campaign.
