# Preserve sequential escape from overlapping observed exclusion margins

Status: ready-for-agent
Resolution: search deadlock fixed; field seed 2 completes navigation but exceeds 900 seconds
Parent: ../spec.md

Field seed 2 discarded 25 search waypoints without matching its target.
Saved onboard pose and 112 camera-derived cells reproduce the routing refusal.
The minimal reproducer has two overlapping 1.50 m inflated cells. The planner
leaves their nearest edges sequentially. The publication guard required its
first endpoint to equal both distinct nearest exits, rejecting every route.
Look-ahead must also preserve the current escape waypoint until it is reached.

Before repair: one failing regression, 113 passing related checks. Isolated
repair: 114 passing checks and original 112-cell replay accepted. Paint and
unrelated obstacles retain their segment checks. No simulator truth enters
the router. Production repair installed after rendered aircraft disarm.

Frozen 760-file physical field-2 rerun finds the target, traverses both
corridors and disarms. Independent corridor clearance 0.7301542117 m;
exclusion clearance 1.5108600253 m; zero contacts or fence breaches. Twelve
of thirteen navigation checks pass. Airborne 942.8 s exceeds the 900 s limit.
This is FAILED qualification, not a candidate adoption or rendered pass.

Source archive SHA256
`1ec8111ae448d5fb961d65cc05f6c6540a81464d2f2b673eeba58d05ae79d983`.
All source/assets/closed recordings verified under
`logs/reliability_search_escape_field2_navigation_20261007/closed_batch_review.json`.
Return alignment spends roughly 145 s on rescanning, relocation and orbit.
Its observation-derived stand-off and camera handover need diagnosis next.

Current integrated-source repeat closes 12/13 navigation checks, target found
and centered, both corridors and disarm, no contacts/fence breaches. Airborne
951.7 s exceeds 900; corridor 0.753871089 m and red 2.267071264 m. Return alignment
is now about 5 s; the remaining time failure is not the old 145 s alignment.

A separate red test reveals search braking cancels the nearest-edge escape
already certified by the router while inside an inflated margin. The braking
gate now uses the same fresh segment predicate; new paint still invalidates
and brakes. 125 related tests pass. The next field-2 repeat freezes 900 code
and asset files (archive e7c9bcc2e7199c6670667b1718a8426513a64de4b5fe4bf3b7c29261a0808c91).
Its outcome is pending. The earlier missing QR payload asset is recorded as
infrastructure failure before flight, not a control failure or qualification.

The 900-file braking-escape repeat closes FAILED: target found, both corridors,
connected disarm, zero contacts/fence breaches, corridor 0.753613072 m, red
2.222071264 m, airborne 1028.9 s. Battery-critical landing is preserved in the
mission outcome. Source/assets verified; no rendered camera/receipt recording
is claimed. Return alignment loses the inferred area-based stand-off again.

A separate oblique observer handoff candidate now repeats field2 from a 901-file
freeze (archive ac9efea016ca03a1b3ed79547d98eb9d14cc6cb7493e3eca7dcca9a39ef1393b).
Recorded observer (24,-6), area-based board (15.2,-17) makes the old approach
relocate over 10 m. The candidate preserves that admitted zone-side viewpoint
for the existing lidar alignment. Face-on placement and outside-observer
behavior remain unchanged in the component control tests. Not installed.


Latest closed tests: monotonic escape source passes 1442 tests, 3 skipped,
and all offline checks, verified against its unchanged 900-file archive.
Field seed2 finds the target at 601.70 simulated seconds (previous source
707.15) but fails return alignment and lands/disarms at 998.5 s airborne.
It has no obstacle contacts/fence breaches. Its 1.169191 m corridor minimum
does not qualify return traversal, which was not completed. Source/assets
and actual FCU disarm are verified; rendered cameras and motor delivery are
explicitly unqualified for this object-level trial.

Recorded-pose return projection corrected to the runtime 0.851919 rad HFOV:
all ten early alignment captures give zero geometrically admissible headings
on the 45-degree sweep, while the 15-degree sweep supplies admissible views.
The level camera misses the board vertically; a 20-degree look sees it.
The original 60-degree replay is retained as invalid runtime configuration,
not a qualification result. Geometry is only a detection precondition.
An isolated fine-framing candidate adds one bounded finer sweep, restoring
the look angle only above gate height, before physical relocation. It retains
the original lettering, freshness, range and lidar checks. Four component
controls pass. Its 901-file archive SHA256 is
dec801079383efa322d64caecc60da2850ead40253b8a40cb72725c27ae641df.
Field seed2 is active under logs/reliability_fine_return_framing_field_s2_navigation_20261007.
An initial launcher registration path error occurred after the valid freeze;
the existing archive was preserved and registration completed separately.

Derivative-cap-only gust diagnostic: dirty0 contacts at 6.1 s, late1 at 19.0 s;
logged preintegration minima 0.402512/0.408085 m. The exact baseline/candidate
and runner are archived in logs/reliability_derivative_cap_1_6_coupled_20261007.
Baseline class methods match current root; its startup wrapper differs.
Candidate rejected. No wider lidar filter or clearance reduction is installed.
No accepted final source or 200-case qualification exists.

07 October later continuation:
Latest continuation: the 903-file arrival-anchor/framing candidate passes
field seed 1, all navigation checks, 816.3 s airborne, corridor minimum
0.758250277 m, red minimum 2.298071264 m, zero independent fixture contacts,
both corridors and actual connected disarm. Source/assets/archive verified.
Seed 2 is running against the SAME archive; seed 3 remains pending.
Archive SHA256: 9431676002ac84aabb134924689a945a19eadee0837822cec2e3f1c7331c18c2.
These are object-level navigation trials, without rendered/motor qualification.

The preceding scoped/fine source passed seeds 2 and 3 (800.8/881.4 s),
but seed 1 exceeded time at 915.3 s; it cannot be adopted. The camera-focus
source then failed seed 1 gate braking and contacted the board during RTL
at 825.24 s. Its legacy geometric contact checkbox passed incorrectly;
the unchanged run.json contact record and closed review explicitly reject
contact-free qualification. Earlier grade files remain preserved.
The real gate crossing regression fails before the measured-arrival anchor
fix, then 227 gate/fail-closed/router tests pass with the fix. Independent
headless contact grading fails five controls before correction; 20 contact
and campaign controls pass afterward. All fixture contacts must be supplied;
missing or malformed evidence cannot qualify an empty contact history.

Native contact coverage is also incomplete in earlier acceptance recordings:
evaluation_contacts.jsonl covers PAYLOAD contacts only. New passive sensors
cover each directly collidable CAD vehicle link without changing collision
geometry or mass; two structural tests pass. A normal-startup unarmed native
smoke is testing actual native topics and ground-contact canary recording.
No mission qualification is claimed for this smoke. Existing 22/22 split
guard result remains an unchanged legacy grade, not proof of new body-contact
qualification. Future final rendered runs must include vehicle contact truth.

The scoped escape root offline archive passed 1443 tests, 3 skipped, and all
syntax/configuration/frontend checks. Archive SHA256:
8f01ab5ca6fe9ae2572bae62f6e38a6998aab016075dfc1b5eac6eb6f37db70f.
Root has changed since that checkpoint (arrival braking and contact evidence);
a new full offline run is required. No accepted final source exists.

The recent 1 s empirical reserve gust diagnostic is rejected: dirty0 and
late1 both time out without traversal; late1 minimum clearance is 0.500754 m.
The dirty-calm regression also stalls (0.822993 m minimum). Original failed
launch guard logs are retained separately. No wider lidar filter, reduced
clearance, empirical recent-reserve policy or faster delay is installed.
Strong coupled gusts remain unresolved. All five final rendered acceptance
cases, corrected 200-case campaign and accepted-source report remain pending.

08 October reduced-scope instruction:
08 October reduced scope supersedes the original qualification target.
Strong-gust and artificially delayed-control work is deferred, unresolved,
and excluded; all existing failures remain archived. The original 200-case
campaign will not be claimed. Concrete weather filtering selects 120 of the
200 original world/preset/seed entries and excludes 80: mean wind >4 m/s
or gust >2 m/s, outside the existing moderate field preset. Exact selected
and excluded rows are in planned_campaign_scope.json. Feasibility auditing
may classify some selected entries without flight; such entries are not passes.

Normal mission startup now contains the camera-only clipped-bearing retry,
one bounded finer return sweep, measured-arrival gate braking, the native
zero-disturbance admission guard and independent native aircraft contact
grading. Aircraft geometry, mass, thin-obstacle filtering and clearance
thresholds remain unchanged. The contact recorder subscribes to actual
entity-scoped native channels, verifies publisher liveness, records skid
contacts and unsubscribes before teardown. The unarmed clean-shutdown smoke
passes with all seven vehicle channels, 25 native clock heartbeats and 258
contact rows; earlier topic and teardown failures are preserved.
Native contact grading requires a preflight skid-to-home-pad canary,
continuous publisher/clock coverage through flight, and no unexpected
vehicle contacts. Missing or malformed evidence fails qualification.

103 focused integration checks pass. Both ROS packages build and six installed
decision modules resolve to the exact root source; startup import hashes are
archived. The first reduced trial source c57104... inadvertently coupled
removal of the physical queue to an override of the controller timing model.
All three field seed trials failed (return/time, contacts in 1 and 2); they are
preserved, never qualification passes. V2 changes only the fixture setup:
physical extra queue 0 s, controller timing model unchanged at .4 s,
normal physical actuator response .6 s and computation budget .20 s.
The 909-file V2 archive SHA256 is
bc63e99f846ee8e3f712e8364ff22835855b7c992bd8d1b53e49ed06ad758966.
V2 field seeds 1/2/3 and the full native split acceptance are running in
parallel. No accepted final source exists. One final full offline suite,
all five rendered acceptances, the selected reduced campaign and final
accepted-source report remain pending; additional fixes will invalidate any
different-source passes. Detector rates from object-level trials are not
rendered perception qualification.

08 October continuation: V13 search braking consumes actual FCU velocity
captures rather than mission-timer aliases, preserving .10 m/s and three
fresh post-command samples and intervening-motion resets. V14 retains an
already acknowledged lower cap for small speed increases; decreases require
immediate acknowledgement. Real red controls and 154 focused green checks
are archived. V14 QR was found at 676.4 s, but return/time failed. V15 is under
trial; no accepted source and no final offline/campaign claim.

08 October continuation: V16 certifies active segments against each original
observed exclusion inflated by the unchanged 1.50 m clearance before merged
routing boxes can reject a physically safe segment. Real captured-command and
L-corner red controls failed before the fix; actual-margin starts, paint
crossings and unsafe margins still fail closed. All five targeted navigation
cases passed on V16. V17 retains identical search/controller/perception source;
its sole production change is passive winch-arrival recording. Exact-source
targeted navigation/offline checks are active; rendered acceptance and the
reduced campaign remain pending. No source has been accepted.

08 October V19 continuation: V18 fields 1/2/3 and retained mild random 4
passed navigation. Mild random 3 still failed during return; its failed grade
and actual disarm remain preserved. V19 changes only return framing from V18;
the observed-exclusion certificate, QR search, controller timing, actuator
response and lidar filter are unchanged. All 11 normal-startup module hashes
match the new freeze. All five same-source targeted cases are running with
two workers before the final offline suite and native/campaign gates.

08 October V20 continuation: V19 passed QR search and return/time/clearance
checks for every targeted case. Field 2 and mild random 3 failed only home
landing. V20 integrates the landing leaf's computed acquisition altitude
into GotoHome. The search/controller/perception source and all timing/clearance
thresholds are unchanged. 230 focused checks pass, and all 11 startup imports
match the freeze. No accepted source, native acceptance or campaign pass yet.

08 October V21 continuation: V20 fields 1/2/3 and mild random 4 passed navigation; mild random 3 still exceeded 900 seconds. All actually disarmed with zero contacts/fence breaches. V21 recovers the observed return-search delay by starting the existing bounded guarded orbit after three stable fresh whole-region captures. Actual-leaf red and 124 focused green checks are archived, and all 11 normal-startup imports match the freeze. Five same-source trials are active. No final offline/native/campaign acceptance yet.

08 October V22 continuation: V21 early-orbit candidate rejected after retained failures. Four cases actually disarmed; mild random 4 simulator ended with last telemetry armed, so final disarm is unverified. V22 retains the full initial search sweep before using stable whole-region observations for an existing guarded orbit, and pauses transient gate capture gaps with unchanged .30 s freshness/.08 m/s braking thresholds. Actual-leaf reds and 287 focused greens archived; 11 startup imports match. Five same-source trials active; final acceptance remains open.

08 October V23 continuation: V22 field seeds 1/2/3 actually disarmed; field 2 passed navigation with precise landing. Mild random 3 failed time/return, preserving actual RTL/disarm. Its 41.70 m high return leg took 70.64 s at retained .60 m/s search cap. The actual built-tree lease regression failed. V23 restores a bounded prior navigation cap only after high-altitude/nadir/fresh-pose prerequisites and FCU acknowledgement. 272 focused checks and 11 startup imports match the freeze. New trials queued after final V22 disarm; no native/campaign acceptance yet.

08 October V24 continuation: V23 closed 3/5 navigation passes; field 3 and mild random 3 time failures preserved, all actually disarmed and no contacts/fence breaches. High return speed restoration shortened transit to about 11 s but camera framing still failed. The actual FindReturnBanner leaf reproduced FORWARD bottom crop/BANNER top crop oscillation. V24 uses at most three camera-only bracket angles via the existing numeric protocol, validates measured settlement, and still rejects clipped range. 314 focused checks and 11 startup imports match the freeze. Five same-source trials active; no final offline/native/campaign acceptance yet.

08 October V25: V24 closed four navigation passes; all actually disarmed and zero contacts/fence breaches. Mild random 3 actual clearance 0.6948520402727778 m remains FAIL. V25 fixes actual premature clipped-backoff transit cancellation, with 297 focused passes and 11 normal-startup imports matching 931-file freeze. Two isolated corridor probes passed but did not reproduce runtime; no speculative clearance change. Five V25 targeted trials active. No accepted source, native final acceptance or campaign qualification. Strong/delayed failures unresolved and excluded.

08 October V26: V25 closed four navigation passes; all actually disarmed and zero contacts/fence breaches. Mild random 3 QR found, return search 190.85 s, corridor 0.6849396857248734 m/time/mode FAIL preserved. Actual leaf reproduced side-crop retry consuming centred vertical framing. Actual frozen V25 certificate reproduced .6990529898953362 m clearance with modest .06 m/s helpful response error, normal .20 s budget/.6 s response/zero queue. V26 separates framing classes and enforces both disturbance and zero-disturbance predictions. 122 integrated and 24 normal navigation/timing checks pass; 11 normal-startup imports match 933-file freeze. Five two-worker targeted trials active; no accepted source or reduced qualification yet. Strong/delayed failures unresolved and excluded.

08 October V27: V26 field 2 passed navigation with .7318246284671641 m corridor clearance and actual disarm. Mild random 3 QR found but return handover failed; automatic RTL and actual disarm preserved. Actual built mission red reproduced generic .60 m climb completing below next .30 m guard. V27 specific return climb uses .20 m tolerance, retaining 10 m height and all prerequisites. 226 focused checks and 11 startup imports match 934-file freeze. Priority V27 trial uses safely closed domain 41 while second worker waits for V26 to close domain 40. Five passes still required; failed batches stop unflown queue and never interrupt armed flights. No accepted source or campaign qualification.

08 October V28: V26 closed four navigation passes/one failed altitude handover. V27 closed field 2 navigation PASS .7354888194818544 m corridor clearance, mild random 3 search/time FAIL; both actual disarm, zero contact/fence; three unflown cancelled. Original failure reviews retained. Actual orbit search seam RED showed camera tilt and exhausted second look leaking to later vantages. V28 restarts each guarded orbit view level with its own second look/fresh dwell; altitude, speed, guards and thresholds unchanged. 93 focused PASS, 11 startup imports, 935-file final freeze. All targeted/native/campaign qualification remains pending.

08 October V29: V28 field 2/3 navigation PASS and actual disarm; mild random 3 return search improved to 15.15 s but gate-crossing timeout/contact FAIL, .4034108728140693 m corridor clearance; two wall contacts, RTL and actual disarm retained; two unflown cancelled. Actual gate/normal physics/streamed guard regression reproduced crossing contact. Fresh signed FCU displacement confirmation retains distance, heading, tolerance, freshness, ACKs and braking limits. 20.8 s replay PASS .9145067912135068 m zero contact; 91 focused checks and 11 startup hashes match 938-file freeze. Rejected settle-window/damping probes archived, not adopted. Five targeted cases rerun; all native/campaign qualification pending.


## V32 hazard-hold checkpoint

V31 field 2/3 passed navigation and disarmed. Mild random 3 passed corridor at .7372377792461882 m, but failed restricted-zone clearance at 1.2139113263915782 m. Original failure is retained. V32 revalidates latched search anchors against new observed paint and certifies escape through the existing router, stopping if blocked. 99 focused checks pass; whole-flight and rendered acceptance remain pending. Issue remains open.
