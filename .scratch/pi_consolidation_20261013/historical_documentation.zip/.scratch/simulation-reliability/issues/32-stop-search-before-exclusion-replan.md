# Brake the active search segment before replacing an unsafe route

Status: ready-for-agent
Resolution: actual search leaf passes 8/8 and broader checks pass 130/130; rendered integration running
Parent: ../spec.md

The search leaf revalidates exclusions but replans and flies in the same
tick. The new candidate cancels a streamed segment that becomes unsafe,
latches a measured position hold, and waits for three distinct fresh FCU
velocity captures below 0.10 m/s. It then replans from the measured aircraft
position and resumes on a later tick. The hold target does not follow a
still-moving aircraft. Missing, stale, future and nonfinite motion samples
keep the stage stopped. The 1.50 m exclusion clearance is unchanged.

The regression executes the real LawnmowerSearch.update method and checks
emitted flight commands. Before repair, 7 fail and 1 passes. With the
candidate, 8 pass. Evidence and exact methods are archived under
logs/reliability_search_braking_before_20261007 and
logs/reliability_search_braking_after_20261007. The candidate remains in
.scratch/simulation-reliability/search_braking_candidate_20261007.py.

Earlier partial camera-boundary evidence still needs integration and
qualification. The clipped solid red and connected white backing are
provisional obstacles, never persistent confirmed zones or simulator
coordinates. Detector and braking changes require a full rendered rotated
repeat. No flight pass is claimed by these scripted motion captures.

The partial red camera callback and mission consumer pass 8/8. Its corrected
before fixture fails 2 and passes 6. The first fixture used a 1 ns timestamp
increment at a large epoch, which rounded to the same float capture and was
correctly dropped. That fixture error is preserved; the corrected 1 ms
distinct capture checks the intended missing-pose path. The candidate also
passes 94 broader perception/geofence/timing checks and rejects all 432
labelled red-QR fixtures through the actual camera callback. Provisional
evidence never credits the persistent red grid.
