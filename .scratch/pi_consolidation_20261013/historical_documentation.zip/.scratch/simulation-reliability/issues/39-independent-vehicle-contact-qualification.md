# Independent vehicle contact qualification
Status: ready-for-agent
Type: bug
Parent: ../spec.md

The headless board-contact fixture can pass the geometric no-contact checkbox.
Native acceptance currently records payload-only contacts, not vehicle impacts.
Require independent contacts and complete live vehicle channels; preserve all
previous grade files and failures. No final campaign until corrected targeted
acceptance passes on the same source.

## Comments
07 October: headless grading now fails absent/malformed/nonempty fixture contact
evidence. Five red controls, then 20 green contact/campaign checks. The recorded
clipped-focus field 1 board contact at 825.24 s is preserved despite its legacy
checkbox. CAD passive contact sensors have two passing structural tests; actual
native recording smoke and grading integration are in progress.

08 October reduced-scope instruction:
08 October reduced scope supersedes the original qualification target.
Strong-gust and artificially delayed-control work is deferred, unresolved,
and excluded; all existing failures remain archived. The original 200-case
campaign will not be claimed. Concrete weather filtering selects 120 of the
200 original world/preset/seed entries and excludes 80: mean wind >4 m/s
or gust >2 m/s, outside the existing moderate field preset. Exact selected
and excluded rows are in planned_campaign_scope.json. Feasibility auditing
may classify some selected entries without flight; such entries are not passes.

Normal mission startup now contains the camera-only clipped-bearing retry,
one bounded finer return sweep, measured-arrival gate braking, the native
zero-disturbance admission guard and independent native aircraft contact
grading. Aircraft geometry, mass, thin-obstacle filtering and clearance
thresholds remain unchanged. The contact recorder subscribes to actual
entity-scoped native channels, verifies publisher liveness, records skid
contacts and unsubscribes before teardown. The unarmed clean-shutdown smoke
passes with all seven vehicle channels, 25 native clock heartbeats and 258
contact rows; earlier topic and teardown failures are preserved.
Native contact grading requires a preflight skid-to-home-pad canary,
continuous publisher/clock coverage through flight, and no unexpected
vehicle contacts. Missing or malformed evidence fails qualification.

103 focused integration checks pass. Both ROS packages build and six installed
decision modules resolve to the exact root source; startup import hashes are
archived. The first reduced trial source c57104... inadvertently coupled
removal of the physical queue to an override of the controller timing model.
All three field seed trials failed (return/time, contacts in 1 and 2); they are
preserved, never qualification passes. V2 changes only the fixture setup:
physical extra queue 0 s, controller timing model unchanged at .4 s,
normal physical actuator response .6 s and computation budget .20 s.
The 909-file V2 archive SHA256 is
bc63e99f846ee8e3f712e8364ff22835855b7c992bd8d1b53e49ed06ad758966.
V2 field seeds 1/2/3 and the full native split acceptance are running in
parallel. No accepted final source exists. One final full offline suite,
all five rendered acceptances, the selected reduced campaign and final
accepted-source report remain pending; additional fixes will invalidate any
different-source passes. Detector rates from object-level trials are not
rendered perception qualification.

08 October native split evidence: 21/22 FAIL retained, 215 deployed-hook delivery-floor contact pairs. Added contact-point and fresh winch-receipt recording with narrowly bounded target-surface classification. 23 dedicated contact checks pass. Requires a new full rendered recording; no historical run is promoted.

08 October continuation: V3 native split remains 21/22 FAIL (215 deployed-jaw
floor contact pairs); its missing contact-position/fresh-winch measurements
cannot be retroactively supplied. The integrated recorder now includes actual
native contact positions and fresh winch receipts, and classification is
limited to intended deployed-hook contact on the delivery target floor with
fresh independent elevated-aircraft and onboard evidence. New full rendered
acceptance remains pending; no previous failed run is counted as a pass.

08 October V16/V17 continuation: V16 split was safely interrupted after 18
deployed-hook target-floor contacts failed only the unchanged .30 s winch
freshness requirement. Actual connected disarm and the original 17/22 grade,
recordings and per-artifact hashes are closed in
logs/reliability_reduced_scope_v16_source_20261008/rendered_split_failure_closed_review.json.
All measured contact positions, independent elevated-aircraft poses, mission
phases and winch states passed their existing requirements. The 5 Hz recorder
had aliased newer actual winch receipts until its next video snapshot. The real
recording callback plus unchanged contact grader reproduced the failure.
V17 journals every winch arrival immediately, preserving the actual callback
stamp and full contemporaneous onboard state. Camera/video cadence, controller,
perception, contact grader and every threshold remain unchanged. Nine new seam
tests and 62 focused evidence checks pass, including stale/future arrival and
unsafe-contact rejection. Exact-source targeted/offline checks are active;
new rendered acceptance remains pending. The post-disarm native contact
recorder pybind11 GIL shutdown abort is preserved and remains unresolved.

08 October V19 continuation: The passive arrival journal and unchanged contact
grader are retained. V19's normal-startup imports match its freeze; 98 further
integrated component checks include winch-arrival, LAND position control and
native evidence controls. Five full native rendered acceptances with actual
motor delivery, aircraft-contact coverage and disarm are still required.
Older native failures remain failed and are not reused as new qualification.
