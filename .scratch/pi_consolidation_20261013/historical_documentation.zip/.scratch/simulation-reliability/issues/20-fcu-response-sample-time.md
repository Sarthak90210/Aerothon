# Compare predicted response and FCU velocity at the same time

Status: ready-for-agent
Parent: ../spec.md
Resolution: independent timestamp bug fixed; rendered return validation pending

The bannerfix full standard run failed return at x=13.19, with independent
clearance 0.684245767 m. The planner's origin hold is correct once its reserved
clearance is unavailable. LocalPlanner, minimum clearance and reserve were
not changed. Native truth is postflight evaluation only.

The observer advanced its expected response to controller time while comparing
it with velocity measured at an earlier FCU header timestamp. A calm known
plant with a 50 ms receipt lag invented up to 0.125073 m/s of wind. The three
captured-source regressions fail in 0.89 s against archived methods. The new
measurement-time alignment passes 31 related checks in 4.94 s, and avoidance
rebuilt in 29.3 s. Source and tests are now frozen for the full offline suite.

Recorded receipt ages during the offending command burst were 17-24 ms.
Bounded trace comparison attributes peak 0.02406 m/s and RMS 0.00663 m/s to
timestamp mismatch, while total response residual RMS remains about 0.07 m/s.
Thus the timestamp fix must not be described as resolving the whole failure.
The old response-fit grid reached its bounds on a trace including gate handover;
it does not justify blind response-time or transport-delay tuning.

Require a focused rendered repeat from this failed run's FCU entry, then both
full current-source standard acceptance seeds. No broader campaign gate opens
until those pass. Complete recordings through disarm and separate native truth
remain mandatory. The detached launcher has harmless lifecycle tests only.

Evidence: return_observer_diagnosis_20261006.md and the bounded comparison
JSON in this scratch directory; logs/reliability_fcu_alignment_related_20261006.log
and logs/reliability_fcu_alignment_archived_red_20261006.log.
