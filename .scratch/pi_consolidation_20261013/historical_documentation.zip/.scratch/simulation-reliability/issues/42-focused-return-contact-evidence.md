# Focused native return completes but fails independent contact closure

Status: ready-for-agent
Parent: ../spec.md

Resolved on V40 by a repeat into a new directory, 2026-10-10. The V39 failure
is preserved. The rest of the V40 qualification is still unfinished, so the
label stays open until the final closure runs.

## Original failure, preserved

The V39 split moving-handover return trial completed all seven focused checks
at 0.7582866549316181 m minimum clearance, traversed the return lane, and
recorded connected FCU disarm at capture stamp 150.345. Its separate contact
closure failed with `contact_free=false` and 6,805 unexpected records:

- 6,566 skid_1/payload records at 47.328-63.994 s, all before first arm at 67.4
- 126 skid_0/ground and 113 skid_1/ground records at 146.67-151.241 s

`logs/reliability_reduced_v39_focused_split_s20261003_20261009` keeps its
original grade, raw events and missing closure. Nothing was reclassified.

## Established cause

Full classification with timestamped truth and telemetry:
`logs/focused_contact_diagnosis_20261010.json`
(`.scratch/simulation-reliability/diagnose_focused_landing_contacts_20261010.py`,
which reads the preserved run and writes nothing into it).

1. **The unloaded scene carried the cargo on the airframe.** `build_cad_vehicle`
   omits the DetachableJoint when `AEROTHON_PAYLOAD_FIXTURE=unloaded`, but the
   world still spawned `aerothon_payload` 0.125 m under the airframe centre.
   Unsupported, it fell the 2 cm onto the pad and came to rest touching
   `skid_1`, which also slowly pushed the parked aircraft 0.27 m. A fixture
   placement fault, not a flight hazard: no contact occurred above 0.45 m and
   none occurred after arming.
2. **The landing rule only knew about home.** `normal_ground` required the
   aircraft within 1 m of `home_world`. This focused trial deliberately omits
   the return home and lands in place where the return lane ends, at
   (25.18, -27.23) against home (-2, 2), so its touchdown could not be
   accepted. Independent truth shows a 0.49 m/s descent, 0.04 deg of tilt and
   rest from 146.70 s, with FCU mode LAND throughout: a landing, not a strike.

## Correction, V40

Archive `956fadafef24af84b9c047ac87004a273bf14bfebd115def032fdc9a67b3d52e`,
951 files; all 12 flown decision modules byte-identical to V39
(`logs/reliability_reduced_scope_v40_source_20261010/provenance.json`).

- `scripts/world_spec.py`, `scripts/materialize_world.py`: an unloaded fixture
  parks the cargo 1.2 m from the spawn, on the pad and clear of the widest
  airframe collider (0.363 m reach). Loaded placement is unchanged.
- `sim/corridor_trial.py`: the trial writes `landing_contract.json` at its own
  LAND command, from the fresh onboard FCU local position. A stale or
  non-finite pose records the failure instead of an anchor.
- `sim/native_contact_evidence.py`: a declared land-in-place accepts skid
  contact with the pad or ground when the contact is at or after the commanded
  stamp, fresh independent truth puts the aircraft within the declared radius
  and at or below 0.45 m, the touchdown is at most 1 m/s and 10 deg off level,
  and fresh FCU telemetry reports LAND. The home rule, every other collider
  and surface, the canary, the seven channels, continuous coverage and the
  0.70 m and 1.50 m thresholds are unchanged. Accepted landing contacts are
  counted as `declared_landing_pairs`, never dropped from the record.

Replayed over the preserved V39 evidence, the corrected grader reproduces the
original 6,805 unexpected records with no contract, and with the contract
accepts only the 239 landing records while still flagging all 6,566 payload
records. The payload records needed the scene fix, not a grading change.

## Repeat result, V40

`logs/reliability_reduced_v40_focused_split_s20261003_20261010`

- Seven focused checks pass; minimum corridor clearance 0.730937743964665 m
- Connected FCU disarm at capture stamp 130.785
- Independent contacts: valid, seven channels, canary, **0 unexpected**
- 141 declared-landing pairs; 530 allowed ground/grip pairs
- Zero skid/payload contacts recorded at any time; parked separation 1.2 m
- `focused_source_closed_review.json` written

## Comments

This is focused evidence only. Search, delivery, loaded payload behaviour and
the return home are still intentionally omitted, and the full-mission grader
still fails for this trial by design. The five full rendered acceptances and
the 96-flight campaign remain required before any qualification claim.
