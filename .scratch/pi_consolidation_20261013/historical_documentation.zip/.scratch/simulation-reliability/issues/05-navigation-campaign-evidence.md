# Repeat the simulation matrix after targeted acceptance

Status: ready-for-agent
Resolution: both current-source standard acceptances and full suite passed; coupled gust repair pending
Parent: ../spec.md

Both earlier standard calm runs passed all 22 checks on 2026-10-06:
`logs/reliability_render_my_world_s20261003_retry4_20261006/` and
`logs/reliability_render_my_world_s1001_20261006/`. Their production source
manifests match. Both exact source archives and runtime assets are verified.
These passes qualify that archived source. Subsequent controller and banner
changes require a new source-matched pair before the matrix. The receipt-model
seed 20261003 run passed 21/22 checks but failed the unchanged 900 s flight
limit at 965.0 s. The later bannerfix run reported return-corridor STUCK and
its recording stopped while the last FCU state was still armed. Final grading
passes 16/22 checks, with native corridor minimum 0.684245767 m and incomplete
landing/disarm evidence. Neither run opens the campaign gate. The full offline
suite must also be repeated after
the latest production changes. Known coupled delay/gust failures remain open
and must be reported rather than omitted.

Run seeds 1-5 for every repository world fixture with calm, field, worst
and random conditions. Classify invalid and geometrically infeasible worlds
separately and preserve their hashes. Report all failures, including full
delivery grading failures even when navigation itself passes.

Use `sim/run_navigation_campaign.py` after both standard rendered acceptance
summaries contain `acceptance_pass: true`. Retain per-run source manifests,
world/configuration, onboard telemetry and commands, separate evaluation
truth trajectories and full/navigation grades. The headless fixture has no
rendered images or measured motor signal, so it cannot qualify either.
Its navigation-only entry point explicitly omits the delivery leaf, keeps
the hook stowed and marks delivery unconfirmed. This is a navigation trial,
not a full production mission pass. Full delivery grading failures remain
recorded alongside the navigation grade.

Repeat rendered acceptance on standard, shipped, rotated and split-corridor
worlds. Retain complete recordings through disarm and every independent grade.

07 October gate correction: two standard passes alone no longer unlock the
campaign. Five full rendered runs are mandatory: standard 20261003 and 1001,
plus shipped, rotated and split 20261003. All 22 checks, full completion,
motor-qualified delivery, disarm, capture/clock input audits and identical
current code/launch/fixture/assets must pass. Added or changed files invalidate
the prior source freeze. The shared recorder now includes QR payload text and
vehicle/image assets. Fourteen gate regressions pass. Campaign remains pending.
