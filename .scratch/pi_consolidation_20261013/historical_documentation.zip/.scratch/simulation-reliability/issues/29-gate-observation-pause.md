# Recover brief observation gaps while holding the gate approach

Status: ready-for-agent
Resolution: field seed 5 traverses safely; mission fails the unchanged time limit
Parent: ../spec.md

The expanded scan-pose batch's field seed 5 aborts at GateAdvance with
unavailable fresh pose, velocity or lidar observations. It disarms, but fails
outbound traversal, return traversal and expected-mode checks.

An isolated gate-only candidate keeps the existing stop-anchor behaviour and
allows up to one second for observations to recover. It does not execute
gate movement, restore speed or hand over to corridor velocity control while
observations are stale. A gap resets the distinct settling dwell. Persistent
loss, service rejection and the original 60-second gate timeout still fail.

Five focused checks pass for the exact inline implementation. The original
12 gate interface checks pass separately. A frozen field seed 5 trial is
active in logs/reliability_gate_pause_navigation_seed5_20261007. Source archive
SHA bff95f7354418d3ba4b8ce3f2d22e29f991cff945ad9a20b0e53b30e8530cec0
is verified. The candidate excludes the buffered scan change and preserves
the physical command delay, response, gate speed and clearance limits.

A physical/full mission pass remains required. No production adoption,
rendered perception, motor-delivery or hardware qualification is claimed.

## Comments

Field seed 5 closes through disarm with both corridors traversed, 0.7333189262 m
minimum clearance and no contacts. Airborne time 917.2 s fails the unchanged
900 s limit. The gate freshness abort does not recur, but this is a failing
trial. Exact source, assets, observations, commands and separate evaluation
truth are verified in closed_trial_review.json. Its 993 control records include
247 capture-time pose faults. The separate combined buffer/pause candidate
will be checked before retesting this and the other preserved failures.
