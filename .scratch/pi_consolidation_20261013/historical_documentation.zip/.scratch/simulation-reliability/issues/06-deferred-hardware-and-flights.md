# Hardware qualification and staged flights

Status: ready-for-human
Resolution: explicitly deferred; records prepared, nothing qualified
Parent: ../spec.md

The user selected simulation only. No physical qualification or flight is
authorized by the simulation results. The bench and flight evidence record
is `docs/HARDWARE_QUALIFICATION_RECORD.md`.

Later checks require connected devices, measured wiring, actuator rates
and orientations, and props-off electrical/actuator checks. Review each
flight stage before advancing from hover to a gate, outbound corridor,
return corridor, delivery and the full mission. Motor calibration must use
real loaded and unloaded hover evidence. The existing claw is unchanged.
