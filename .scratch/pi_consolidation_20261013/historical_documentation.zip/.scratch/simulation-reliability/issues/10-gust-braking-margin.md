# Gusts can exceed the certified hold margin in the split corridor

Status: ready-for-agent
Resolution: changing-disturbance certification implemented; 117 broad checks pass, full suite and fresh rendered qualification pending
Parent: ../spec.md

2026-10-06: current full suite reproduced both original behavior failures,
with 1305 passes, 12 failures and 3 skips. Ten failures were the old yaw
fixture's invalid zero radius; its unchanged assertions now pass. All syntax,
XML/YAML, type-check and frontend build checks passed. Raw full report:
`logs/reliability_full_after_fixture_20261006.log`.

The minimized dirty seed 0 fails in 314 steps at contact. The late-scan seed 1
traverses with only 0.630411806 m clearance. Their traces show conservative
lidar and measured incoming drift. Forecast compensation was being certified
against constant disturbance, rejected, and eventually replaced by raw zero.
A two-test real-publication regression first failed the safe forecast case
with 89 other checks passing. Certification now includes the measured trend
through the command/response interval and retains the entire braking tail
and full clearance checks. No sensor values or clearance limits were changed.

103 related checks pass in 6.15 s. Minimized dirty seed 0 now passes with
0.778495053 m clearance, late-scan seed 1 with 0.758094997 m. The full
geometry/slalom/stress/delay selection passes all 117 checks in 402.02 s:
`logs/reliability_changing_wind_broad_20261006.log`. These existing wind
fixtures use immediate velocity transport; coupled 0.4 s physical-delay
gust probes and the full offline suite are next.
This changes drone avoidance software after the two standard passes, so
fresh rendered acceptance is required before claiming current qualification.

## Evidence

After mounting registration, strict compensated hold checks, certified current
wind cancellation and active braking, the combined geometry/slalom/stress
selection ran 100 passing checks and two failures. The dirty-lidar gust case
contacted an obstacle. The late-scan gust case traversed but reached only
0.60605 m minimum clearance. Neither result qualifies at 0.70 m.
Raw evidence: `logs/reliability_braking_bound_final.log`.

The braking horizon includes the response tail and limits predicted braking
deceleration to the declared 0.5 m/s². These individual regressions failed
before their fixes. Do not restore a short horizon or unchecked hold to make
the stress suite pass. Do not reduce the full clearance requirement.

## Next work

Verify the saved calm standard return failure in a separate rendered trial.
Then retain and minimize these weather failures. Determine whether earlier
travel limiting or improved observed velocity/disturbance assessment can
maintain margin before hold certification becomes impossible. Keep measured
clearance failures separate from geometrically infeasible course fixtures.

This issue remains open before broader reliability qualification. Hardware
response rates, lidar uncertainty and environmental limits remain unqualified.

## Comments

2026-10-06 latest pre-delay run: 107 passes and two failures in
`logs/reliability_connected_mount_final_regression.log`. Dirty gust lidar
contacted a surface; late-scan gust minimum was 0.630411806 m. These remain
failures. The calm rendered retry also failed at 0.444372 m, with onboard
evidence of delayed command response driving compensation oscillation.
Delay-aware regression and original gust reruns are in progress. No narrower
clearance or shorter braking horizon is allowed.

2026-10-06: A minimized masked-lidar regression fails before component-wise
braking is added. Whole-vector braking can predict reverse movement in the
masked rear sector, even when a lateral-only brake is fully observed. Each
candidate now receives the same complete trajectory and deceleration check.
All 82 geometry/registration/clearance checks pass in
`logs/reliability_lateral_braking_contract.log`. Stress rerun pending.
