# Include transmitted yaw in corridor motion certification

Status: ready-for-agent
Resolution: receipt and queued-yaw regressions pass; rendered validation pending
Parent: ../spec.md

The controller used heading at transmission to predict a delayed body packet.
ArduPilot converts the body velocity once at receipt. The observer now uses
observed past arrival heading; the motion certificate forecasts future receipt
heading using FCU heading history and already transmitted yaw packets. Stale
stops preserve those packets and their heading basis. Unavailable braking
stops newly issued translation and yaw. Full clearance and reserve are unchanged.

The receipt regression fails on the exact archived publication method in
0.38 s. Five receipt, observer, queued-yaw and stale-stop tests pass in 2.43 s.
The 61-test broad controller selection passes in 394.26 s. After matching
physical test conversion and yaw transport to the installed firmware, 34
selected checks pass, 9 deselected, in 60.68 s and avoidance rebuilds in 17.3 s.

The focused rendered repeat is running in
logs/reliability_render_return_receipt_model_20261006. This does not yet prove
the rendered STUCK failure is resolved. Corrected-physics delayed-gust probes
still contact at 6.05/7.85 s under issue 15. No hardware qualification is claimed.

## Comments

The first continuous-rotation prototype regressed dirty-gust clearance,
56 passed and 1 failed. It was corrected after reading the installed ArduPilot
GCS_MAVLink_Copter.cpp handler: body_to_earth2D converts each velocity once at
receipt. The corrected receipt regression fails on the exact archived method
in 0.38 s and passes after in 2.74 s. The earlier continuous-turn interpretation
is superseded, not a firmware claim.

The observer now applies observed arrival heading to previously transmitted
body packets. Future heading uses observed FCU heading rate and already queued
yaw commands. Stale stops preserve translation, heading basis and yaw packets
already sent. Unavailable braking stops both newly issued translation and yaw.
Five publication/observer/queued-yaw tests passed in 2.43 s. The 61-test broad
selection passed in 394.26 s and four packages rebuilt in 40.1 s, before the
physical fixture correction described next.

The headless body/local frame regressions failed 2/7 before and passed 7/7 in
1.64 s after fixing conversion at receipt. The corridor physical fixture now
queues yaw with velocity and likewise converts each packet at receipt. Related
focus checks and an avoidance rebuild passed. A focused rendered rerun follows.
The corrected delayed dirty-gust fixture still contacts at 6.05 s; issue 15
remains open. No source, world or clearance changes are hidden in this result.
