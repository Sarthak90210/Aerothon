# Deployment transients should not spend release attempts

Status: ready-for-agent
Resolution: implemented; full rendered verification pending
Parent: ../spec.md

The focused rendered delivery passed on attempt 2, but a single deployment
effort transient stopped payout at about 0.54 m. Stable loaded evidence then
returned. The observer waited 15 s and consumed attempt 1 despite never
inferring touchdown or attempting release.

A minimized regression fails before the fix. Ten distinct qualified loaded
samples spanning at least one second now clear that unconfirmed candidate
and resume lowering. This does not infer touchdown or detachment. Repeated
samples cannot clear it. Actual release-probe retries still count toward the
three-attempt full-stow/unconfirmed-continuation policy. The overall time
budget and frozen motor threshold are unchanged.

## Validation

`logs/reliability_delivery_false_candidate_before_fix_20261006.log`: failed.
`logs/reliability_delivery_candidate_recovery_20261006.log`: 199 checks passed.
The new full standard seed-20261003 flight must verify rendered behaviour.

Full standard retry 3 completed motor-priority delivery on attempt 1. It
used the provisional short-probe branch, then stable unloaded hover qualified
touchdown and release after full estimated stow. No early candidate-clear
event was recorded, so that branch remains covered by its focused
regressions rather than a claim of rendered branch coverage. Overall
acceptance failed only the flight time limit.
