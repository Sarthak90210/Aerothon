# Provisional motor unloading and retry observation windows

Status: ready-for-agent
Resolution: open
Parent: ../spec.md

## Evidence

In standard calm seed-20261003 retry 2, independent native contact occurred
at 663.653 s. FCU observations after contact were not stable enough to qualify
unloaded hover. The aircraft continued payout while the claw contacted the
ground. This correlation does not establish contact force or prove a cause.
Expired telemetry timers then consumed attempts 2 and 3 within 0.4 s.
The mission continued only after complete estimated stow, marked unconfirmed.

## Changes

Each retry gets a fresh telemetry and camera observation window. Sustained
fresh provisional motor unloading near estimated reach can command a short
0.25 m release probe. Unstable observations cannot confirm touchdown,
detachment or success. The frozen motor calibration and qualified stable
hover checks remain necessary after the probe and after full estimated stow.
Stale telemetry stops the provisional probe. Returned load causes a retry.

## Validation

Two retry-window tests failed before the timer fix. Four probe tests include
stale telemetry, midair unloading, returned load and withheld confirmation
during unstable hover. The full delivery selection passed 197 checks in
`logs/reliability_delivery_probe_complete_20261006.log`.

Rendered hover/drop qualification is pending. Full rendered mission acceptance
is also pending. Simulator truth remains an independent offline evaluation
channel and never reaches the decision logic.

## Comments

2026-10-06: Focused loaded hover/drop passed on attempt 2 with onboard camera
support and stable motor unloading after full estimated stow. Native payload
stayed stationary, both input audits passed and full recording decoded.
Evidence: `logs/reliability_render_delivery_probe_20261006/RESULT.md`.
The unstable provisional branch was not used. A deployment transient spent an
attempt despite loaded evidence returning. A minimized regression fails before
a fix; 199 focused checks pass after stable loaded hover can clear an
unconfirmed touchdown candidate. The final full rendered run must qualify
that refinement. Frozen thresholds and three-attempt recovery are unchanged.
