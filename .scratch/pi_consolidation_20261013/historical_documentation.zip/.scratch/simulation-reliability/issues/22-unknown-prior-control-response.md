# Separate unknown prior control from observed disturbance

Status: ready-for-agent
Parent: ../spec.md
Resolution: regression repair and focused moving render pass; full acceptance pending

Before the first own velocity command arrives, the observer uses a zero target
for the previous position controller. A known calm 0.3 m/s handover plant then
produces up to 0.1368446465 m/s false disturbance. Timestamp alignment cannot
fix this because the sample times in this plant are exact.

A scratch measurement-seeding guard removes that false residual in the bounded
plant. It cannot establish actual wind or safe initial motion. The controller
must explicitly represent the unknown response interval rather than certify
an invented signal. Correlate with the closed moving rendered trial before
choosing the repair. Clearance and operating-envelope requirements remain.

Three actual-controller regressions fail against the archived moving-failure
methods in 0.60 s. The patched controller passes 34 related tests in 5.10 s
and rebuilds in 18.3 s. Logs:
logs/reliability_unknown_handover_archived_red_20261006.log,
logs/reliability_unknown_handover_related_final_20261006.log and
logs/reliability_handover_guard_build_20261006.log.

The observer only evaluates residual after an own arrived-command response
can be assessed. Prior response is explicit and disturbance fields unavailable
during that interval. The motion certificate retains measured incoming motion
until a known packet arrives. Existing certified active braking remains usable.
Clearance, reserve and response/transport parameters are unchanged. This fixes
the bounded regression; full physical traversal is not yet qualified.

Repeat output: logs/reliability_render_return_handover_guard_moving_20261006.
All seven focused checks pass with native minimum clearance 0.7093870740 m.
Actual entry 0.7591 m/s differs from both earlier failures; exact replay is not
claimed. Full standard seed acceptances remain required. The preceding failed
trial and its complete recording remain preserved.
Controller SHA-256:
76ec878ba6c5747176e6e6d5456d4295977344d75cdbc59c610451b662f40e93.

Evidence: ../unknown_handover_response_20261006.md. Coupled gust failures in
issue 15 remain separate and open. No simulator truth may become a controller
input. No production edits during the rendered-source freeze.
