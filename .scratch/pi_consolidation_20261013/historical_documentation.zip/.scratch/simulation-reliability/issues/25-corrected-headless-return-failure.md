# Corrected headless return still violates clearance

Status: ready-for-agent
Resolution: failure preserved; causal controller diagnosis in progress
Parent: ../spec.md

After repairing the headless ground-velocity observation, delayed command
handover and terminal publication, the full calm my_world seed 1 trial still
fails return navigation. Outbound traversal succeeds; ReturnCorridor reports
STUCK at x=15.54. Independent minimum corridor clearance is 0.5028028772 m,
below the unchanged 0.70 m requirement. There are no contacts. The subsequent
RTL crosses above the corridor and fails the altitude/mode checks, while
physical home landing and connected final disarm are recorded.

Find the first clearance loss in the observed state, queued commands and
recovery transitions. Do not rewrite the failed grade, substitute future truth
into the controller, loosen clearance or count safe timeout as traversal.
Measure callback timing separately from independent recorder receipt timing.
Headless object detections cannot qualify rendered perception or motor delivery.

Direct candidate update: acknowledged early speed caps, distinct fresh FCU
velocity settling and acknowledged restoration of the previous command now pass
the physical gate component at 0.50 and 0.80 m/s. The minimum independently graded
clearances are 0.8294466941 and 0.7899010987 m respectively. Ten rejection checks
pass, including stale scans holding the latest measured position instead of
commanding a return to the entrance. Production decision source is unchanged.
The 0.50 m/s full navigation candidate is isolated under
.scratch/braked_navigation_candidate_20261007; its child entry point and cwd are
checked against that snapshot. Its first launch was stopped during START_QR for
an import-scope problem and is preserved without a qualification verdict.

Evidence: logs/reliability_corrected_headless_focus_20261007, including the full
onboard, lidar and command recordings, separate evaluation_truth_track.csv,
navigation_grade.json and a verified 833-file frozen_source.zip. Archive SHA-256:
ce70e282063bf91821e5e09b056f58fd9ec9584e9d06b7be307d14f0eaeb5662.

## Comments

The current full offline suite and three fresh rendered courses use frozen
decision source matching the passing standard seeds. Controller experiments
remain scratch-only until their full-clearance traversal and rejection behavior
are demonstrated and a new source-matched qualification sequence is prepared.
## Independent-clock candidate — 7 October

Expanded qualification with frozen bytes now finds 3/5 calm navigation passes.
Seeds 3 and 5 fail at 0.6893745645 and 0.6788924955 m; both first breaches
occur at obstacle 4 in the return corridor. All five eventually disarm and
record no contacts. Seed 5's recorded first-breach control decision already
reports unavailable braking clearance, with 0.62 s scan age and 0.33 s pose
age. The old forecast paths were not recorded, so a prediction/trajectory
reconstruction must not be presented as exact. A separate instrumented snapshot
is being prepared without changing the original certificate decisions or motion.
Adoption is withheld. Field seed 1 fails margin and the 900 s budget despite
completing return traversal. The two coupled stress cases still contact.

The fixed scratch candidate passes all 29 existing controller regressions and
the full calm seed 1 navigation course. All 13 navigation checks pass, with
0.7073142080 m minimum clearance, no contacts and actual final disarm. The
756-source archive verifies SHA256
a32479058127f2d7f8711125753090b26398ae5b33ecc978759879775d46cc28.
This does not qualify omitted delivery, rendered perception, coupled gusts or
hardware. The expanded frozen-candidate calm trials have closed seeds 1 and 2
as navigation passes. Production decision source is still frozen during native
split-corridor acceptance; adoption needs remaining qualification.
