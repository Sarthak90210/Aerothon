# Exclude display annotations from camera analysis and OCR

Status: ready-for-agent
Resolution: integrated pixel repair passes full 1388-test suite; rendered split fails 19/22, further repairs installed
Parent: ../spec.md

The banner node draws detection boxes and labels on its normalized image
before subsequent candidate checks and OCR. The OCR crop therefore contains
display pixels that did not come from the camera. This is an implementation
defect independent of whether it caused the observed gate failure.

The isolated candidate draws on a separate overlay and keeps all image
analysis on the original normalized frame. A saved rendered banner fixture
using the real OCR reader confirms the defect: 8,835 changed color channels
reach OCR in the original implementation, versus zero in the candidate.
Both exact on_image implementations are saved under
logs/reliability_clean_banner_pixels_contract_20261007/source_override.

Repeat the unchanged banner identity, capture, sweep, orbit, text, camera
gate, phase-zero and perception-corruption checks. The first runner used a
nonexistent test filename, so no regressions executed. Preserve that setup
error separately. The corrected runner is active under
logs/reliability_clean_banner_pixels_regressions_fixed_owned_20261007.

Do not mutate the production source while its rendered split qualification
is active. After qualification closes, integrate only a checked repair and
repeat the full suite and rendered trials. No current rendered repair pass,
motor-delivery qualification or hardware qualification is established here.

## Comments

All 279 selected banner/camera/corruption checks pass in 218.59 s. The new
actual-word-reader pixel regression plus capture checks pass 11/11. A two-file
review patch is saved in logs/reliability_clean_banner_review_patch_20261007.
The integration coordinator waits for the previous owned renderer and its
source archive to close, requires actual disarm and checks the full original
835-file manifest. Only then does it install the exact checked patch and run
the full offline suite and a new rendered split trial. Its waiting status is
in logs/reliability_pristine_banner_integration_20261007/report.json.

The complete pristine suite closes 1388 passed, 3 skipped with all other
offline checks passing. Its rendered split flight closes FAILED, 19/22,
773.1 s airborne and actual disarm. Motor delivery qualifies at 0.11 m
independent payload error. Return traversal, unexpected mode and zone
ceiling fail. Exact source and runtime visual assets are verified, and the
recording includes disarm. The pristine pixel defect is repaired; the
return-alignment flight failure remains open under issue 34.
