# Search coverage fixtures need timestamped motion captures

Status: ready-for-agent
Type: task

The 7 October complete suite finished with 1402 passed, 2 failed, 3 skipped.
Both failures are FrontierSearchTests lane-coverage regressions after a new
observed exclusion. Their teleporting aircraft fixture supplies no clock,
pose timestamp or velocity timestamp. The new production braking gate
correctly refuses to resume without fresh measured motion.

## Evidence and repair

The isolated original-input probe reproduces both failures in 0.132 s.
It records a latched braking hold with no clock, no captures and zero
settled samples. Changing only fixture inputs to distinct fresh stationary
captures passes the original two coverage assertions in 0.249 s.

The shared fixture now advances its own simulated clock by 0.1 s per tick
and reports a stationary FCU capture at the previously commanded pose.
This agrees with its existing instantaneous teleport response. No test
assertions, flight logic or real telemetry signals were changed.
Missing, stale, duplicated, future and nonfinite motion captures remain
covered by the production-path braking tests.

Combined stage, search braking and provisional red-entry checks pass
184 tests. The full suite is rerunning on frozen 839-file source under
logs/reliability_early_red_clipped_bearing_fixture_clock_qualification_20261007.
Rendered split and rotated trials are gated on that full suite passing.

Evidence: logs/reliability_frontier_braking_fixture_before_20261007.log,
logs/reliability_frontier_braking_fixture_after_20261007.log,
logs/reliability_frontier_fixture_regressions_20261007.log.

The first rerun launcher incorrectly reused the old output path and exited
before any tests. Its error log is preserved. Retry 1 uses a distinct output
path; it is the actual rerun. Complete offline and rendered results remain
pending, so this issue is not marked complete.
