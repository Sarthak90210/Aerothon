# Native return stops inside the fixed sampling reserve

Status: ready-for-agent
Parent: ../spec.md

The frozen V38 split trial failed 17/22 at 0.694933815 m and became STUCK.
Its actual received scan at 415.6 s reports 0.719975550 m. Replaying the
same conditioned scan and recorded velocity registration gives 0.720316952 m,
but the production compiled planner rejects the occupied origin before
search. Recorded attitude sampling error is 0.054 s; this is a bounded
sensor-input seam, not exact ROS callback reconstruction.

The fixed 0.025 m interpolation reserve is applied even to zero-length
segments and short forecast steps. Merely admitting the origin leaves
the graph disconnected. Refining continuous clearance also requires the
compiled shortcut stage to use the same certificate when its normal
batch rejects every shortcut. The actual compiled private control finds
a path whose 2001-sample-per-edge minimum remains above 0.70 m.

V39 checks the 1-Lipschitz lower bound of distance between observed samples
and subdivides ambiguous intervals, bounded to ten refinements. The same
0.70 m threshold and unknown-space checks apply to every subdivision.
The normal compiled fast path, grid reserve, lidar mask/filter, timing,
actuator response and stale-data guards are unchanged.

Before the fix: six regressions fail, four safety negatives pass. Actual
published holds through the existing normal 0.6 s airframe with no added
queue lose clearance to 0.615 m. After the fix: 40 focused checks pass;
that physical hold retains 0.700267746 m. Thin surfaces between clear
endpoints, subthreshold origins and masked reverse space remain rejected.

Qualification still requires five new exact-source targeted flights,
short native moving-gate return replay, one reduced offline suite, five
22/22 full native missions and 96 campaign flights. The separate overhead
demonstration's 22/22 does not upgrade the earlier failed V38 trial.
Strong gusts, artificial delayed control and post-disarm native recorder
shutdown faults remain preserved and unresolved.

## Comments

2026-10-10 user stop and executive handoff. All five exact-source V39 targeted
navigation trials now pass all 13 checks and have connected disarm. The short
native moving-handover return completed all seven focused checks with
0.758286655 m independent clearance and actual connected disarm. Its separate
contact-free closure failed with 6,805 unexpected contact records. See issue 42.
The full reduced offline suite, five full native missions and 96-flight
campaign have not started. No source is accepted. Qualification is stopped by
the user, and no mission or qualification process was active at handoff.
