# Preserve physical gate braking and corridor height through estimator wander

Status: ready-for-agent
Resolution: focused diagnostic fixes integrated; complete reduced qualification remains pending
Parent: ../spec.md

V34 mild random seed 3 failed 0.70 m corridor clearance at 0.6560762477 m
while crossing/braking before the corridor velocity controller was enabled.
The flight had zero contacts/fence breaches and an actual connected disarm.
Field seeds 2/3 passed navigation; two queued cases remained unflown.
The closed failed grade and immutable 944-file archive are retained under
`logs/reliability_reduced_scope_v34_source_20261008/targeted_failure_closed_review.json`.

The recorded braking-only seam reproduces 0.6676548894 m on the frozen
V34 gate class. Constant estimator errors pass. A motion-derived arrival
hold passes 0.9855804276 m. The V35 gate fix retains signed FCU ground
displacement and cancels GPS changes in its position command. Missing,
malformed, nonfinite, future and discontinuous vectors fail closed; duplicate
captures cannot settle. The previous recorded crossing case also passes
0.9131327877 m. No lidar filter, speed, freshness, settling, actuator or
clearance threshold changed.

V35 passed field seeds 1/2/3 and mild random seed 3 navigation, with the
last retaining 0.7424024490 m corridor clearance. Mild random seed 4
failed return traversal at eight true heights below 0.30 m despite
0.7339558115 m wall clearance. Actual disarm, zero contacts/fence and
DEGRADED landing remain in the closed five-run failure review:
`logs/reliability_reduced_scope_v35_source_20261008/targeted_failure_closed_review.json`.

The actual published vertical command with captured barometer errors and
normal airframe reproduces 0.2736657746 m. Constant barometer errors pass;
half gain passes but retains estimator-driven physical travel and was not
adopted. V36 preserves the actual handover height using signed FCU vertical
displacement while retaining commanded altitude offsets, 0.8 gain and
0.6 m/s cap. The same isolated replay remains above 0.7843999999 m.
Target changes, real sink, duplicate and missing/stale/nonfinite/future
captures, a broken stream, repeated target messages and actual re-enabling
are covered. 98 combined focused checks pass.

Recorded-error replays regenerate physical inputs and do not reconstruct
ROS callback order. The vertical seam exercises vertical publication, not
horizontal navigation or motor delivery. Truth and world data appear only
in evaluation fixtures, never production decisions. These focused results
do not close the issue. V36 must pass all five targeted flights, the complete
reduced-scope offline suite, all five native 22/22 acceptances and the
96 eligible campaign flights on the same final source. Strong gusts and
artificially delayed control remain unresolved and excluded.

V36 subsequently closed two failed flights and cancelled three unflown
cases. Random 4 hit the gate history guard and contacted the board during
abort before actual disarm. Random 3 had computation-deadline misses and
a vertical capture gap, stopped in return, exceeded 900 s, then returned on
battery abort and disarmed. The stop watchdog timed out and terminated;
its failure and all flight grades/telemetry remain preserved. The captured
timeline does not prove a callback race or that a numeric boundary alone
caused the actual gate stop.

An isolated exact-clock control reproduces rejection of precisely
300000000 ns because subtracting float seconds produces a slightly larger
value. V37 compares integer nanosecond intervals at the same 0.30 s limit;
300000001 ns remains rejected. 107 integrated focused checks pass. V37
targeted and campaign object flights use real-time simulation, RTF 1,
with unchanged controller/sensor rates, 0.6 s actuator response, 0.20 s
computation budget and zero added queue. Timeout receipts are now saved
and stop requests retried by all three supervisors. V37 remains an
unaccepted candidate pending every original reduced qualification gate.
