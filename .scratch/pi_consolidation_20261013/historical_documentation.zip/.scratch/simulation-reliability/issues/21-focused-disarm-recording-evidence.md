# Require real FCU disarm and camera captures through landing

Status: ready-for-agent
Parent: ../spec.md
Resolution: false-pass regressions fixed; rendered moving trial pending

The focused driver read `mav.state.armed` without checking a live FCU link.
MAVROS defaults armed to false on heartbeat loss. Its grader also accepted the
driver's final boolean without verifying recorded FCU states or the video.
The passive recorder had the same disconnected-state termination weakness.

The actual driver landing-loop regressions and focused-grader regressions
reproduce nine false passes. The retained red log is
logs/reliability_disarm_evidence_red_20261006.log, with nine failures and two
valid-case passes in 2.29 s. Tests use actual MAVROS message types and a
controlled clock. They do not qualify flight hardware.

The driver now requires an observed armed state followed by fresh, connected
FCU disarm after landing starts. Missing or stale states remain unknown.
The recorder only starts its shutdown delay after that recorded transition.
Focused and full graders verify the capture ledger, decoded export count and
duration, and a real last camera capture at or after FCU disarm. Playback's
final hold cannot stand in for an observation.

New landing/qualification and moving-handover checks pass 27 tests; related
route/stage checks pass 214, recording/campaign checks pass seven. Changed
Python and shell syntax is checked separately. This patch follows the full
1340-test snapshot and does not inherit that snapshot's qualification.

No controller, planner clearance, motor-priority delivery or retry policy was
changed. Require a closed moving rendered trial and archive before further
production edits. Full current-source standard seed acceptances remain pending.
