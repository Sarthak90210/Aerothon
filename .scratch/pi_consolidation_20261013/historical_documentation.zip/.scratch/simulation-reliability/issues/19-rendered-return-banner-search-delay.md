# Avoid discarding a valid oblique return-banner view

Status: ready-for-agent
Parent: ../spec.md

The current-source full standard calm seed 20261003 completed and disarmed,
but failed the unchanged 900 s flight-time limit at 965.0 s. All other 21
checks passed: independent corridor clearance 0.723653986 m, restricted-zone
clearance 1.635075236 m, motor-qualified delivery and input isolation.
The complete recording and exact source archive are preserved in
logs/reliability_render_my_world_s20261003_receipt_model_20261006.

Replaying an actual early orbit camera frame through the production banner
node reproduces rejection: board aspect 0.82 outside 0.9-8.0. The later
frontal frame is accepted. The early frame already passes the existing
lettering-component, board-area, white-content and green-content checks.
An isolated parameter probe at minimum aspect 0.8 accepts both frames;
OCR remains inconclusive on the oblique frame. No text-reading claim is made.

The recorded regression fixture is
tests/fixtures/banner_return_oblique_843_20261006.png, SHA256
4fc45dac7b4fd8a678c2546da568350f7da1fc0bb7c7fde7939bddd283572d1d.
Run the actual-image regression red before editing, then preserve all decoy
and existing rendered-image tests. Clearance and square-on lidar entry gates
remain unchanged. Require both full current-source standard rendered seeds
to pass before opening campaigns. Hardware identity remains unqualified.

## Comments

The actual-image regression failed before editing in 2.47 s. Minimum aspect
is now 0.8; all other identity gates, lidar square-up and clearance requirements
are unchanged. All 209 banner regressions pass in 16.55 s and the package
rebuilt in 18.5 s. The full calm seed 20261003 bannerfix recording has started;
no rendered timing fix or current-source full acceptance pass is claimed yet.
