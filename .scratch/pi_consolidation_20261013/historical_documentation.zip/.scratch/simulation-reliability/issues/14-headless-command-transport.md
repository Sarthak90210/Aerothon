# Match headless command transport to the avoidance model

Status: ready-for-agent
Resolution: implemented; focused checks and full offline suite pass
Parent: ../spec.md

The real headless callback applied every raw velocity command immediately.
The rendered-qualified controller accounts for a 0.4 s transport delay.
The reproducer exercising the callback and velocity selection failed twice
before the fix: a command moved immediately, and an immediate stop erased
a pulse that should still have been in transit.
`logs/reliability_headless_delay_before_20261006.log`: 2 failed, 1 passed.

The headless physical model now queues raw commands by arrival time. A later
stop cannot cancel an earlier transmitted command. Position targets, takeoff,
mode changes and disarm cancel velocity mode. A zero-delay configuration
remains explicit; invalid delays are rejected. The navigation runner records
0.4 s transport and 0.6 s response and passes the same delay to the controller.
No motor or contact-confirmation signal was added.

`sim/test_headless_command_delay.py` tests the real callback, delayed pulse
and stop, zero-delay model, position-mode transition and stale-command timeout.
Together with geometry, registration, planner and headless/navigation contracts,
100 checks pass in 6.14 s in `logs/reliability_headless_coupling_20261006.log`.
The drone production code remains identical to both targeted rendered passes.
