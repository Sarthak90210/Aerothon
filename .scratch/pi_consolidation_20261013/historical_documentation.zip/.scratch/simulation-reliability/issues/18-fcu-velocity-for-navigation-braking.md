# Use fresh onboard EKF velocity in corridor braking

Status: ready-for-agent
Resolution: six focused rendered checks pass; full source-matched acceptance pending
Parent: ../spec.md

The receipt-model focused return still failed at 0.687308717 m clearance and
recovery exhausted at 123.537 s. Record and exact 751-file source archive are
preserved in logs/reliability_render_return_receipt_model_20261006.
The 123.601 s camera timeline decodes through disarm; input isolation passes.
The yaw/receipt fix does not resolve this failure by itself.

The navigator derived ground velocity from FCU pose differences despite a
fresh FCU velocity_local stream in the same recording. Three real ROS-topic
publication regressions failed in 3.33 s before the change, then passed in
2.06 s after. Six expanded guards pass in 2.71 s; the related transport
selection passes 34 tests, 9 deselected, in 60.17 s and avoidance rebuilt.

The controller now subscribes to /mavros/local_position/velocity_local and
prioritizes its fresh local-ENU EKF velocity. Handover seeds existing observed
motion into the response model. Once velocity is observed, stale or invalid
velocity holds navigation; repeated old timestamps cannot refresh it.
Pose-only input remains an explicitly labelled finite-difference estimate
when no velocity stream has been observed. Fault diagnostics report unavailable
velocity rather than presenting a reset zero as a fresh measurement.

Physical offline fixtures supply their integrated aircraft velocity as a
simulated EKF observation. No motor or current evidence is fabricated. The
rendered trial receives the actual existing MAVROS stream; it adds no simulator
truth or contact inputs. Ground clearance stays 0.70 m with the same reserve.

Focused repeat logs/reliability_render_return_fcu_velocity_20261006 is running
on the same recorded FCU starting fixture and unchanged world. Source and
qualification helpers are frozen. No rendered pass is claimed yet. Broader
campaigns and current full standard qualification remain gated.

## Comments

The focused repeat passed all six checks. Observed far exit 132.467 s,
independent clearance 0.739236132 m, full return below walls and disarmed.
Navigation input audit passes. The 131.551 s video decodes through disarm;
752 source/helper files and 53 runtime assets verify. RESULT.md in the run
directory records exact archive provenance. Current full offline suite is
running before the two source-matched standard acceptance seeds.
