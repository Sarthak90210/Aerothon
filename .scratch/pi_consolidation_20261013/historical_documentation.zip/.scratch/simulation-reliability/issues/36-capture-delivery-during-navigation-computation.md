# Deliver onboard captures during navigation computation

Status: ready-for-agent
Type: task

The command-deadline candidate completed ten calm/field navigation trials.
Seven pass: all five calm seeds and field seeds 4 and 5. Field seed 1 fails
return recovery with 0.6253002931 m clearance and 882.4 s airborne. Field
seed 2 exceeds 900 s at 981.0 s, despite 1.0590746617 m clearance. Field
seed 3 fails return recovery with 0.6814237298 m clearance and 807.7 s.
All closed recordings, source hashes, assets and actual disarm are verified.
The candidate is withheld from production. No pass is inherited by a repair.

## Callback-scheduling evidence

Field seed 1 records six stale-observation faults. A representative callback
starts at clock 770.31 with pose/velocity stamp 770.04 and scan stamp 769.70.
After computation it records velocity age 0.39 s and scan age 0.73 s, and
correctly refuses the expired observations. This is an observed starvation
candidate, not proof that starvation alone caused physical clearance loss.

An actual ROS scheduling probe sends controlled pose, velocity and lidar
messages while a timer callback takes 120 ms. The existing callback path
has median pose age 0.09196 s and maximum 0.10290 s. An isolated capture
inbox has median 0.00969 s and maximum 0.02149 s, with 41 sampled decisions
in each case. These are scheduling measurements, not simulated flight passes.

The candidate receives the same onboard topics on a separate executor.
It writes only a bounded inbox; navigation state is updated on the control
thread at tick boundaries. Timestamp validity, pose pairing, freshness,
planner clearance, disturbance assessment and command certification remain
unchanged. It subscribes to no contact, attachment, simulator truth or world
geometry topic. The VelocityController class AST is verified identical to
the tested deadline candidate; only its entry-point delivery wiring changes.

## Pending physical repeat

Frozen 760-file source and separate assets are archived under
logs/reliability_capture_inbox_source_20261007, SHA-256
8d52d1dd2db055d903397ce10e741bdf9f442a24b0799ee4b745e1085d5616ba.
The unchanged my_world field seed 1 repeat is running under
logs/reliability_capture_inbox_field1_navigation_20261007 with 0.4 s physical
delay, 0.6 s response, 0.20 s computation budget and full clearance retained.
Onboard telemetry/commands and independent truth are stored separately.
This is navigation only. Camera rendering and motor delivery are not qualified
by it. The first archive preparation stopped on Windows text decoding before
any trial; an explicit UTF-8 retry verified every unchanged base byte first.

The current production perception qualification remains source-frozen and
is recording the split mission after its 1404-test complete offline pass.
Production controller files were not changed. Strong gust/delay failures,
normal gate integration, final-source rendered acceptance and the corrected
200-case matrix remain open.


Field 1 now passes all navigation checks, 0.7474275214 m corridor clearance, 884.1 s airborne, zero contacts and actual disarm. All 530 decisions have no stale-observation fault. Field 3 also passes at 0.7347988319 m and 845.9 s. Field 2 fails search without matching the target, at 0.7606753893 m and 542.3 s. Both failed and successful repeats have source/assets/recordings verified through disarm. Expansion is withheld. The first closure watcher exited before its report existed; direct closure retry succeeded, and the watcher now waits for report creation. No flight result was changed. Normal gate integration, field-2 search and strong-gust qualification remain open.


07 October integration update: the capture inbox, pairing, independent clock and
computation deadline now run from the normal production entry point. Recorder
creation is optional, and partial-startup resources close. Native avoidance and
mission build pass, 89 focused controller/router checks and 204 startup/mission
checks pass. Normal gate speed admission, measured braking and acknowledged
restore are integrated and pass 12 fault checks. Full offline and new rendered
qualification remain pending; this source is provisional, not accepted.

Latest root integration verification closes: 1440 unit tests pass, 3 skipped,
plus all syntax/configuration/frontend checks. All code/assets match the
pre-run 900-file freeze, whose archive is verified. Review:
logs/reliability_search_braking_campaign_full_offline_closed_review_20261007.json.
This qualifies offline checks only. Native full missions, gusts, timing,
source adoption and the corrected 200-case campaign remain open.
