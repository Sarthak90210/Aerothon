# 44. Return gate: the laid sheet merges with the delivery-zone grass

Status: needs-triage (Phase 2 rebuilds the arena layout)

## What happened

Headless banner_ground, field s2, after `_laid_face`
(logs/laid_front3_ground_field2_20261012): COMPLETED at 956 s, over the
900 s limit. Before the change the same case took 829 s.

The extra time is the return gate (BANNER_ALIGN 249 s against 140 s). At
the stand-off (21.4, -15.8, 5.0) facing -180 deg, with the camera at GROUND
(-35 deg), the detector saw a green box 819 x 119 px on the frame's bottom
edge and refused it: "no border legible". On most other headings the
frame was solid green (1280 x 720). The drone is over the grassed delivery
zone, whose edge (world x = 13) lies under the sheet's near edge, so grass
and sheet form one green region and the sheet's border is not isolated.
The coarse sweep and one fine sweep (~130 s) saw nothing. The green orbit
then found the sheet at -165 deg and squared up.

The earlier 829 s run reached the return gate in the hung pass (camera at
BANNER, -20 deg), whose frame bottom stops short of the grass. In this run
the outbound gate taught the placement hint "ground", so the return gate
went straight to the GROUND pose.

## Why it may be a headless artefact

The headless world puts the delivery-zone grass in the detector's green
band (`Arena.green_ground`). The rendered grass measured H47/S73, below the
S floor of 90 (status 2026-10-12), so in Gazebo it would not merge.

## Options

- Phase 2 arena: keep the delivery zone clear of the gate mouths, as the
  real hall layout dictates.
- Headless: model the grass with its measured saturation instead of
  inside the band.
- Alignment: when a GROUND sweep sees only border-less green on the entry
  heading, lift to the BANNER pose before the full sweep.

## 2026-10-12: seen again in the Phase 2 headless campaign

The first clarified worlds kept the delivery zone 4 m clear of the
corridor ends. The return search stands 5 m off the return gate on the
zone side, so the return alignment ran from over the grass, and the GROUND
pose saw solid green on every heading (clarified_h030_ground, superseded).
`world_from_dimensions.py` now keeps the zone 9 m clear (ZONE_CLEAR_M). The
headless grass model is unchanged; it is pessimistic compared with the
rendered grass (S73, below the band).
