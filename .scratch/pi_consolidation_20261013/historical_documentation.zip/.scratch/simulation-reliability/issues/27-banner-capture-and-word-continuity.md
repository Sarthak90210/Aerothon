# Qualify banner captures and current word evidence

Status: ready-for-agent
Resolution: implementation and targeted checks in progress; rendered qualification pending
Parent: ../spec.md

The drone must use distinct timestamped captures, paired onboard pose history,
and evidence in the current image when identifying the return banner. Neither
an unstamped vector nor a cached word from an absent or blank panel can qualify
a new sweep heading. Preserve the existing range and clearance requirements.

The repaired OCR cache exposes a real severity-5 exposure clipping case. A
clipped-color region can reach the word reader, but cannot satisfy the original
structural green-board check. Corruption envelope trials require independent
fresh reads; detector rate qualification remains a separate rendered check.

Repeat targeted identity, sweep, orbit, camera gate and capture regressions,
then the full offline suite. Record native split, standard pair, shipped and
rotated results on their actual frozen decision source, including failures.

## Comments

The previous new-capture complete suite closed 1381 passed / 3 failed / 3 skipped.
No native rendered trial began after that failure. Two fixture timestamps were
missing; one perception defect was masked by the original OCR cache.

The repaired clipped-color and current-lettering implementation passes all 209
targeted checks. A fresh complete suite is active under
logs/reliability_banner_capture_qualification_continuity_20261007. Its frozen
835-file archive is verified, SHA256
0553a195d3b18359a4d55e5dd1f6ac0dfa907be44d89e576692b3cec03a99e9d.
The separate fresh-read corruption matrix passes every condition. A blank
panel at a previously read word's box is rejected. Native qualification is pending.

The complete suite now passes with 1387 passed, 3 skipped in 944.93 s and
all syntax/configuration/frontend checks passing. All 835 source hashes remain
unchanged. The fresh native split trial is next; its grade remains pending.
Exact verified source archives for both previous interrupted/failed suites are
also preserved, with their original non-passing statuses unchanged.
