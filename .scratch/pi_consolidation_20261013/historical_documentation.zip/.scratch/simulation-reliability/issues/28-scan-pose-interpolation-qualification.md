# Qualify capture-time lidar pose interpolation

Status: ready-for-agent
Resolution: expanded batch closed six navigation passes, four failures; buffer trial active
Parent: ../spec.md

Replace a nearest-pose registration estimate with bracketed interpolation of
actual onboard FCU pose history at the lidar header timestamp. Reject missing
brackets, stale scans and gaps beyond the original freshness limit. Preserve
0.70 m clearance, sampling reserve, physical command delay and aircraft response.

The isolated candidate passes six pairing checks, 29 existing controller
regressions and the complete calm my_world seed 5 navigation trial. Minimum
clearance is 0.7407902342 m, airborne time 883.9 s, no contacts and final disarm.
Delivery is omitted. Source archive 758 files is verified in
logs/reliability_paired_scan_navigation_s5_assets_20261007.

Expand to calm/field seeds 1-5 before adopting production changes. Preserve
every earlier failure and every new failure. Changing gusts with delayed
control still require separate physical qualification. A headless pass cannot
qualify rendered perception or motor-based delivery.

## Comments

The first expanded runner omitted AEROTHON_MOTION_FORECAST_OUT. The avoidance
controller crashed; those partial flights are invalid qualification evidence.
The runner was stopped and its twelve escaped child groups were closed only
after checking snapshot cwd, assigned domains, start identities and commands.
All partial traces and the interruption review are preserved. The replacement
batch uses process-local unique recorder paths under
logs/reliability_focused_paired_scan_navigation_verified_20261007.

The scan-pose candidate still contacts in both original combined gust/delay
fixtures. A separate actuator/disturbance forecast correction also fails both
physical trials and is not adopted. Neither result changes the seed 5 grade.

Nine of ten expanded trials are closed at 10:52 India on 7 October: six
navigation passes, calm seed 3 recovery failure, field seed 2 clearance failure
at 0.6895136986 m, and field seed 5 GateAdvance freshness failure. Field seed 4
is still pending closure. These results block production adoption.

Calm seed 3 has 99 capture-pose faults among 462 late return control records.
Field seed 2 has six such faults among 25 records near its first hard-clearance
violation at 798.4 s. Both reviews use recorded onboard data; independent
geometry grading stays separate. Correlation is not established causality.

The isolated buffered candidate waits for a later FCU pose bracket while
retaining a still-fresh paired scan. It never refreshes the older scan's
capture timestamp. Seven subscription callback checks pass. Its original
29-test regression had six failures with unstamped fixture inputs, archived
with exact source SHA 8916a3ededd80cda7bd82f159e048ba62948cd2a6a3cbc18e0ab80930fd7c5af.
Measurement-stamped copies now repeat the unchanged physical cases and
assertions. No production source or active scan-pose snapshot was changed.

Final expanded result: six of ten navigation passes, four failures, unchanged
source, all ten disarmed and evidence hashes verified. Field seed 4 closes
with 927.7 s airborne and fails the 900 s limit. Calm seed 5 loses the 0.025 m
sampling reserve at 0.7234276155 m despite passing the hard 0.70 m grader.
The reserve remains required for adoption.

Buffered timestamped-fixture regressions pass 29/29 in 237.26 s. Both combined
gust/delay cases still contact at 6.1 / 19.0 s, so those are not qualified.
A frozen full calm seed 3 buffered trial started at 10:54 India and closed
with all 13 navigation checks passing, 0.7254285863 m corridor clearance,
2.2520712636 m exclusion clearance and 803.4 s airborne, through disarm.
Its 759-file source, recovered assets, commands, onboard data and separate
truth are verified. Among 605 controller records there are no capture-time
pose faults, one stale-scan stop and three post-planning freshness stops.
The field seed 2 failure is being repeated next on this same frozen source.
One seed does not authorize production adoption or broader qualification.
