# Static equipment mounts must not admit simulator vehicle pose

Status: ready-for-agent
Resolution: implemented; focused and both full targeted navigation-time audits passed
Parent: ../spec.md

The earlier lazy TF listener subscribed to dynamic TF, including an unused
native odometry path. An initial pre-activation graph audit missed that
subscription. Relative mount lookup did not intentionally use absolute pose,
but this was insufficient isolation evidence.

The navigator now receives static equipment calibration only. It rejects
world/map/odom/body absolute transforms and admits descendants of the body
mount. Aircraft motion comes from FCU pose. Regressions failed before this
fix; the 88-check static mounting selection passed afterward.

The focused delay-aware return trial passed its actual navigation-time graph
audit, including the operator driver and activated mounting subscription.
The focused delivery trial passed an active four-node driver audit. Runner
audits now activate automatically; no early snapshot is treated as proof of
later subscriptions. Full rendered mission and broader campaign audits remain.

## Comments

2026-10-06 full standard retry 3 passed both initial and navigation-time
graph audits with the static mounting subscription active. All independent
clearance checks passed, but the whole acceptance failed the 900 s time
limit. Broader campaign audits still remain.

Evidence: `logs/reliability_render_return_delay_20261006/decision_inputs_navigation.json`
and `logs/reliability_render_delivery_probe_20261006/decision_inputs_delivery.json`.
Both preserve source/helper hashes and separate native evaluation truth.
