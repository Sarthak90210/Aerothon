# Optional camera report crashes after motor confirmation

Status: ready-for-agent
Resolution: optional camera crash fixed; earlier full targeted passes qualify archived source
Parent: ../spec.md

Current source also continues after motor confirmation with camera ground
support inconclusive. Full current-source acceptance remains pending because
the later return controller failed; the older full passes below are archived
evidence for this optional-camera fix.

2026-10-06: both requested seeds complete, return, land and disarm after
motor-priority confirmation. Seed 1001 records delivery offset UNMEASURED
when camera positioning is unavailable, without crashing or fabricating an
offset. Independent native evaluation separately measures 0.12 m payload error.

## Reproduction

Rendered `my_world.json`, calm seed 20261003, retry 1. The motor observer reached
DONE on attempt 1 at t=769.0 s. The payload detection was fresh but reported
`visible: false`, without `x` or `y`. WinchDrop read `det['x']` while attempting an
optional camera distance report and the mission process died. Operator simulator
recovery LAND disarmed at the delivery site. Full acceptance failed.

## Change

Validate visibility and finite payload coordinates before the optional report.
Without them, preserve motor confirmation, leave camera offset unmeasured and
advance to the return climb. Motor thresholds, retries and claw mechanics are
unchanged. The failed run is retained with its original hashes and failure note.

## Validation

`logs/reliability_delivery_continuation_fix_final.log`: 191 passed, including
invisible/incomplete/non-finite detections after confirmation and valid optional
coordinates. The same-world, same-seed retry 2 is running. Close only after the
rendered full mission completes and independent grading passes.
