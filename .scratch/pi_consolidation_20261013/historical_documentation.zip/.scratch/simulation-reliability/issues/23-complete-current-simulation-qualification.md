# Complete current-source simulation qualification

Status: ready-for-agent
Resolution: both standard seeds and full offline suite passed; coupled gust repair in progress
Parent: ../spec.md

The user explicitly requested completion of the current seed 1001 mission,
latest-source full offline suite, changing-gust/delayed-control qualification
and the 200 requested world/seed/weather combinations with additional rendered
shipped, rotated and split-corridor acceptance.

Keep hard clearance and all acceptance checks unchanged. Preserve actual
recordings through connected FCU disarm, commands, raw onboard observations,
source/configuration hashes and simulator evaluation truth separately.
Classify the preserved off-axis fixture as infeasible at 0.70 m. A headless
navigation pass cannot qualify rendered perception or motor delivery.

The existing owned continuation closes the unchanged-source standard seed
pair and full offline suite. The new completion coordinator waits for that
verified closure, repeats dirty and delayed-scan gust diagnostics with 0.4 s
actual command transport on seeds 0-5, and stops on failures before launching
broader qualification. Passing diagnostics open the six-worker 200-case
navigation matrix, followed by sequential rendered calm seed 20261003 on
shipped, rb_rotated and split_corridors. All failures remain preserved.

If gust repair changes production code, the old pair remains archived evidence
and a new matching standard pair and offline suite must qualify the new source.
Hardware and flight qualification remain deferred by the user.

## Comments

Seed 1001 closed with GRADE_PASS, 880.0 s flight, 0.7130100272 m minimum native
corridor clearance, 1.6248532894 m red-zone clearance, 0.09 m payload error and
0.17 m landing error. First-attempt motor inference and camera through fresh
connected disarm pass. The continuation verifies both exact source archives
and unchanged source before the full suite. The new coordinator's failed-job,
unqualified-report and changed-source gates pass three isolated checks.

The complete suite closes with 1367 passed, 3 skipped in 692.63 s and all
syntax, XML/YAML and frontend checks passing. The preserved pair report
confirms source unchanged. All 12 current-source coupled gust/delay probes
fail, including dirty seed 0 contact at 6.1 s and late seed 1 at 19.0 s.
Slower travel and disturbance-limited speed delay the dirty contact to
12.6/13.0 s without repairing it. The distance-tracking cap is a no-op under
the existing proportional-speed formula. A proactive measured-position hold
with observed-rate release contacts at 75.9 s after 11 holds. None is a pass.

The owned launcher exposed transient DrvFS replacement gaps, including
FileNotFoundError and ENODATA. The actual launched probes were inspected
without duplicate launches. Bounded read retries pass checks for missing,
empty and ENODATA transients, plus persistent and permission errors.
Producer code and the four recorded qualification helpers remain unchanged.

The 200 requested combinations are now being characterized from an exact
source snapshot of the passing standard pair, independently of scratch-only
gust diagnosis. Six workers use ROS domains 40-45. Archive bytes, snapshot
bytes and launched decision/fixture module origins were verified. Evidence:
logs/reliability_navigation_baseline_matrix_20261006, including source ZIP,
snapshot verification and import verification. This baseline cannot qualify
a later repair. It records 20 invalid editor_test combinations and 20 off-axis
combinations blocked at 0.70 m separately; neither class counts as a pass.

On 7 October the asset-complete baseline matrix closed all 200 requested
combinations: 160 executed, zero navigation passes, 40 classified without
flight. Every failure is preserved in summary/report/aggregate_review_20261007.
The three rendered follow-ons failed before mission start due to the absolute
OUTPUT bug tracked in issue 24. The scope selector repair passes eight checks,
but live course reruns and coupled control repair remain outstanding.
The headless velocity, command handover and terminal evidence bugs are being
repaired independently, with the active frozen snapshot left intact.

The observation/receipt/terminal fixes now pass 25 related checks, and the
absolute-output runtime selector passes eight checks. The new complete suite
closes with 1376 passed, 3 skipped in 813.17 s and all syntax, XML/YAML and
frontend checks passing. Source comparison confirms decision source matches
the standard pair and frozen source is unchanged after the suite. Fresh full
rendered shipped, rb_rotated and split_corridors courses are now active under
logs/reliability_observation_and_capture_qualification_20261007.

The corrected calm headless my_world seed 1 still fails at the incoming return
gate handover. First actual breach precedes earliest raw-command receipt.
Issue 25 tracks that failure and its verified source archive. The corrected
broader matrix is held until this targeted failure is repaired.
