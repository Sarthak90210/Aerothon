# Preserve fresh FCU observer state during lidar-only stops

Status: ready-for-agent
Resolution: isolated repair passes 5 contract and 29 controller checks; three physical repeats closed, adoption withheld
Parent: ../spec.md

The archived combined candidate loses the 0.70 m minimum during field seeds
4 and 5. A lidar gap unconditionally resets the observer even when fresh
FCU velocity and pose samples are available. The next valid scan treats
continuing measured disturbance as a new control handover.

The isolated candidate keeps the observer advancing on distinct fresh FCU
captures during a lidar-only fault. It still commands zero translation and
yaw until lidar observations return. Stale or invalid flight observations
still reset estimation. No simulator measurements, narrower clearance or
physical-fixture changes are introduced.

The real publication-path regression fails 2/5 before the repair and passes
5/5 afterward. The unchanged stamped controller regressions pass 29/29.
Field 4, field 5 and calm 5 repeats run from a verified 759-file archive,
SHA-256 fb1dd19dc9276b7ec87fd99306fc7d87a97c743f49967c5f8d336d5e5f8215b5.
The original launcher had CRLF line endings and failed before any physical
trial. That failure and launcher are preserved separately. The LF retry is
logs/reliability_lidar_fault_continuity_trials_retry1_owned_20261007.

Production remains frozen for rendered camera qualification. This candidate
has not been adopted and does not qualify the strong coupled gust cases.

The original combined batch evidence is closed and source/assets verified
through disarm. Calm seed 5 passes all 13 navigation checks, 0.7504102976 m
minimum corridor clearance and 878.1 s airborne. Field 4 and 5 remain failed
at 0.6401312614 / 0.6778281715 m and 916.8 / 934.4 s.

Independent prefix comparison originally mixed absolute GPS offset with
relative motion error. The correction is preserved separately under
relative_forecast_review_20261007.json. Queued-prefix displacement errors
near the violations are at most 0.01777 / 0.03619 m; absolute pose offsets
of 0.51590 / 0.48784 m are not motion-prediction errors.
