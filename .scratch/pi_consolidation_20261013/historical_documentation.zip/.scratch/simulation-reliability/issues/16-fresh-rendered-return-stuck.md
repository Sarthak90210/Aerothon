# Fresh calm rendered return failed after disturbance certificate change

Status: ready-for-agent
Resolution: open
Parent: ../spec.md

Fresh standard calm seed 20261003 reported return STUCK at x=13.01 and
independent clearance 0.680769329 m. The full record is preserved in
logs/reliability_render_my_world_s20261003_gustfix_20261006, including verified
source archive and full video through disarm. Delivery motor qualification,
restricted-zone clearance and detector timing passed. Mission acceptance did
not pass; current-source campaigns remain gated.

The first minimized closed-loop standard-course fixture passes at 0.722215336 m.
It has not reproduced this failure. Continue minimizing with recorded noise,
scan timing, mounting, command delay and response behaviour. Do not relax the
clearance requirement or count the archived older-source passes as current.

## Comments

The focused rendered reproduction closed and failed with recovery exhausted
at 126.854 s. Its independent clearance minimum was 0.648668474 m. It landed
and disarmed, video 125.701 s decoded through disarm, input isolation passed.
The exact 750-file archive and 53 runtime assets verified. Record:
logs/reliability_render_return_fresh_repro_20261006. This reproduces the stall
without full mission search or delivery. The idealized noisy/delayed/mounted
fixture still passes even with measured initial velocity, so it is not a
replacement for rendered validation.

Rejected slope smoothing contacted earlier in both coupled gust cases;
rejected clearance-cost floor adjustment did not resolve them. Both changes
were local diagnostic prototypes only. Issue 17 fixes a separately reproduced
yaw omission in the real publication certificate. Repeat the focused rendered
reproduction after the broad regressions and rebuild pass.
