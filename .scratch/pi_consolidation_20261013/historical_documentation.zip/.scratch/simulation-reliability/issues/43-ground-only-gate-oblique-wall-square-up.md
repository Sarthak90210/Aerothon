# Ground-only gate: square-up locks onto the corridor wall from off-axis

Status: resolved in source 2026-10-12 (headless); awaiting rendered confirmation
Parent: ../spec.md

Organiser clarification: a banner may be laid flat in front of the corridor
instead of hung. With no board there, the gate's only lidar signature is the
mouth: the wall ends, plus the gate posts in the simulator.

## Observed

`banner_ground.json`, calm seed 1, headless, 2026-10-11
(`logs/banner_matrix_calm1_20261011/banner_ground_calm_s1`).

The aircraft runs out of relocations at the outbound gate and the mission
fails (`AlignToBanner: no AEROTHON banner found from 15 vantage point(s)`).

- The hung view identifies nothing within its 60 s budget, as designed. The
  aircraft flies back over the top to (0.6, -0.3, 4.9).
- The GROUND view identifies the sheet 100/100 at -28 deg, about 6.3 m off
  by ground-plane ranging.
- The square-up fit then returns a "face" 1.8-2.0 m away. The forward scan
  holds nothing nearer than 5.2 m. The fit is the outbound corridor's north
  wall, seen obliquely from about 3 m off the corridor axis: that is its
  perpendicular distance.
- The laid-face check refuses it correctly ("not the mouth the laid banner
  marks at ~6.3 m"). Each relocation, though, moves along the bearing to the
  sheet, which never brings the aircraft onto the corridor axis. Six
  relocations, then failure.

Field seed 2, from the same corner, fitted the mouth (posts) at 4.9-5.1 m and
completed: `logs/banner_ground_aspect15_field2_20261011`, all navigation checks
pass at 871 s.

## What is needed

A laid-sheet pass needs the corridor axis, not just the bearing to the sheet:

- either estimate the sheet's long-axis direction from its image (the
  border's long sides) and stand off perpendicular to it,
- or, when the fitted face is refused, relocate laterally along the fitted
  face toward its end (the mouth) rather than along the bearing.

Either must keep the existing refusal of a face that does not match the
sheet's ground range.

## Not affected

Suspended-only and both-banner gates square up on the hung board, as before
the clarification.

## Resolved, 2026-10-12

In AlignToBanner, GROUND passes only:

- A refused NEARER face is read as the side wall. The aircraft moves onto
  the line through the sheet along that wall, a standoff back, on the side
  the pass came from (`laid_mouth_vantage`). At most two such moves.
- The move is not cut short by a sighting on the way.
- A face BEYOND the sheet is never read as a side wall.
- On the axis the mouth is open and the lidar sees only the walls edge-on.
  An edge-on wall with the sheet centred is accepted as the corridor
  direction (`_laid_axis_fit`), with the standoff taken from the sheet's
  ground range.

Headless, banner_ground (logs/issue43c_*_20261012): calm s1 completes,
822 s; field s2 completes, 868 s. All navigation checks pass in both.
Tests are in sim/test_banner_placement_alignment.py.
