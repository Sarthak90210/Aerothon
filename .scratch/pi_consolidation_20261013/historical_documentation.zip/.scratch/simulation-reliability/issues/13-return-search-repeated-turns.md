# Return search exceeds the full mission time budget

Status: ready-for-agent
Resolution: implemented; both full targeted standard acceptances passed
Parent: ../spec.md

## Evidence

Full standard seed 20261003 retry 3 passes every independent check except
the 900 s flight limit. Actual duration 927.0 s. Return-gate search takes
105.983 s. Its full-circle zigzag scans command about 2522.7 degrees of
shortest yaw travel. Camera readback remains fresh and settled. The
minimized actual-stage empty-scan test reproduces 1260 degrees for a single
complete scan before the second camera tilt. Before the fix, one check
fails and 89 pass in 6.55 s.

## Fix and acceptance

Visit adjacent headings around the full circle, preserving the initial
heading, coverage, dwell and identity thresholds. Preserve all routing,
exclusion and corridor requirements. Re-run return-search regressions and
complete standard rendered acceptance with the unchanged 900 s limit.
Keep the failed recording and hashes. Broader campaigns remain gated.

## Validation

After the fix, 213 focused checks passed. Four packages rebuilt in 42.5 s.
Full standard calm seed 20261003 retry 4 passed all 22 independent acceptance
checks, including the unchanged 900 s limit. Flight duration was 864.1 s.
Return and exclusion clearances were 0.741457867 m and 1.567421444 m. Input
audits, fresh recorded motor confirmation, source/runtime preservation and
complete decoded video through disarm passed. The prior timing failure is
retained. Seed 1001 and broader qualification remain.
