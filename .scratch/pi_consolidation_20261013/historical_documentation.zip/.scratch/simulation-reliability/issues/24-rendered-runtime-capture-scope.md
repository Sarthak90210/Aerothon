# Recognize owned rendered output paths

Status: ready-for-agent
Resolution: selector repaired; regressions and fresh owned runtime capture passed
Parent: ../spec.md

All three additional rendered courses reached connected FCU readiness but
stopped before mission start. Their runtime_capture.log reports "This output
has no active owned rendered harness". The coordinator passes an absolute
OUTPUT argument. The helper's original selector only considers arguments
starting with logs/, so it rejects its actual caller.

Match the known workspace Bash script and its positional OUTPUT argument
resolved in that process's cwd. Preserve exact output and simulator-child-group
scoping; a different output, checkout, incomplete command or Python process
must not match. Do not bypass runtime capture or substitute defaults for
loaded configuration.

## Comments

check_runtime_capture_scope_20261007.py executes the helper's actual AST selector.
The absolute-output case fails against the original and passes after repair,
alongside seven valid/invalid scope cases. Red/green logs are preserved in logs/.
The previous helper is retained as runtime_capture_original_20261007.py and in
the qualified standard source archives. Fresh complete rendered flights remain
required; the three earlier setup outputs are not flight results.

The fresh shipped seed 20261003 launch with the same absolute OUTPUT form now
passes actual runtime capture. runtime_capture.log records 32 parameter files,
53 hashed configuration assets and owned stack group 5017. Independent camera,
payload truth and aircraft truth channels are ready before mission start.
Evidence is logs/reliability_render_shipped_s20261003_observation_repairs_20261007.
This closes the scope-selection defect; complete rendered flight grades and
recordings remain pending and receive no pass from this setup check.
