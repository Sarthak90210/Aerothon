# Physical transport delay and gusts still violate corridor clearance

Status: ready-for-agent
Resolution: open; original no-transport gust regressions fixed, coupled cases fail
Parent: ../spec.md

Current receipt-model probes still fail after correcting the physical fixture
to queue both yaw and body velocity and convert each vector once at receipt,
matching the installed ArduPilot handler. Dirty seed 0 contacts at 6.05 s,
sampled minimum 0.410391157 m, and late seed 1 contacts at 7.85 s, sampled
minimum 0.403685054 m. Reports:
logs/reliability_gust_{dirty,late}_receipt_physics_20261006.{json,log}.
They include controller, planner, physical-fixture and probe source hashes.
These remain failures on feasible courses. Older probes below used the old
physical conversion semantics and are retained as historical diagnostics.

The changing-disturbance certificate passes all 117 existing broad checks.
Those wind fixtures have immediate physical velocity transport. Separate
real-controller probes with a 0.4 s physical command queue still fail:

- Dirty lidar, seed 0: contact at 15.35 s, sampled minimum 0.407455992 m.
  `logs/reliability_gust_dirty_delayed_20261006.{json,log}`.
- Late scans, seed 1: contact at 27.85 s, sampled minimum 0.404350018 m.
  `logs/reliability_gust_late_delayed_20261006.{json,log}`.

These are failures on geometrically feasible courses, not infeasibility passes.
The probes execute the real scan/pose/controller loop and queue emitted
commands in the physical fixture. Independent clearance is evaluation only.

Rejected local diagnostic experiments are retained separately. Extending
forecast lead by the transport delay made contact earlier at 7.8/14.7 s.
That prototype was not installed in production. Keeping the unsimplified
connected path also contacted a surface at 24.7 s. No clearance reduction,
unchecked hold or fabricated observation is permitted as a workaround.

Reproduce with:
`bash .scratch/simulation-reliability/check_gust_probe.sh --seed 0 --kind dirty
--delay .4 --out NEW.json` and the equivalent `--seed 1 --kind late`.
Each output must be new so failure evidence is preserved.

Full-suite results, calm rendered acceptance and broader campaigns must
report this limit separately. Current hardware/environmental qualification
remains deferred; no worst-condition qualification is claimed.
