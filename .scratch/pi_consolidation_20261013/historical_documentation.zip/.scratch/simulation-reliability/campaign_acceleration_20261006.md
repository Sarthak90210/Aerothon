# Campaign acceleration preparation

This preparation does not launch a campaign or qualify any mission. Production,
simulation, runner and qualification-helper files were not changed.

The existing navigation campaign already runs six trials at once. Each trial
has seven owned process groups: the object world, recorder, mission, avoidance,
camera controller, winch controller and delivery-zone publisher. The campaign
leases a distinct ROS domain for the entire trial, then releases it only after
cleanup. Six workers use domains 40 through 45. The supported maximum is 16,
which uses domains 40 through 55. No MAVLink or Gazebo port is used by these
object trials. Use the campaign runner, whose domain queue prevents reuse while
a trial remains alive, rather than launching separate generic fly_headless
batches with overlapping domain ranges.

The full matrix is ten world fixtures, four condition families and five seeds,
or 200 requested trials. Geometrically blocked fixtures are classified before
flight. If off-axis remains the only blocked fixture, 20 trials are classified
and 180 run. Every executed trial records its source/configuration and onboard
data separately from simulator truth. Headless navigation does not qualify
rendered perception or motor delivery. The runner checks both full standard
rendered acceptances, their required seeds, disarm and matching current drone
source before creating its output directory.

At the existing RTF cap of four, a trial consuming the full 1200 simulated
seconds takes at least 300 wall seconds. With six workers, 180 such trials have
150 minutes of nominal flight work. This is an arithmetic estimate, not an ETA:
startup, recording, grading and CPU contention add time. A stalled trial's
existing outer wait is 1020 wall seconds before cleanup. Raising workers can
reduce total time only while the real stack keeps up with simulated time.
The host reports 16 logical processors and 33,968,549,888 bytes of physical
memory. Its effective WSL allocation and sustained campaign throughput have
not been measured in this preparation.

Keep six workers for the first qualified matrix. Inspect each completed result's
sim_s and wall_s, plus onboard stale-scan/pose/telemetry holds. Eight workers is
a reasonable next benchmark if the host sustains the six-worker batch, but
there is no measured evidence here that eight will improve total throughput.
Increasing RTF above four or launching all 16 workers immediately can add
transport/executor latency and change the actual failure envelope. Do not
change physics delay, clearances, rulebook time, stale limits, detector rates
or required evidence to claim speed.

The current rendered runner is a singleton. Its guard rejects another active
Gazebo/ArduPilot stack. The launcher uses shared /tmp/aerothon_* assets, a fixed
9002 flight-dynamics port, MAVROS 14555/14556 and fixed ancillary ports. Distinct
ROS domains and GZ_PARTITION values alone cannot isolate simultaneous full
rendered runs. Safely running these in parallel would require separate runtime
directories, all port/instance settings and ownership/cleanup changes followed
by isolation tests. It is a larger change than assigning additional agents.

The current bannerfix seed 20261003 capture ledger spans 919.75 simulated
seconds over 3864.786829616 wall seconds, an achieved RTF of about 0.238.
Readiness took about 208 wall seconds. The mission log spent 1897.9 wall seconds
in SEARCH_QR, then failed return recovery at 3619.2 wall seconds. The rendered
configuration is already headless: 1280 by 720 camera at 20 Hz, 450 lidar rays
at 10 Hz, 1 ms physics steps and an intended RTF of one. Another software agent
cannot advance these clocked flight stages.

The launcher has an existing AEROTHON_SERVER_GPU=1 option. Its retained comments
report older measurements in which GPU rendering improved camera throughput
but reduced lidar throughput. Those historical comments do not establish an
improvement for the current 450-ray headless configuration. A controlled
fresh diagnostic comparison could measure that option later, after the active
source archive closes. A backend change requires new runtime hashes and
delivered QR/red/lidar rate evidence; it is not an accepted speed improvement.

Additional agents can work concurrently on independent recorded-trace analysis,
small replay preparation and review while one rendered flight owns the machine.
Keep production edits under one owner and freeze them during acceptance.
Full tests, builds and navigation campaigns should follow rendered closure.

Prepared command, to be launched only by the primary after both gates pass:

```bash
bash .scratch/simulation-reliability/start_qualified_navigation_matrix_20261006.sh \
  logs/reliability_render_my_world_s20261003_bannerfix_20261006 \
  logs/reliability_render_my_world_s1001_bannerfix_20261006 \
  logs/reliability_navigation_matrix_20261006 6
```

The first path is currently failed and the second is not yet accepted. The
command will therefore refuse the gate now. Supply the eventual matching,
current-source passing pair if a return fix changes those output names.

After this matrix, rendered shipped, rb_rotated and split_corridors acceptances
remain sequential, using the same full recording runner and frozen calibration
profile. Their simulator truth, complete recordings through disarm, detector
rates and grading must remain separate per run.
