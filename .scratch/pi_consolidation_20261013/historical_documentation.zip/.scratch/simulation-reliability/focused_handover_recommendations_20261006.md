# Focused return handover review

The existing focused fixture reproduces an entry pose, then starts avoidance
from near-rest. It does not reproduce the moving handover in the full mission.
This is a measured fixture difference, not evidence that entry momentum caused
the later clearance failure or that the current timestamp fix is insufficient.

## What the driver actually does

`sim/corridor_trial.py` waits 15 simulated seconds, arms in GUIDED, takes off to
10 m, flies to the recorded approach x/y at 10 m, descends there to the entry
altitude, points the camera forward and flies to the recorded entry x/y/yaw.
Its crossing condition is a 0.12 m three-dimensional position error and yaw
error below 0.08 rad. It then holds that position for more than three simulated
seconds before enabling avoidance. The driver never writes an FCU velocity or
teleports the aircraft. The hold physically brakes its actual momentum.

The original entry schema stores x, y, altitude, yaw, an approach position and
capture timestamps. The driver uses only the positions, altitude and yaw.
It does not replay the timestamps, prior commands or attitude/velocity history.
The newly extracted bannerfix entry also records an actual entry velocity, but
the unchanged driver does not read that additional field.

The full return sequence uses `GateAdvance` with a 0.25 m horizontal arrival
tolerance. It hands control directly to `Corridor` on reaching that condition,
without the focused driver's three-second hold. `Mav.enable_avoidance` clears
position streaming at that handover. The avoidance node resets traversal and
observer history, then seeds its initial ground and response state from a fresh
actual FCU velocity. It does not set the drone's measured velocity to zero.

The focused phase label changes to RETURN_CORRIDOR one driver tick before the
first enable call. Therefore the first non-OBSERVING avoidance sample is the
better available recorded comparison, with the recorder's 0.2 s resolution.

## Retained onboard evidence

| Run | First RETURN_CORRIDOR observation | First active avoidance observation | Measured horizontal speed at active observation |
| --- | --- | --- | --- |
| Old focused six-check PASS | 98.394 s | 98.594 s | 0.03212 m/s |
| Full gustfix, source of old entry pose | 866.274 s | 866.474 s | 0.28924 m/s |
| Full bannerfix failure | 868.408 s | 868.408 s | 0.31493 m/s |

At the first RETURN_CORRIDOR observation, before the focused enable takes
effect, the focused speed was 0.04037 m/s. The corresponding original full
entry speed was 0.38991 m/s. Its x/y were reproduced closely, within about
0.003 m, and altitude within 0.016 m. The pose match therefore does not imply
a velocity match. The old focused and bannerfix full recordings have identical
recorded hashes for velocity_controller.py, mission_tree.py, corridor_trial.py
and run_recorded_acceptance.sh. These comparisons are historical; the new
measurement-time fix is currently being verified separately.

The last three seconds before full bannerfix handover contain a moving gate
approach: measured horizontal speed fell from about 0.637 m/s to 0.425 m/s
before handover. The focused recording was already holding the waypoint and
fell to 0.046 m/s before handover. Its onset observer and pending command
history are consequently different, even with the same loaded parameters.

The retained data and bounded read-only extraction are in
`focused_handover_review_20261006.json` and
`review_focused_handover_20261006.py` beside this report. No simulator truth is
used by that extraction's entry or command-history analysis.

## Runtime and payload comparison

The focused PASS and full bannerfix failure have identical hashes for the world
spec, materialized world, layout, conditions JSON, conditions parameter file,
airframe and frozen delivery calibration. Both archive 32 loaded parameter
files. Thirty-one content hashes match. The remaining bridge parameter file
differs only in the generated `/tmp/tmp*.yaml` filename supplied to config_file.
The contents of those referenced upstream temporary bridge files are not in
these 32 archived parameter files, so their equivalence cannot be established
from this hash comparison alone.

The focused fixture declares payload_fixture=unloaded. Its vehicle XML is
identical to the full loaded vehicle after removing the single DetachableJoint
plugin. Aircraft link masses total 2.034 kg in both XML documents. The payload
is a separate model and is not counted in that number. Removing that joint
allows the focused aircraft to begin without carrying the payload.

The full bannerfix stack recorded a native simulator_contact_detach event.
Separate evaluation truth ends with the payload at the target, approximately
(46.403, 13.037, 0.105) m, while the drone had returned toward home. The focused
unattached payload remains at the start, with ground height approximately
0.105 m. Thus an unloaded aircraft is the appropriate return fixture after
successful physical release. It does not reproduce the earlier loaded flight,
winch movement, estimator/controller integral history or long mission duration.
The onboard winch is IDLE with zero commanded payout estimate in both entry
observations. That estimate must remain distinct from measured hook position.

## Recommended next reproduction

1. Keep the present focused trial as a stationary-entry clearance regression.
   A pass supports that scenario only. It cannot validate the moving gate-to-
   avoidance handover or the entire full mission.
2. For a separate moving-entry trial, reuse the production gate-crossing
   handover, including its actual recorded last position target and 0.25 m
   arrival tolerance. Avoid the extra three-second hold. Command real approach
   motion and record the resulting fresh FCU velocity. Do not inject velocity
   samples or assume that using the entry x/y automatically reproduces speed.
3. Record the pre-handover pose, attitude, actual FCU velocity and actual
   setpoints for at least the response/transport interval before enabling.
   Compare these against the original full-flight window. Report a mismatch
   rather than presenting a stationary trial as a moving reproduction.
4. The measurement-time fix should still be tested in the full standard
   rendered seed pair with unchanged clearance, course and grading. A moving
   focused pass shortens the feedback loop but does not replace those gates.

No production file, driver, qualification helper, calibration or requirement
was changed. No simulation, test suite or build was launched for this review.
