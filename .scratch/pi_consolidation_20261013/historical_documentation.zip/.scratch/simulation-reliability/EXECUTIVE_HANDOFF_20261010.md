# AeroTHON Mission 2 executive handoff

Prepared 10 October 2026, 16:58 IST. Workspace: `D:\MY DOCUMENTS\VIT\Team Rotor Fpv\AEROTHON`.

## Executive position

Work is stopped at the user's request. The current V39 controller candidate has passed five targeted navigation flights, including the previously failing field seed 2. All five recorded connected disarm. The short rendered split-corridor return completed with 0.758287 m minimum clearance, above the unchanged 0.70 m threshold. It did not receive evidence acceptance because its independent contact check failed. The pipeline exited before the final offline suite, five full rendered missions and the reduced campaign.

**No final source version is accepted. Reduced qualification is incomplete.** No original 200-case qualification is claimed. Strong gusts and artificially delayed control remain unresolved and excluded by the user's instruction.

The stop audit found no active mission, SITL, Gazebo, qualification worker or watchdog process. Unified execution session 43454 had already finished with exit code 1. No armed flight needed interruption during this handoff. The five object-navigation flights and focused native flight had already disarmed. The previous custom-world bird's-eye recording was delivered and remains available.

The highest priority on an authorized restart is the focused native contact failure. Preserve the original failed evidence, establish whether the unloaded scene and landing contact rules match the trial contract, and repeat into a new output directory if a correction is needed. After that, complete the final offline, native and campaign gates on one unchanged source version.

Authoritative stop record: [Stop checkpoint and artifact hashes](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/handoff_stop_checkpoint_20261010.json>). This report supersedes older "active" headings in the historical progress files. Their chronological evidence remains preserved.

## Status against the requested work

| Workstream | Verified position at handoff | Remaining work |
|---|---|---|
| QR search, field seeds 1/2/3 | All three pass 13/13 navigation checks on V39, without added control delay | Verify real rendered detection and delivery in final full missions |
| Gate braking and corridor return | V39 also passes retained mild random seeds 3/4; short native return passes seven focused checks and clearance | Resolve focused contact closure, then pass full split mission and other courses |
| Normal startup integration | Controller, camera scheduling and perception code are integrated; build and 12 installed imports match frozen source | One complete reduced offline suite on V39; complete mission integration evidence |
| Full rendered acceptance | No required full V39 acceptance has started | Five required full missions, every check passing |
| Reduced campaign | Zero of 96 eligible campaign flights executed | Run and close all 96; record 80 weather exclusions and 24 negative geometry classifications |
| Consolidated final evidence | Source freeze, targeted closure, recordings and failures retained; stop checkpoint written | Accepted source, final detector rates, all required results and source/configuration closure |
| Strong gusts and delayed control | Failures retained; user-deferred and unresolved | Outside this qualification scope; requires separate future work |

## Current source and integration

The candidate is V39, containing 951 controlled files. A fresh handoff comparison found zero file mismatches against its frozen manifest. The frozen ZIP was rehashed successfully.

```
V39 frozen-source archive SHA256
000dd0834aff203801af9fa8980597634b846ab7806084ed907719478ff2671e
Git base commit
c6348a1fbacea45548287ba89a7fdba44a31a72c
```

The workspace contains extensive uncommitted and untracked work. The Git base alone does not identify the tested implementation. The frozen archive and manifests do. No reset, commit or push was performed for this handoff.

- [Frozen V39 source archive](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_scope_v39_source_20261008/frozen_source.zip>)
- [951-file source manifest](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/reduced_scope_v39_candidate_20261008/source_manifest.json>)
- [Source provenance](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_scope_v39_source_20261008/provenance.json>)
- [12 installed decision-module paths and hashes](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_scope_v39_source_20261008/installed_startup_imports.json>)
- [Avoidance package build, passed](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_v39_build_20261009.log>)
- [Installed startup verification, passed](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_v39_startup_verify_20261009.log>)

The installed import check includes the actual `FastConnectedPlanner` module used by the velocity controller, as well as mission tree, gate and search braking, local planner, commander, routing, banner captures, camera controller, banner and QR perception. This closes the earlier risk of testing only a base planner while the running controller used the compiled planner.

### Changes already integrated

1. **Continuous corridor certification, V39.** The captured native V38 scan showed a safe origin near 0.720 m, but fixed sampling reserves rejected zero-length and short forecast intervals. A second rejection occurred in compiled path shortcuts. The shared planner now uses a 1-Lipschitz clearance bound and bounded subdivision of uncertain intervals. It keeps the 0.70 m floor, unknown-space rejection, 0.025 m grid reserve and normal compiled fast path. A failed shortcut batch can use the same continuous certificate. Ten refinements are the limit. Thin obstacles and unsafe endpoints still fail closed.
2. **Physical gate hold, V35.** Gate braking uses distinct fresh measured ground velocity to integrate signed displacement and correct the hold anchor, avoiding pursuit of estimator wander. Existing speed, settling, tolerance and timeout limits remain.
3. **Physical vertical corridor hold, V36/V37.** Fresh vertical velocity tracks displacement from the enabled corridor altitude. The exact 0.30 s capture-gap boundary uses integer nanoseconds, avoiding rejection caused by floating-point representation. Missing or invalid motion evidence still faults.
4. **Camera and perception scheduling.** The normal startup code retains buffered distinct captures and capture-time registration while navigation computes. Object fixtures now match the existing native 20 Hz camera and 10 Hz lidar, with recorded drops and latency. The production camera rate was not raised to hide failures.
5. **Return camera handoff, V34.** Normal mission startup explicitly restores the banner camera pose before return alignment and waits for measured joint settlement. This addresses a custom search tilt leaking into alignment.
6. **Search and return sequencing.** Fresh settled-motion captures, bounded camera framing, corrected QR capture-gap holds, ground-motion gate advance and strict return climb completion are retained. Search holds revalidate new red exclusion evidence and preserve the existing escape rules.
7. **Observed geometry and lidar registration.** Motion registration uses fresh onboard ground velocity and captured attitude/static mount transforms. Red exclusion margins stay at 1.50 m. The rejected wider lidar filter was not adopted.
8. **V38 offline integration correction.** The banner-alignment camera stage has its UI state. Seven toy stationary-hold fixtures were corrected because their expected stop lay inside the existing red exclusion margin; original assertions remain, with added inside-margin negative controls.

Main V39 production changes are [LocalPlanner](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/src/aerothon_avoidance/avoidance/avoidance/local_planner.py>) and [FastConnectedPlanner](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/src/aerothon_avoidance/avoidance/avoidance/fast_connected_planner_candidate.py>). Controls are in [Continuous-certificate regression tests](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/sim/test_continuous_corridor_certificate.py>) and [Captured native origin fixture](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/sim/fixtures/corridor_native_safe_origin_split_s20261003_20261009.json>). Other integrated changes are recorded in the frozen source and historical evidence report.

## Verified V39 results

### Focused software and physical controls

Before the V39 fix, six controls failed and four safety negatives passed. After the fix, 40 focused tests passed. The actual published hold through the normal 0.6 s airframe response, with zero added queue, improved from 0.615 m minimum clearance to 0.700267746 m. Thin surfaces between clear endpoints, subthreshold origins and masked reverse space remain rejected.

The captured native input replay recreated 0.720316952 m observed clearance against 0.719975550 m in the original log. Attitude sampling error was 0.054 s. The actual compiled planner probe then found a route whose densely sampled minimum was 0.709985959 m. This is a captured sensor-input diagnostic, not an exact reconstruction of native ROS callback timing or a full mission.

Evidence: [40 passing focused checks](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_v39_continuous_certificate_focused_20261009.log>), [Preserved pre-fix failures](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_v38_continuous_certificate_red_20261009.log>), and [Actual compiled planner cause probe](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_v38_native_compiled_origin_causes_20261009.json>).

### Five targeted navigation flights

All five pass every one of the 13 navigation checks, with zero contacts and fence breaches and actual connected disarm. This is object-level navigation evidence. Rendered images and motor delivery are not exercised; original overall `DELIVERY_UNCONFIRMED`/`FAIL` labels remain preserved.

| Preset | Seed | Corridor minimum, m | Red minimum, m | Airborne, s | Navigation |
|---|---:|---:|---:|---:|---|
| field | 1 | 0.735022 | 2.230071 | 636.7 | 13/13 |
| field | 2 | 0.721266 | 2.275071 | 647.8 | 13/13 |
| field | 3 | 0.727705 | 2.359071 | 650.8 | 13/13 |
| mild random | 3 | 0.733650 | 2.176071 | 824.6 | 13/13 |
| mild random | 4 | 0.718289 | 2.122071 | 770.6 | 13/13 |

Configuration: RTF 1, two workers on ROS domains 40/41, camera 20 Hz, lidar 10 Hz, physical actuator response 0.6 s, computation budget 0.20 s, zero injected command delay and zero extra transport queue. Native mission defaults remain the qualification reference. Random seed 4 retains a `DEGRADED` precision-landing label, although its navigation checks pass.

Evidence: [Five-case report](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_v39_targeted_20261008/report.json>) and [Exact-source targeted evidence closure](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_scope_v39_source_20261008/targeted_closed_review.json>). Per-run onboard telemetry, commands, lidar, independent tracks, configuration, navigation grades and hashes are retained under that batch.

### Focused native split return and immediate blocker

The next pipeline stage ran the actual native moving-handover return, calm seed 20261003, CAD aircraft, unloaded payload fixture, ROS domain 30. It used a recorded onboard entry pose, with a fresh handover age limit of 0.7 s. It omitted search, outbound traversal, delivery and normal return-home landing. It is therefore a focused return test.

All seven focused checks passed. Independent clearance was **0.7582866549316181 m**. The aircraft traversed the full return lane below the walls. Connected disarm was captured at 150.345 simulated seconds and recorded at 150.4. The camera timeline decoded successfully and extended through disarm. Initial and navigation-time decision-input audits passed.

However, the separate contact closure failed. Evidence coverage is valid, all seven channels are present, and the ground canary passed. `contact_free` is false, with 6,805 unexpected contact records:

| Pair | Records | Simulated time, s | Interpretation established at handoff |
|---|---:|---|---|
| skid 1 to payload body | 6,566 | 47.328-63.994 | All precede first recorded arm at 67.4; scene is configured unloaded |
| skid 0 to ground | 126 | 146.670-151.241 | Landing/disarm interval; 106 within the recorded armed interval |
| skid 1 to ground | 113 | 146.670-151.241 | Landing/disarm interval; 93 within the recorded armed interval |

These are contact records, not independently established collision episodes. The placement/classification cause remains unverified. The ground contacts cannot all be dismissed as post-disarm cleanup. The original grade and raw events have not been altered.

The combined focused-pass/contact-valid/contact-free/canary assertion failed in the focused-stage shell. `focused_source_closed_review.json` was never created. The main pipeline exited with status 1. The full-mission grader also remains failed because the focused trial intentionally omits mission stages; its contact failure is an additional unresolved gate.

Evidence: [Seven focused checks](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_v39_focused_split_s20261003_20261009/focused_summary.json>), [Preserved native grade and all contact events](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_v39_focused_split_s20261003_20261009/grade.json>), [Actual disarm](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_v39_focused_split_s20261003_20261009/recorded_result.json>), [Focused native recording](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_v39_focused_split_s20261003_20261009/onboard_sim_time.mp4>), [Pipeline failure log](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_v39_qualification_pipeline_20261009.log>), and [New handoff issue 42](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/42-focused-return-contact-evidence.md>).

## Earlier evidence and delivered recordings

### V38 reduced offline suite

V38 passed its five targeted navigation flights and a complete reduced offline suite: **1,697 passed, eight skipped**, with frontend build, syntax and configuration checks passing. The skips are five explicitly deferred strong-gust positive flight tests and three empty real-photograph corpus tests. The unrestricted suite was not qualified.

This is prior-source evidence. V39 changed both planners and added controls, so V38's offline pass cannot replace the pending V39 suite.

[V38 offline closure](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_scope_v38_source_20261008/full_offline_closed_review.json>) and [Complete V38 offline log](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_v38_full_offline_20261008.log>).

### V38 full split qualification failure

The original normal-startup V38 split run failed **17/22**, with independent minimum clearance **0.694933815 m**. Delivery was confirmed at 0.110438 m offset, but the return became `STUCK` at 429.2 simulated seconds. The operator requested safe RTL; the aircraft returned and actually disarmed. The five failed checks cover incomplete return, above-corridor flight, unexpected mode, zone ceiling and corridor clearance. Contact evidence was valid and contact-free. Flight time was 422.1 s and landing was 0.07 m from home.

The source, configuration, recordings, received scans, controller commands and safe-stop receipt are sealed. V39 was developed from this failure. It stays failed even though a later demonstration succeeded.

[Original 17/22 result](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_v38_render_split_corridors_s20261003_20261008/summary.json>); [Sealed failed-run evidence](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_scope_v38_source_20261008/native_split_failure_closed_review.json>); [Return clearance diagnosis](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_v38_render_split_corridors_s20261003_20261008/return_clearance_diagnosis.json>).

### User-requested bird's-eye recording

The user paused qualification and selected `split_corridors.json`, then requested a bird's-eye view instead of onboard camera video. A fresh V38 calm seed 20261003 flight used a passive fixed native overhead camera. That demonstration completed delivery, full return and actual disarm and passed its own **22/22** grade. Clearance was 0.733833424 m; flight time 441.1 s; delivery offset 0.120191357 m; landing 0.14 m from home.

The added camera and private runtime-provenance adapter give it a different observation configuration. It is retained as demonstration evidence, not final V39 qualification or a replacement for the failed V38 run. Its post-disarm contact-recorder GIL abort remains unresolved. Two earlier unarmed setup failures are preserved.

- [Full bird's-eye video, 7 min 26 s](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/user_birdseye_split_v38_s20261003_retry3_20261009/birds_eye.mp4>)
- [4x bird's-eye video, 1 min 52 s](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/user_birdseye_split_v38_s20261003_retry3_20261009/birds_eye_4x.mp4>)
- [Recording provenance, decode and disarm closure](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/user_birdseye_split_v38_s20261003_retry3_20261009/birds_eye_recording_closed_review.json>)

The overhead camera captured 1,501 frames with zero recorded drops. The exported video contains 1,340 frames at their capture intervals, including disarm. The full video SHA256 is `6c8e9f2a4dd074beeedb8c5f65f8d30ef683f2afd7f24d2b420f3a8620df2535`; the 4x video SHA256 is `8ba4b2fd8d7238f12a6c18ceb2afce3def5e8a06e50fc1ca44c0662c54a6037e`.

## Work remaining, in execution order

1. **Resolve the focused native contact failure.** Inspect unloaded payload placement and landing contact evidence against the existing contract. Keep airborne obstacle protection, all seven channels, the canary, continuous evidence and every threshold. Make a narrow correction only after reproducing the cause. Preserve the failed run and repeat into a new directory. If controlled source changes, freeze a new version and rerun affected targeted checks; V39 evidence must retain its original version label.
2. **Complete final startup/integration verification.** Recheck installed imports after any code/build change. The current 12-import/build proof is complete for unchanged V39; it does not cover a future correction automatically. Keep normal mission startup, camera scheduling, actuator response and perception code in the same final source.
3. **Run one complete reduced offline suite on the final integrated source.** This has not started on V39. Record exact passes, failures and all skips/exclusions. Do not repeatedly run the full suite before a relevant change or diagnostic need. V38's 1,697 passes remain useful regression history only.
4. **Pass five full rendered missions on that same source and configuration.** Required courses are standard `my_world` seeds 20261003 and 1001, `shipped` seed 20261003, `rb_rotated` seed 20261003, and `split_corridors` seed 20261003. Each must pass every required check, including clearance, qualified delivery, aircraft contacts, complete video, input audits and actual disarm. None has started on V39. The earlier rotated result remains a historical failure; no live rotated search is active.
5. **Run and close the 96-flight reduced campaign.** Start only after targeted/native gates pass. Use independent workers where practical, keep normal response and zero injected delay, and stop a failed trial safely after sufficient diagnostic evidence. Preserve cancelled and unflown cases explicitly.
6. **Close the consolidated evidence report.** Identify the accepted archive/manifest, installed modules and configurations. Include every final run, detector rates with time basis, video/telemetry hashes, actual disarm, all exclusions, geometry classifications, precision-landing limitations and every unresolved failure. Run the final closure checks before making any qualification claim.
7. **Retain deferred work separately.** Strong-gust and artificially delayed-control failures remain open. Hardware and real-camera qualification also remain separate from simulation acceptance.

## Reduced campaign accounting

The original matrix is 10 worlds x four weather presets x five seeds, or 200 entries. The selected moderate envelope is mean wind at most 4 m/s and gust at most 2 m/s.

| Accounting category | Exact cases | Treatment |
|---|---:|---|
| calm | 50 | Selected |
| field | 50 | Selected |
| mild random seeds 3 and 4 | 20 | Selected |
| worst preset | 50 | Strong weather excluded, unresolved |
| random seeds 1, 2 and 5 | 30 | Strong weather excluded, unresolved |
| Selected entries | 120 | Before geometry classification |
| Invalid `editor_test` entries | 12 | Negative geometry classification, no flight pass |
| Infeasible `my_world_offaxis` entries | 12 | Negative geometry classification at 0.70 m, no flight pass |
| Eligible navigation flights | 96 | All remain to be run |

Accounting reconciles as **200 = 80 excluded + 24 negative classifications + 96 eligible flights**. Zero campaign flights have executed. The five targeted flights are separate and do not reduce the campaign count.

The eight eligible worlds are `example_custom`, `my_world`, `rb_high_board`, `rb_long_tight`, `rb_low_board`, `rb_rotated`, `shipped` and `split_corridors`. Retained seeds are calm 1-5, field 1-5 and random 3/4 for each world, giving 12 flights per world. Artificial delay is excluded throughout, rather than counted as another set of matrix passes.

Object-navigation campaign fixtures do not qualify rendered detection or motor delivery. The five full native missions supply that evidence. [Original geometry accounting](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/reliability_reduced_scope_v16_source_20261008/planned_geometry_scope.json>) and [Current scope and exclusion index](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/evidence_index_20261007.json>) preserve the exact reasons.

## Detector rates and recording limits

Configured capture rate is not measured recorder rate. The table distinguishes simulated capture cadence, host delivery cadence and simulated latency. These historical measurements belong to their exact source/configuration.

| Run | Camera distinct captures | Camera capture Hz, sim | QR capture Hz, sim | QR delivered Hz, host | QR p95 latency, sim s |
|---|---:|---:|---:|---:|---:|
| V38 original failed split | 2,699 | 5.7264 | 20.0000 | 4.8181 | 0.1910 |
| V38 bird's-eye demonstration | 3,197 | 6.5165 | 20.0000 | 4.2311 | 0.1401 |
| V39 focused return | 893 | 6.2773 | Unmeasured | Unmeasured | Unmeasured |

V38 original red captures are also 20.0000 Hz sim, 4.8182 Hz host, with 0.1910 s p95 simulated latency. The demonstration red captures are 20.0000 Hz sim, 4.2309 Hz host, with 0.13605 s p95 simulated latency. V39 focused return had no search phase, so zero search detector observations cannot qualify QR/red detection. Its camera p95 simulated latency is 0.023 s; the source video timeline is 142.251 s and decodes through disarm.

The V39 object trials contain synthetic detector outputs and empty image recordings by design. Final rendered detector-rate evidence remains pending. Three skipped empty real-photo corpus tests also leave physical camera validation unproven.

## Unresolved failures and risks

- **Current contact blocker.** Focused return scene/contact classification is unresolved, issue 42. Keep its 6,805 unexpected records and failed closure.
- **Full rendered reliability.** V38 original split clearance failure remains; V39 full split and rotated course are unverified. Earlier rotated time/red-clearance failures remain preserved. Passing a short return segment does not establish normal full-mission behaviour.
- **Strong gusts and added delay.** Existing obstacle contacts and return-gate failures are deferred, not fixed. The wider lidar filter was rejected because it can erase thin obstacles.
- **Host timing sensitivity.** V36 had real deadline/capture-gap failures even without artificially injected delay. RTF 1 and exact capture-time guards are retained. Final native runs must expose actual timing rather than weakening guards.
- **Landing quality.** V39 mild random seed 4 remains `DEGRADED` despite navigation acceptance. Record this quality limitation in the final report.
- **Native recorder shutdown.** The pybind11 GIL shutdown abort occurred in prior native runs, including the bird's-eye demonstration after disarm. Preserve stderr/core evidence; do not call the cleanup issue resolved.
- **Headless shutdown.** Some prior runs report `rcl_shutdown already called` after actual disarm. The error is unresolved and must remain separate from recorded flight/disarm evidence.
- **Historical incomplete evidence.** V21 mild random seed 4 was interrupted while the last telemetry remained armed at 606.01 s. Its final disarm/grade is unverified. No pass may be assigned retroactively.
- **Physical validation.** Real-camera corpus, motor/load calibration on actual hardware, full sensor/FCU/winch integration and staged real flights are not qualified by this simulation work. Issue 06 is `ready-for-human`.
- **Environment startup.** The handoff's first WSL inspection failed with `CreateInstance/CreateVm/ConfigureNetworking/0x8007054f`; a retry succeeded and proved no active process. Mirrored-network fallback is a restart risk, not an aircraft result.
- **Documentation lag.** Earlier report paragraphs refer to old V24/V38 work as pending or active. Current stop preambles and this report are authoritative. The machine index now marks `stopped_by_user`, no accepted source and zero campaign flights.

## Restart instructions for the next owner

Do not restart until the user authorizes continuation. No new trial or test is part of this handoff.

The pipeline launcher cannot simply be rerun: its first targeted output directory already exists and its worker uses `mkdir(exist_ok=False)`. It would fail or require unsafe reuse. Preserve completed targeted evidence and resume from the unresolved focused stage, using fresh repeat paths and updated closure references as needed. Do not delete or overwrite previous outputs to make the pipeline start.

The focused-stage helper is [Focused moving-return stage](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/run_reduced_v39_focused_split_20261009.sh>). Its stricter contact closure is the point that failed. The next stages, when authorized and prerequisite gates are valid, are:

```bash
# Run from the WSL repository, after source and prerequisite checks.
bash .scratch/simulation-reliability/run_reduced_v39_full_offline_20261008.sh
bash .scratch/simulation-reliability/run_reduced_v39_split_render_20261008.sh
bash .scratch/simulation-reliability/run_reduced_v39_remaining_rendered_20261008.sh
bash .scratch/simulation-reliability/run_reduced_v39_campaign_20261008.sh
python3 .scratch/simulation-reliability/close_reduced_v39_qualification_20261008.py
```

These are sequencing references, not instructions to bypass unresolved gates. Full rendered and campaign trials require their matching watchdogs, fresh outputs and normal launcher defaults. The final closer explicitly requires the missing focused source closure, final offline closure, 12 startup imports, all five native records and 96 campaign results. If source/configuration changes, prepare a new candidate and adjust helpers and final closure coherently.

Environment: WSL Ubuntu user `sarthak`, ROS Jazzy at `/opt/ros/jazzy`, native overlay `$HOME/aerothon_stack/install/setup.bash`, repository `install/setup.bash`, Node `/home/sarthak/.nvm/versions/node/v24.18.0/bin/node`. Native stages use ROS domain 30; headless targeted workers use 40/41; offline uses 20. The Windows workspace maps to `/mnt/d/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON`. Check live availability before reuse.

The calibrated delivery profile is [Delivery profile](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/logs/delivery_profile_20261005.json>). Native acceptance uses the CAD aircraft with loaded payload, normal mission startup and independent passive evaluators. Simulator truth and evaluation cameras must not enter navigation decisions. Both initial and navigation-time input audits are required.

On a failed armed trial, request safe RTL through the owned MAVROS domain and confirm actual connected disarm before stopping child processes. Preserve each stop attempt and mode receipt. Do not kill an armed process group. Watchdogs exist for targeted, native and campaign stages, with retained timeout receipts and retries.

## Evidence locations and preservation rules

The latest checkpoint hashes every existing focused-native artifact, including onboard/lidar/command logs, camera/video, independent aircraft/contact truth, grade, source and runtime configuration. Targeted closure already hashes its five runs. Historical failures retain their original grades and source versions.

- [Current status with historical checkpoints](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/status.md>)
- [Consolidated working evidence history](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/evidence_report_20261007.md>)
- [Machine-readable evidence index](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/evidence_index_20261007.json>)
- [Read-only handoff inventory](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/handoff_inventory_20261010.jsonl>)
- [Prepared qualification sequencing](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/run_v39_qualification_gates_20261008.py>)
- [Final acceptance and evidence closure requirements](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/close_reduced_v39_qualification_20261008.py>)
- [Repository verification history](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/VERIFICATION.md>)

Legacy `20261008` suffixes identify established candidate/output naming. Actual preparation/run timestamps may be 9 October, and this stop audit is 10 October. Use recorded timestamps and manifests, not directory names alone.

Reuse evidence only if source, configuration, evaluation tools and required scope match. Preserve recordings and telemetry per run, including failed, interrupted, cancelled and setup attempts. Do not weaken 0.70 m corridor clearance, 1.50 m restricted clearance, 900 s airborne limit, contact evidence, qualified delivery or actual disarm. No earlier failure becomes a pass because a later trial succeeds.

## Appendix A: preserved failure ledger

The following historical ledger is copied from the working evidence report without changing prior outcomes. References to a candidate being "unaccepted" describe that checkpoint. They do not undo later focused results, and they do not establish final acceptance. New V38/V39 outcomes are covered above.

| Evidence | Result | Qualification limit |
|---|---|---|
| V3 fields 1/2/3 | All 13 navigation checks passed; actual disarm; zero contacts/fence | Different source; object navigation only |
| V3 offline | 1477 passed, 3 skipped; syntax/configuration/frontend passed | Different source; final suite still pending |
| V3 native split, 20261003 | 21/22; completed, motor delivery and actual disarm; .717815 m clearance | Aircraft-contact check failed; 215 lowered-jaw target-floor contact pairs |
| V5 field 3, RTF4 | Failed corridor clearance .619442 m after .36 s certificate exceeded .20 s budget | Preserved failure |
| Exact V5 field 3, RTF2 | All 13 navigation checks passed | Different source; no rendered qualification |
| V7 retained random 4 | All 13 navigation checks passed | Different source |
| V7 retained random 3 | Failed; QR search lasted 799.6 s before return; battery RTL | Remains in scope |
| V8 fields 1/2/3 and random 3/4 | All five failed in battery RTL; connected disarm verified | Completed-hold braking deadlock; archived failures |
| V9 field 1 | All 13 navigation checks passed; zero contacts/fence; disarmed, 845.1 s total sim | Different source; no delivery qualification |
| V9 retained random 3 | Failed QR time/return/mode/ceiling/red-clearance checks; recorded operator RTL and disarm | Remains in scope; turn holds repeatedly interrupted |
| V10 field 1 | All 13 navigation checks; both corridors and connected disarm, 845.7 s total sim | Different source |
| V10 retained random 3 | Failed; operator RTL after 900 s, connected disarm | Remains in scope; moving hold anchors reproduced |
| V11 retained random 3 | QR found at 802 s; failed time and return; recorded RTL/disarm | Remains in scope |
| V12 retained random 3 | Failed QR time; recorded RTL/disarm; normal native-matching camera cadence | Remains in scope; FCU sample aliasing reproduced |
| V13 retained random 3 | QR found at 712.2 s; return alignment stalled; failed return and time; recorded RTL and actual disarm | Remains in scope; capture aliasing reproduced |
| V14 retained random 3 | QR found at 676.4 s; return alignment stalled; failed return/time; RTL and actual disarm | Remains in scope; top-cropped captures during yaw settlement reproduced |
| V15 retained random 3 | 12/13 navigation checks; flight 905.0 s; failures: flight within 900 s; actual disarm; stop request preserved | Preserved failure; remains in scope |
| V16 retained random 3 | 13/13 navigation checks; 882.3 s airborne; zero contacts/fence and actual disarm | Prior source; object navigation only |
| V16 rendered split | 17/22; 18 target-floor contacts failed only winch freshness; safely interrupted, delivery confirmed and actual disarm | Preserved failure; not qualified |
| V17 parallel targeted field 1 | Return STUCK; .671739 m corridor clearance; actual disarm; no contacts | Preserved failure; remains in scope |
| V17 parallel targeted field 3 | Return/corridor passed; flight exceeded 900 s; actual disarm | Preserved failure; remains in scope |
| V17 parallel targeted random 3 | Return/corridor passed; time/home landing failed; actual disarm | Preserved failure; remains in scope |
| V17 two-worker field 1 | Return/clearance passed; home landing failed at 1.54 m; actual disarm | Preserved failure; LAND model mismatch reproduced |
| V17 two-worker random 3 | Return/time failed; operator RTL and actual disarm | Preserved failure; width-cropped return views during turning archived |
| V18 retained random 3 | Return/time failed; operator RTL and actual disarm; zero contacts/fence breaches | Preserved failure; remains in reduced scope |
| V19 field 2 | Return/time/clearance passed; home landing failed at 1.67 m; actual disarm | Preserved failure; remains in scope |
| V19 retained random 3 | Return/time/clearance passed; home landing failed at 2.19 m; actual disarm | Preserved failure; landing startup mismatch reproduced |
| V20 retained random 3 | Return/corridor clearance passed; 900 s and unexpected-mode checks failed; watchdog RTL and actual disarm | Preserved failure; 100 s return-search delay diagnosed |
| V20 field 2 and mild random 4 | All navigation checks passed; precision landing reported DEGRADED | Quality limitation retained; fixture motor delivery unqualified |
| V21 field 2 | Gate timestamp failure; failed return/mode/ceiling; actual disarm | Preserved failure; bounded hold seam reproduced |
| V21 field 3 and mild random 3 | Time failure; mild seed 3 also failed return; actual disarm | Preserved failures; early-orbit candidate rejected |
| V21 mild random 4 | Simulator interrupted with last telemetry armed at 606.01 s | Final disarm and grade unverified; never counted as a pass |
| V22 mild random 3 | QR found at 746.99 s; failed return/time; watchdog RTL and actual disarm; zero contacts/fence | Preserved failure; search speed lease leak reproduced in actual tree |
| V23 field 3 | Search 194.96 s; time/unexpected mode failed; actual disarm | Preserved failure; opposing camera crops reproduced |
| V23 mild random 3 | High transit shortened to 11.46 s; return search still failed time/return; watchdog RTL and actual disarm | Preserved failure; camera bracket candidate unaccepted |
| V23 mild random 4 | Navigation passed; precision landing DEGRADED | Quality limitation retained; fixture motor delivery unqualified |
| V24 mild random 3 | Actual clearance 0.6948520402727778 m; 792.1 s airborne; mission completed and actually disarmed | Original clearance FAIL preserved; isolated probes do not reproduce runtime |
| V24 mild random 4 | Navigation passed; landing DEGRADED | Quality limitation; fixture motor delivery unqualified |
| V25 mild random 3 | QR found; return search 190.85 s; actual corridor clearance 0.6849396857248734 m; time/unexpected mode failed; actual disarm | Original FAIL preserved; V26 fixes proven framing and certificate gaps, runtime acceptance pending |
| V25 mild random 4 | Navigation passed; landing DEGRADED | Quality limitation; fixture motor delivery unqualified |
| V26 mild random 3 | QR found; high-return speed guard rejected climb handover; automatic RTL and actual disarm | Original FAIL preserved; built mission reproduces .60 m/.30 m tolerance mismatch; V27 strict climb unaccepted |
| V27 mild random 3 | QR found and strict climb complete; return search 187.64 s; 900 s limit exceeded, watcher RTL, actual disarm | FAIL preserved; three unflown cases cancelled; camera state leak reproduced and V28 still unaccepted |
| V28 mild random 3 | Return search 15.15 s, then gate-crossing timeout and two wall contacts; corridor .4034108728140693 m; automatic RTL and actual disarm | FAIL preserved; two unflown cases cancelled; V29 ground-motion arrival still unaccepted |
| V29 timing failures | Mild random 3 and field 3 exceeded 900 s; both zero contacts/fence breaches, all corridor checks passed, automatic RTL and actual connected disarm recorded; field 2 navigation PASS with DEGRADED precision | Original failures retained in exact-source closed review; two unflown cancelled; V30 capture-gap correction unaccepted |
| V30 mild random 3 | Actual disarm within 900 s, but corridor clearance .6908234714203971 m; zero contacts/fence breaches; field 2 and 3 navigation PASS with PRECISE landing, two unflown cancelled | FAIL retained; simple reserve prototype rejected for STUCK; V31 scan-motion alignment still unaccepted |
| V31 mild random 3 | Restricted-zone clearance 1.2139113263915782 m FAIL; corridor .7372377792461882 m, 835 s airborne, actual disarm, zero contacts/fence breaches; field 2 and 3 navigation PASS; two unflown cancelled | FAIL preserved; V32 hazard-hold recovery remains unaccepted |
| V32 exhaustive offline attempt | Interrupted: 5 failed, 1085 passed; four physical tests at mean 8 m/s/gust 4 m/s remain unresolved/deferred; QR fixture failed six-replan count, corrected cadence passes unchanged count/skip/coverage assertions; all five navigation flights passed/disarmed | Original failures preserved; never a full offline PASS; V33 explicit scope is unaccepted |
| V33 field 3 | Delivery QR and return gate found; alignment lost lettering at inherited custom camera tilt after approach, failed seven vantages; safe return and actual disarm, zero contacts/fence breaches; other four targeted navigation cases passed | Original failure preserved; V34 normal-startup camera settlement fix remains unaccepted |
| V34 mild random 3 | Corridor clearance 0.656 m during gate crossing/braking, zero contacts/fence breaches, actual disarm; field 2/3 navigation passed; two unflown cases cancelled | Original failure preserved; V35 physical braking hold remains unaccepted |
| V35 mild random 4 | Return corridor below 0.30 m floor for eight samples; corridor clearance 0.734 m, zero contacts/fence, actual disarm; DEGRADED landing retained; other four cases passed navigation | Original failed grade preserved; V36 physical vertical hold remains unaccepted |
| V36 mild random 3/4 | Random 4 gate history guard failed, board contact during abort, actual disarm; random 3 deadlines/capture gap, return stopped, flight over 900 s, battery return and actual disarm; stop watchdog timed out | Both failures preserved; three queued cases unflown; V37 remains unaccepted |
| V37 offline integration | Five navigation passes; complete offline suite 8 failed, 1687 passed, 8 skipped; UI state and seven inside-margin stationary-hold fixtures | Complete failed suite preserved; V38 source and fixture corrections remain unaccepted |
| Strong gust/delayed control | Preserved obstacle contacts and other failures | Deferred, unresolved, excluded |

## Appendix B: source versions and issue inventory

Key frozen source archives are listed below. All remain historical or provisional; none is the final accepted version.

| Version | Controlled files | Frozen archive SHA256 |
|---|---:|---|
| V34 | 944 | `34aad95e05f1fface7dd8b931892fb1d909d86e7004d2b7af554e2cc694dbd15` |
| V35 | 946 | `b97b74647bb4531e0b7f359d9653e726ab4276e7c0045bf19844c1dfd0aaa510` |
| V36 | 949 | `7a0e5214e6f25a3180c8ff4e10f79731074e55b8584d34db7634794a85d65dc2` |
| V37 | 949 | `de2a300afd15027061feebdba752efb8c0ab294041bfbd471a96cf5cd59722fb` |
| V38 | 949 | `eb38b8d828445196fa6716461bd42f66c94ce90fb4b72b696d22b40129f2d213` |
| V39 | 951 | `000dd0834aff203801af9fa8980597634b846ab7806084ed907719478ff2671e` |

Local issues still carry their original triage labels. Many describe code that has since changed but still lacks final qualification closure. An open label should not be read as proof that every historical bug reproduces on V39. Issues 08, 23, 26, 37, 40, 41 and 42 carry the main remaining clearance/search/qualification thread; 10/15 cover deferred gust/delay; 06 covers hardware work.

- [01: Reject clipped return-banner positions](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/01-reject-clipped-return-sightings.md>) | ready-for-agent
- [02: Preserve a corridor stall until movement earns a new window](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/02-preserve-stall-until-progress.md>) | ready-for-agent
- [03: Resolve the off-axis chicane outside the navigator's envelope](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/03-offaxis-corridor-envelope.md>) | ready-for-agent
- [04: Verify detector-rate pacing in rendered Gazebo and SITL](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/04-rendered-camera-rate-validation.md>) | ready-for-agent
- [05: Repeat the simulation matrix after targeted acceptance](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/05-navigation-campaign-evidence.md>) | ready-for-agent
- [06: Hardware qualification and staged flights](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/06-deferred-hardware-and-flights.md>) | ready-for-human
- [07: Optional camera report crashes after motor confirmation](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/07-motor-confirmation-camera-report.md>) | ready-for-agent
- [08: Rendered return-corridor clearance failure](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/08-rendered-return-clearance.md>) | ready-for-agent
- [09: Provisional motor unloading and retry observation windows](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/09-provisional-delivery-probe.md>) | ready-for-agent
- [10: Gusts can exceed the certified hold margin in the split corridor](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/10-gust-braking-margin.md>) | ready-for-agent
- [11: Static equipment mounts must not admit simulator vehicle pose](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/11-static-mount-input-isolation.md>) | ready-for-agent
- [12: Deployment transients should not spend release attempts](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/12-unconfirmed-touchdown-candidate.md>) | ready-for-agent
- [13: Return search exceeds the full mission time budget](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/13-return-search-repeated-turns.md>) | ready-for-agent
- [14: Match headless command transport to the avoidance model](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/14-headless-command-transport.md>) | ready-for-agent
- [15: Physical transport delay and gusts still violate corridor clearance](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/15-delayed-gust-control-margin.md>) | ready-for-agent
- [16: Fresh calm rendered return failed after disturbance certificate change](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/16-fresh-rendered-return-stuck.md>) | ready-for-agent
- [17: Include transmitted yaw in corridor motion certification](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/17-yaw-aware-motion-certificate.md>) | ready-for-agent
- [18: Use fresh onboard EKF velocity in corridor braking](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/18-fcu-velocity-for-navigation-braking.md>) | ready-for-agent
- [19: Avoid discarding a valid oblique return-banner view](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/19-rendered-return-banner-search-delay.md>) | ready-for-agent
- [20: Compare predicted response and FCU velocity at the same time](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/20-fcu-response-sample-time.md>) | ready-for-agent
- [21: Require real FCU disarm and camera captures through landing](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/21-focused-disarm-recording-evidence.md>) | ready-for-agent
- [22: Separate unknown prior control from observed disturbance](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/22-unknown-prior-control-response.md>) | ready-for-agent
- [23: Complete current-source simulation qualification](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/23-complete-current-simulation-qualification.md>) | ready-for-agent
- [24: Recognize owned rendered output paths](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/24-rendered-runtime-capture-scope.md>) | ready-for-agent
- [25: Corrected headless return still violates clearance](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/25-corrected-headless-return-failure.md>) | ready-for-agent
- [26: Rotated rendered search loses red margin and return search exceeds flight budget](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/26-rotated-rendered-clearance-and-time.md>) | ready-for-agent
- [27: Qualify banner captures and current word evidence](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/27-banner-capture-and-word-continuity.md>) | ready-for-agent
- [28: Qualify capture-time lidar pose interpolation](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/28-scan-pose-interpolation-qualification.md>) | ready-for-agent
- [29: Recover brief observation gaps while holding the gate approach](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/29-gate-observation-pause.md>) | ready-for-agent
- [30: Exclude display annotations from camera analysis and OCR](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/30-pristine-banner-analysis-pixels.md>) | ready-for-agent
- [31: Preserve fresh FCU observer state during lidar-only stops](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/31-lidar-fault-observer-continuity.md>) | ready-for-agent
- [32: Brake the active search segment before replacing an unsafe route](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/32-stop-search-before-exclusion-replan.md>) | ready-for-agent
- [33: Include computation time before command receipt](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/33-command-certificate-computation-age.md>) | ready-for-agent
- [34: Centre repeated clipped identity before area-based distance assessment](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/34-clipped-banner-bearing-before-range.md>) | ready-for-agent
- [35: Search coverage fixtures need timestamped motion captures](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/35-search-fixture-motion-captures.md>) | ready-for-agent
- [36: Deliver onboard captures during navigation computation](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/36-capture-delivery-during-navigation-computation.md>) | ready-for-agent
- [37: Preserve sequential escape from overlapping observed exclusion margins](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/37-search-overlapping-exclusion-escape.md>) | ready-for-agent
- [38: Qualify the rendered velocity response and restore viable corridor braking](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/38-rendered-velocity-response-model.md>) | ready-for-agent
- [39: Independent vehicle contact qualification](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/39-independent-vehicle-contact-qualification.md>) | ready-for-agent
- [40: Preserve physical gate braking and corridor height through estimator wander](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/40-gate-and-corridor-motion-holds.md>) | ready-for-agent
- [41: Native return stops inside the fixed sampling reserve](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/41-native-safe-origin-continuous-certificate.md>) | ready-for-agent
- [42: Focused native return completes but fails independent contact closure](<D:/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON/.scratch/simulation-reliability/issues/42-focused-return-contact-evidence.md>) | ready-for-agent

The handoff is complete as a stopped-state report. Mission qualification remains unfinished, and work will resume only on the user's instruction.
