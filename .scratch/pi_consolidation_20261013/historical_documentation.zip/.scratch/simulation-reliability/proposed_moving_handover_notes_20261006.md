# Moving handover patch proposal

`proposed_moving_handover.patch` is prepared and has not been applied. Python
syntax parsing and `git apply --check` pass against the recorded base files.
The proposed tests have not run. No ROS node, simulator or build was launched.

The patch changes four files after the primary releases the source freeze:

- `sim/corridor_trial.py` adds moving mode and retains stationary mode by default.
- `scripts/run_recorded_acceptance.sh` validates and forwards the mode, and records
  the mode, maximum observation age, driver hash and existing fixture hash.
- The focused grader checks physical clearance against every retained native
  aircraft sample, including approach and descent. Traversal classification
  still uses crossing and return phases, so operator setup above the walls is
  not presented as a valid corridor traversal.
- `sim/test_moving_return_handover.py` adds eleven driver seam checks. These cover
  actual production GateAdvance reuse, handover on the arrival tick rather than
  after three seconds, its 0.25 m arrival boundary, latched position commands,
  stale/future/nonfinite/disconnected observations, duplicate velocity stamps,
  the stationary default and validated environment mode selection.

Moving setup visits the same recorded approach x/y and entry altitude. It yaws
toward the recorded approach-to-entry line. The unchanged production GateAdvance
then latches its destination from actual current FCU pose/yaw and remaining
distance. Its actual target is recorded. This avoids overriding the leaf's
private target or modifying the production leaf. The target can differ slightly
from the requested entry because the leaf uses measured heading. The fixture's
recorded entry yaw remains provenance. Do not claim an exact state replay.

The leaf commands position setpoints through the normal production LegRouter
with observed exclusions. Avoidance remains disabled during crossing and is
enabled on the same driver update that GateAdvance reports arrival. The patch
does not add a velocity command, alter FCU measurements, reset the aircraft's
physical velocity or wait for a low-speed condition. Actual stamped FCU pose
and velocity must be finite, nonfuture and no older than 0.7 seconds before a
moving crossing command or handover. Failure ends the trial and lands. Position
and yaw setup still use the existing operator flight, not a simulated teleport.

`entry_handover.json` records the transition stamp, actual complete pose and
velocity observations and their header stamps, velocity receipt time, measured
horizontal speed, latched gate target, arrival tolerance and fixture provenance.
The driver trace records the selected mode and fresh entry observations. The
trial result records its mode. No simulator contact, attachment or world
position is read by the driver. Native evaluation truth remains separate.

The planner's 0.70 m clearance and 0.025 m reserve are untouched. The grader's
0.70 m clearance requirement is unchanged; its sample coverage is broader.
Legacy stationary crossing and three-second settling behavior remain intact.
Adding metadata changes source/helper hashes and requires a new recorded source
snapshot before acceptance.

The primary should verify base hashes before applying, then run the eleven
prepared seam checks and the related existing GateAdvance tests. A focused
moving flight should report its measured entry velocity against the original
failure window. A mismatch is a fixture limitation. It must not be hidden or
replaced by injected values. Full current-source seed acceptances remain needed.

Proposed mode selection after applying and validating:

```bash
AEROTHON_RENDER_TRIAL=return-corridor \
AEROTHON_CORRIDOR_HANDOVER=moving \
AEROTHON_CORRIDOR_ENTRY=.scratch/simulation-reliability/return_entry_bannerfix_20261003.json \
bash scripts/run_recorded_acceptance.sh sim/worlds/my_world.json 20261003 NEW_OUTPUT logs/delivery_profile_20261005.json
```

For the detached launcher, pass those values as `/usr/bin/env` arguments before
the recording-runner command. Choose new job and run output directories.
`proposed_moving_handover_base_hashes.json` records the exact three modified
existing file hashes. The proposed new test is included in the unified patch.
