# Coupled control envelope and archived baseline review

Status: ready-for-agent

The standard calm rendered runs are qualified on the archived source. The additional narrow-corridor gust and 0.4 s command-delay trials are not qualified: all twelve hit an obstacle on geometrically feasible layouts. Preserve both findings. These failures do not invalidate the closed standard runs, and the standard runs do not qualify the combined disturbance cases.

This review changes no production source, test, existing helper or run output. New read-only evidence is in `coupled_snapshot_independent_review_20261006.json` and `wind_draw_characterization_20261006.json` beside this report. The independent actual-controller reproduction ran on ROS domain 225. The disturbance characterization imports only the archived `WindDrift` class through an AST; it constructs no ROS node and supplies no fixture information to a flight decision.

## Verified results

The pair report is `logs/reliability_standard_pair_handover_guard_20261006.json`. Both full standard runs pass 22/22, qualify motor delivery, and finish disarmed:

| Standard run | Armed flight duration | Native corridor clearance | Native restricted-zone clearance |
| --- | ---: | ---: | ---: |
| `logs/reliability_render_my_world_s20261003_handover_guard_20261006` | 865.0 s | 0.7258271521 m | 1.5967184497 m |
| `logs/reliability_render_my_world_s1001_handover_guard_20261006` | 880.0 s | 0.7130100272 m | 1.6248532894 m |

The latest offline log, `logs/reliability_full_handover_guard_20261006.log`, records 1367 passed, 3 skipped in 692.63 s and successful syntax/configuration/frontend checks. That is existing completed evidence; this review does not rerun it. Hardware and staged flights remain deferred.

The combined-failure coordinator is `logs/reliability_remaining_qualification_20261006/report.json`. Its source is unchanged and all twelve saved physical command-delay diagnostics fail. The following minima are **logged pre-integration point clearance**, not an exact minimum through the final contact step. Contacts are the times reported by the fixture after integration. The distinct first threshold violations use the recorded points.

| Seed | Observation condition | First physical clearance below 0.70 m | First uncertified raw zero | Contact failure time | Minimum logged clearance |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | Dirty lidar | 5.20 s | 2.40 s | 6.10 s | 0.402511517 m |
| 0 | Late scans | 5.20 s | 4.75 s | 6.10 s | 0.405968713 m |
| 1 | Dirty lidar | 7.70 s | 5.15 s | 16.50 s | 0.412441505 m |
| 1 | Late scans | 6.00 s | 5.70 s | 19.00 s | 0.400077708 m |
| 2 | Dirty lidar | 10.05 s | 9.45 s | 12.10 s | 0.402021171 m |
| 2 | Late scans | 10.00 s | 9.65 s | 12.10 s | 0.412608138 m |
| 3 | Dirty lidar | 11.75 s | 0.85 s | 12.90 s | 0.409071585 m |
| 3 | Late scans | 11.80 s | 11.40 s | 12.80 s | 0.413248880 m |
| 4 | Dirty lidar | 4.30 s | 3.60 s | 5.40 s | 0.406638771 m |
| 4 | Late scans | 10.05 s | 9.45 s | 10.70 s | 0.412015704 m |
| 5 | Dirty lidar | 4.60 s | 0.00 s | 5.40 s | 0.411578488 m |
| 5 | Late scans | 4.70 s | 4.15 s | 5.80 s | 0.406603951 m |

Use the JSON values as authoritative if a rounded table entry differs. The independent dirty seed 0 reproduction, `logs/reliability_independent_gust_envelope_baseline_20261006.json`, has exactly the same rows, failure and source hashes as the saved batch run. This is a reproduced control failure, not a conjecture based on a source read.

At 2.40 s in that reproduction, physical clearance is still 1.114356540 m, but a dirty short return gives observed clearance 0.207168162 m. The controller publishes zero and reports `braking_clearance_available=false`. At 5.20 s the physical clearance is 0.699789736 m, with fresh FCU velocity and scan evidence; it is still publishing zero. The earlier report's later 4.70 s event remains relevant but is not the first loss of a certified raw-zero response in this current trace. Other seeds can lose that certificate at startup because of the dirty observation. Rejecting an uncertain observation cannot by itself keep an aircraft stationary.

## Actual safety gaps

1. **The terminal certificate assumes an unimplemented response.** In `src/aerothon_avoidance/avoidance/avoidance/velocity_controller.py`, `motion_clear` predicts incoming queued commands, then the candidate command and a changing measured disturbance. After `delay+tau`, it sets the goal to zero ground velocity and caps braking at 0.5 m/s². A later cancellation command or active hold that produces this ground response is not scheduled or independently certified. The physical fixture instead adds a residual world velocity after the commanded velocity response, so zero actuator command leaves residual ground motion. A predicted terminal ground hold requires an actual controller and its delay/response bound.

2. **Failure to certify a stop still results in raw zero.** After travel reduction and four cancellation/braking candidates fail, the controller publishes raw zero even when its own certificate returns false. It records the false diagnostic, but continues ordinary BLOCKED/BACKOFF handling. This is an honest diagnostic but is not a clearance guarantee or safe recovery. Replace the assumption with an explicit maintained hold or early unsupported-envelope outcome while sufficient fresh-space reserve remains; do not wait until every movement starts inside the forbidden clearance region.

3. **The disturbance derivative clamp is not a physical uncertainty bound.** The observer caps its estimate at 0.8 m/s². The certificate uses a point extrapolation, not a range of attainable disturbance trajectories. There is no qualified disturbance, acceleration or jerk maximum for the physical model or actual airframe. Treating the cap as a guarantee would understate the stopping reserve.

4. **Observation corruption and delayed control must be handled together.** Dirty lidar can reject every candidate while actual ground motion persists. Late scans additionally consume free-space reserve during capture-to-use age. Fresh FCU velocity in these logs prevents a stale-telemetry explanation. A repair must track a viable stop/hold before entry, preserve commands already in transport, and explicitly handle a fresh scan that invalidates that reserve. A blind reverse or relaxed clearance cannot repair this failure.

The scratch terminal-hold, raw-zero-tail and rate-alternative changes in `coupled_hold_diagnosis_20261006.md` all contact. Its proactive position-hold experiments remain outside the corridor for 20 s with more than 1.06 m physical clearance, then fail traversal by timeout. That demonstrates a useful onboard hold mechanism in two trials; it does not demonstrate corridor traversal or a qualified uncertainty bound. Primary's additional gain and hold/release prototypes also remain unqualified. Do not present any of these as a pass.

## What the gust fixture establishes

`sim/test_corridor_stress.py` defines 8 m/s mean, a sinusoidal 4 m/s gust, and an Ornstein–Uhlenbeck process driven by Gaussian draws with parameter 1.5. That parameter is a stochastic amplitude, not a maximum turbulence speed. The draws have unbounded support. Quadratic drag, assumed 1.94 kg mass and 0.05 m² drag area, a 0.5 s residual velocity-loop time constant and 1.5 s trim response produce the residual velocity that the fixture adds to aircraft motion. The fixture is useful for control regression but is not a measured FCU/aerodynamic model.

The independent archived-class draw evaluation records the following realized maxima during the first 20 s. These are unflown disturbance sequences, not traversal results or signals given to the drone:

| Seed | Wind magnitude | Residual velocity magnitude | Residual derivative magnitude |
| ---: | ---: | ---: | ---: |
| 0 | 12.5586 m/s | 0.4852 m/s | 0.7958 m/s² |
| 1 | 12.6607 m/s | 0.4109 m/s | 0.8242 m/s² |
| 2 | 14.3865 m/s | 0.5827 m/s | 1.3206 m/s² |
| 3 | 14.7212 m/s | 0.6446 m/s | 1.0573 m/s² |
| 4 | 16.3750 m/s | 0.7915 m/s | 1.1062 m/s² |
| 5 | 12.3588 m/s | 0.4128 m/s | 0.8891 m/s² |

Five of six realized derivative maxima exceed the observer's 0.8 clamp. Over the unflown 150 s sequence, seed 0 reaches 16.8289 m/s wind, 0.8394 m/s residual velocity and 1.4379 m/s² residual derivative. The initial derivative includes the trim-to-gust transition. Finite sampled maxima do not bound later Gaussian draws.

A nominal 1.7 m opening permits a 0.30 m-wide center interval after two 0.70 m clearance requirements; the planner's extra 0.025 m on both sides reduces that interval further. Transport delay is 0.4 s and command response is 0.6 s. The current finite failures show that this controller does not keep the required reserve under those inputs. They do **not** prove that every onboard controller must fail these finite seed trajectories. A universal deterministic safety guarantee against the fixture's unrestricted Gaussian process is impossible with finite actuator authority and finite clearance. Therefore this narrow-gap gust/delay combination cannot honestly be called a qualified dynamics envelope today.

An onboard repair may attempt the preserved finite cases using measured pose/velocity and lidar, active position hold, prediction uncertainty and early rejection. Qualification must demonstrate both traversal on supported cases and a safe stop/rejection before entering an unsupported case. Use simulator geometry and disturbance draws only in the independent evaluator. Do not change the wind, delay, layout or clearance to make the regression pass. Report a failed feasible traversal as a control limitation; reserve geometric-infeasibility classification for the separate polygon-expanded geometry audit.

## Source-isolated broader campaign

The snapshot is `.scratch/qualified_navigation_baseline_20261006`. The independent review verifies all 756 archived source-file bytes, no missing files, no mismatches and no symlinks. Both qualified source manifests and both internal archive manifests are identical. Both ZIP hashes match their saved verifications:

- Standard seed 20261003: `d3f93345289d050b4fe27e9cf0b83d8952c8fb0cbcd6e3efdec905dc1c8feac1`.
- Standard seed 1001: `3b7c310ae51758f59a47f7fe445a5105aba7d85b1c601191fd42c5ea4df190f3`.

`start_snapshot_navigation_matrix_20261006.sh` prepends the snapshot package paths and changes cwd to the snapshot. `fly_headless.py` launches world/recorder/helper files by paths derived from its own snapshot location, and its `python -c` children inherit that cwd. The corrected `decision_import_verification.json` now records 14 imports, including the actual `camera_ctrl.camera_ctrl_node`, navigation process, flight modules, perception modules and fixture helpers. Their origins are under the snapshot; the independent JSON also checks their recorded hashes against the archived entries and current snapshot bytes.

The runner hashes Python/configuration/source inputs before and after the campaign. Its suffix filter omits some runtime assets such as QR text/PNG files. Repeat the independent full 756-byte comparison after campaign closure as well. Keep the baseline campaign's source label distinct from any later control repair. A newly edited producer cannot inherit this snapshot's rendered qualification.

The initial owned campaign, `logs/reliability_navigation_baseline_matrix_owned_20261006`, stopped with exit -15 after the first six jobs returned NO_OUTCOME because `Arena` could not read `materials/qr_payloads.txt`. Those outputs are preserved. They are startup/setup failures, not completed navigation trials. The qualified source archives omitted that text file and PNG materials. The new `additional_assets_manifest.json` therefore records separately copied current-workspace materials and explicitly states that the earlier archive did not contain the complete asset set. These new bytes must not be described as independently archived by the standard runs.

The actual headless path requires the QR payload text file, the archived `worlds/mission2.sdf` for layout generation, the archived `models/aerothon_quad/airframe.json` through the world helper, and the frozen world fixtures. Rendering's `qr_matrices.json` and PNG textures are not read by the imported headless layout functions. The optional motor calibration path defaults empty in this launch and the delivery leaf is replaced. No other direct external file lookup was found on the headless runtime path. Preserve the additional-asset hashes and verify them after the retry alongside the archived source files.

Headless observations are projected object-level detector outputs and ray-cast lidar, not rendered frames. `sim/navigation_mission.py` replaces the delivery leaf only in the test process, keeps the winch stowed, and explicitly marks delivery unconfirmed. Headless FCU and wind responses remain models. Headless results cannot qualify camera detector rates, motor load change, contact-only release, physical hardware, or full rendered recordings through disarm. The independent trajectory is copied to `evaluation_truth_track.csv`, while observations/commands/decisions are retained in `onboard.jsonl`; those remain distinct evidence channels.

## Remaining evidence

- Repair or explicitly reject the preserved feasible coupled-control cases with maintained 0.70 m clearance; test terminal hold and raw-zero behavior under corrupt/stale observations and queued commands.
- Complete and report the source-isolated baseline navigation matrix, all failures included. Repeat its 756-byte full check on closure and retain the actual import audit.
- Render the shipped, rotated and split courses on the final repaired source, with sensor input graph audits, native grading and uninterrupted recording through landing and disarm. Headless completion does not satisfy those trials.
- Run the final source's appropriate regressions and offline suite after any production repair; previous 1367 passing tests describe the recorded guarded source.
- Keep hardware rows unqualified in `docs/HARDWARE_QUALIFICATION_RECORD.md`, including command delay, velocity response, braking, sensor age/noise and motor-load measurements. Bench and staged flight work remain deferred under the simulation-only scope.
