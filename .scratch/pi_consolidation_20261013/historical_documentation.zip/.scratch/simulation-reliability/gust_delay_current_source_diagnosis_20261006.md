# Coupled gust and command-delay diagnosis

Production source remains unchanged. Controller SHA-256:
`76ec878ba6c5747176e6e6d5456d4295977344d75cdbc59c610451b662f40e93`.
All experiments retain 0.70 m centre-to-surface clearance, the 0.025 m
sampling reserve, the existing observation restrictions, actual body-command
transport and receipt-time heading conversion. No simulator geometry or
future disturbance enters a controller decision.

No new gust traversal pass has been demonstrated. The coordinator's twelve
dirty/late cases at 0.4 s command delay remain failures. Standard rendered
calm acceptance and broader course qualification are separate from these
focused physical diagnostics.

## Missing model assumption

The certificate treats the estimated disturbance velocity as an actuator
target: it integrates `(command + wind + t*wind_rate - ground)/tau`.
The physical fixture integrates the commanded actuator response and adds the
wind residual directly to ground velocity. When that residual changes,
ground-velocity dynamics also contain its derivative. The certificate omits
that term during command transport.

The minimal current-source red loop compiles the production `motion_clear`
function directly. A fully observed wall is 0.750 m away. Zero commands are
in transit. Disturbance velocity increases at 0.8 m/s2 over the next 0.4 s.
The certificate accepts a cancellation packet and predicts at most 0.014022 m
toward the wall. Before that packet can arrive, the unchanged discrete plant
moves 0.056000 m, leaving 0.694000 m clearance.

Commands:

```text
/usr/bin/python3 .scratch/simulation-reliability/prove_certificate_delay_wind_feedthrough_20261006.py
/usr/bin/python3 .scratch/simulation-reliability/prove_certificate_delay_wind_feedthrough_20261006.py --extra-feedthrough
```

The second command retains the original certificate and adds a direct-drift
forecast conjunct. It rejects this minimal case. That is a model regression,
not a repaired corridor traversal. The exact earlier version with corrected
receipt timing is preserved as
`prove_certificate_delay_wind_feedthrough_before_green_20261006.py`.
The first draft used an end-of-step drift convention inconsistent with the
physical fixture; that draft and its output remain preserved separately and
are excluded from the result above.

## Actual dirty0 sequence

The recording-only run reproduces the original contact at 6.1 s exactly.
It records full-precision transmitted body commands, measured heading,
observer states and every original certificate path.

At 2.40 s a false-short scan reports 0.207168 m observed clearance while the
independent physical clearance is 1.114357 m. All ten candidates fail; the
controller sends raw zero. That scan continues to constrain the next two
control samples.

The last certified packet before the later refusal is at 4.70 s. Physical
clearance is 0.842781 m and observed clearance is 0.840236 m. Predicted lateral
motion during the next 0.4 s is 0.043787 m, while actual motion is 0.089925 m.
At 4.75 s every candidate fails at the same predicted point at exactly 0.4 s,
before any new packet can affect the aircraft. More candidate choices or a
different terminal braking tail cannot repair that already lost certificate.
Actual clearance first drops below 0.70 m at 5.20 s.

Of 92 complete certified delay-interval comparisons, none directly spans the
physical breach. The largest prediction error is 0.046138 m. Therefore the
missing term is proven, but it is not established as the sole failure cause.
Temporally inconsistent short returns, a lack of reserved future hold
viability and raw-zero fallback also matter.

An independent post-flight reconstruction reproduces the physical ground
velocity to 1.1e-16 m/s and the unavoidable-delay displacement to 3.5e-15 m.
It never supplies those future physical values to the controller. Direct
drift feedthrough reduces the 4.70 s forecast error from 0.046138 to 0.016395 m.
Across 105 known-response samples, however, the worst forecast error rises
from 0.046970 to 0.060064 m. Measured rate extrapolation remains uncertain.
Correcting the point equation does not create a qualified uncertainty bound.

## Preserved experiments

| Policy | Dirty0 result | Clearance | Meaning |
| --- | --- | --- | --- |
| Original certificate recording | Contact 6.1 s | 0.402512 m logged minimum | Exact baseline reproduction |
| Original AND direct-drift certificate | Contact 6.6 s | 0.413935 m logged minimum | Stronger check alone does not repair traversal |
| Receipt-position waypoint tracking | Contact 6.2 s | 0.404104 m logged minimum | Predicting steering position alone does not repair traversal |
| Permanent first-failure rejection, 30 s | Timeout, no traversal | 0.933307 m actual minimum | Bounded safe hold only |
| Permanent first-failure rejection, 150 s | Timeout, no traversal | 0.854258 m actual minimum | Bounded safe rejection on this one seed |
| Same permanent rejection, late1 | Contact 14.1 s | 0.408598 m logged minimum | Rejection at first refusal is too late on this case |

Permanent rejection latches the aircraft's measured current position after
the first `braking_clearance_available=False` event. Position error produces
a velocity correction with gain 0.8 and cap 0.25 m/s. Every correction passes
through the unchanged original compensation and full motion certificate.
There is no release condition and no derivative-envelope assumption.
Dirty0 latches at 2.40 s at `[8.1340093, 0.3577969]` and remains clear through
150.05 s over 3001 samples. This is an onboard velocity-based position hold,
not a test of an absolute FCU position-target interface. Traversal still
fails and this one trial cannot qualify a general operating envelope.

Late1 latches at 5.70 s at `[6.8053244, 0.5101950]` but contacts at 14.1 s.
The first-failure latch is too late to maintain clearance on that case.
Dirty0's bounded safe hold cannot qualify this rejection policy generally.

Outputs:

- `logs/reliability_gust_dirty_certificate_trace_20261006.{json,log}`
- `logs/reliability_gust_dirty_external_drift_conjunct_20261006.{json,log}`
- `logs/reliability_gust_dirty_receipt_path_20261006.{json,log}`
- `logs/reliability_gust_dirty_reject_and_hold30_20261006.{json,log}`
- `logs/reliability_gust_dirty_reject_and_hold150_20261006.{json,log}`
- `logs/reliability_gust_late_reject_and_hold150_20261006.{json,log}`
- `.scratch/simulation-reliability/gust_dirty_certificate_delay_error_20261006.json`
- `.scratch/simulation-reliability/gust_dirty_direct_velocity_forecast_20261006.{json,log}`

The 18-file exact-source archive is
`current_source_gust_diagnosis_archive_20261006.zip`, SHA-256
`e5e03f472f9d2219637f20e6113dcdca6f94a015898170c34a4de018511be5b8`.
The later analysis script has SHA-256
`2df138843cb5ff7e1f4f8412e93e93f7bdbb6154ff7ebb940451092cb9899ce4`
and remains a separate stable source file.

## Next repair requirements

1. Propagate command response and observed disturbance velocity separately.
   Keep body-to-earth conversion at each actual receipt boundary. Retain the
   original check until any replacement is demonstrated at full clearance.
2. Before permitting travel, reserve a reachable braking or position-hold
   response through the unavoidable queue interval and subsequent response.
   A terminal zero-ground goal is not an actuator command under disturbance.
3. Qualify forecast errors from separate high-rate loaded/unloaded trials.
   Record measurement headers, callback times, transmitted packet times,
   actual FCU response and heading. Freeze delay/response intervals and
   disturbance prediction bounds before held-out acceptance. The derivative
   cap of 0.8 is not a measured physical bound.
4. Define explicit sensor/model rejection and qualified hold states. Short
   returns must not be discarded simply because they prevent travel.
   Re-entry needs a fresh continuous segment and a reachable hold reserve.
   A transient safe-looking scan or small current innovation is insufficient.
5. Require the coupled dirty/late delay cases to traverse without violating
   0.70 m before claiming gust qualification. A permanently held aircraft is
   a safe rejection result only. Preserve feasible-course failures honestly.

Hardware, motor-based delivery confirmation and rendered perception receive
no qualification from these offline velocity fixtures.
