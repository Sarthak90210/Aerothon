# Consolidated qualification evidence — work in progress

There is no accepted final source. Changes are provisional until the same
frozen implementation passes the requested targeted runs and full offline suite.
Earlier failures remain failures; navigation and focused trials cannot qualify
rendered perception or motor delivery. The 200-case campaign has not qualified.

The machine-readable companion is `evidence_index_20261007.json`. It records
provisional controller/router/tree hashes, per-run manifests, configurations,
detector rates where available, outcomes, remaining failures and check logs.

| Evidence | Result | Remaining failure |
|---|---|---|
| Split rendered, calm 20261003 | 17/22; landed/disarmed | Return STUCK; 0.686971 m corridor clearance; return traversal, corridor altitude, unexpected mode and zone ceiling |
| Rotated rendered, calm 20261003 | 18/22; actual RTL landing/disarm | Flight 1070.1 s; 1.48 m red clearance; return traversal and unexpected mode. Operator abort is explicitly archived after irreversible time failure. |
| Frozen field-2 QR escape repair | 12/13 navigation checks; zero contacts/fence breaches; both corridors and disarm | Flight 942.8 s exceeds 900 s. Corridor 0.730154 m and red 1.510860 m. No rendered qualification. |
| Actuator/disturbance forecast correction, dirty0 and late1 | Both physical cases contact | Not installed. Physical delay 0.4 s and response 0.6 s retained. |
| Integrated focused split return | FAILED; actual disarm and complete camera timeline verified | Recovery exhausted; native minimum 0.678049 m, return traversal fails. Stationary-entry trial omits search/delivery/gate finding. Trace-equipped repeat also fails at 0.685551 m; forecasts archived. FCU target-echo repeat also fails at 0.691816 m; actual disarm and camera timeline verified. |

Native avoidance/mission build passes. Focused controller/router checks pass 89;
normal startup/gate/mission regressions pass 204; production gate fault cases
pass 12. The first full offline run closed with 9 failed, 1402 passed and 3 skipped;
syntax, configuration and frontend pass. Corrected instantaneous fixtures pass
52 affected checks. Corrected full suite passes 1427 tests, three skipped, and
all syntax/configuration/frontend checks. Original failed logs are preserved.
Production .20 s computation budget and separate deadline tests remain.

Search capture rates on the failed split recording are QR 18.0608 Hz and red
17.9786 Hz in simulated time (host delivery 4.6854/4.6640 Hz), p95 latency about
0.24 simulated seconds. Rotated search rates are QR 18.0982 Hz and red 18.1088 Hz
(host delivery 4.7390/4.7415 Hz), p95 capture-to-processing 0.2370/0.23695 s.
Whole-recording camera rates use a different window and are preserved separately
in each summary. Detector throughput does not establish clearance or mission success.

Requirements retained: 0.70 m corridor clearance plus 0.025 m planning reserve,
1.50 m restricted zones, 900 s airborne, actual connected FCU disarm, verified
camera recording through disarm, isolated drone inputs and motor confirmation
after complete hook retraction. World/vehicle/calibration assets are archived per
run. Off-axis infeasibility remains a separate classification, not a traversal pass.

The closed target-echo repeat matched 421 unique issued velocity signatures.
First FCU echo lag upper observations are median 0.048 s and p95 0.057 s.
These are echo observations, not qualified transport bounds. Exact 0.4 s
receipt modelling invents helpful disturbance in the causal zero-wind fixture:
it approves a pulse predicted at 0.919309 m that actually reaches 0.406778 m.
Matched fast/delayed model controls reject the unsafe pulse. The additional
zero-disturbance admission check rejects that fixture but still contacts in
both coupled gust cases; it is rejected for production. The separate frozen
native return diagnostic passes all 7 focused checks at 0.702154 m minimum,
with complete traversal, verified camera timeline, actual disarm, six-node
audit and controller import/source verification. This does not qualify a
full mission or the coupled gust cases. Its source archive and closed review
are preserved in reliability_render_split_return_disturbance_guard_20261007.

Original target-echo navigation audit covers three decision nodes; the earlier
explicit capture/clock/return-driver audit passes on its own recording. Future
normal and focused audits now require the capture and clock helper nodes too.
No prior audit is silently reclassified as covering additional nodes.

The current integrated field-2 repeat finds and centers the target, completes
both corridors and disarms, but fails time at 951.7 s (12/13 navigation checks).
Corridor 0.753871 m, restricted zone 2.267071 m, zero contacts/fence breaches.
Return alignment takes about 5 s; search and return search still consume the
budget. The first launch omitted qr_payloads.txt and failed before flight;
that infrastructure failure is preserved and the corrected asset is hashed.

A new red regression proves that search braking cancels the router's certified
nearest-edge margin escape. The gate now uses the same fresh segment check;
new paint still brakes. All 125 related checks pass. The asset-complete 900-file
frozen field-2 repeat closes FAILED at 1028.9 s airborne, battery-critical
landing/disarm, with both corridors, zero contacts/fence breaches, corridor
0.753613 m and red 2.222071 m. Return alignment again loses the area-derived
stand-off and spends time on sweeps/relocations. Source/assets/disarm are
verified. The object fixture has no rendered frames or independent receipt
recording; these omissions are explicit, not recording qualifications.

The isolated oblique-viewpoint candidate retains the measured zone-side
observer for lidar alignment when the area-derived ray is over 45 degrees
off the inferred face normal. Face-on placement and outside-observer behavior
are retained in its reproduction. The 901-file frozen field-2 diagnostic closes FAILED on battery critical
landing/disarm, with missing return traversal and altitude/mode/time failures.
The original viewpoint was retained, but lowering and range rejection still
lost the return-board lead. This candidate is rejected and not installed. Separate queue
preview and combined separate-actuator/queue-preview diagnostics still
contact in dirty0 and late1, and remain rejected.

The campaign gate now requires both standard seeds and shipped/rotated/split
seed 20261003, all 22 rendered checks, live capture/clock audits and identical
current code/assets/launch/fixture source. It rejects added or changed files
and incomplete grades; 14 tests pass. The 200-case campaign has not started.
The 1427/3 full suite precedes these latest search/campaign changes; the
full offline rerun on the latest root search/campaign changes passes 1440
tests, 3 skipped, plus syntax/configuration/frontend. Its source/assets match
the pre-run 900-file freeze and all archive bytes are verified.
Further accepted controller changes will require another final-source run.

To finalize: close the current repeat, resolve remaining return/search timing and
gust failures, freeze the accepted source and configuration, pass all 22 checks
on standard 20261003/1001 and shipped/rotated/split, run the corrected 200-case
matrix, and include every failed or unqualified case in the final report.

The isolated native clearance guard is now exercising a full rendered split
mission, logs/reliability_render_split_guard_full_s20261003_20261007. Normal
startup, outbound gate and corridor are completed; search is active. The live-runner table is host elapsed time, not airborne time. Recorded
ROS/FCU transitions show entrance alignment 82.983..135.878 s, search
177.228..233.231 s, and winch deployment from 239.454 s. At the timing
review the recorded armed interval is about 210 s; no time failure is
established. No final result is available.
Owned controller/mission import resolution is verified on this live run.

The causal counterexample figure and underlying curves are archived under
logs/reliability_causal_delay_mismatch_closed_review_20261007/
zero_wind_predicted_actual_clearance_20261007.png and the adjacent JSON. They
show a controlled physical fixture, not a rendered flight or a gust envelope.


07 October continuation: the isolated guard's full rendered split mission
closed GRADE_PASS, all 22 required checks passed. Native minimum corridor
clearance is 0.7380697531 m, restricted-zone clearance 3.2156264652 m,
flight time 455.0 simulated seconds, payload error 0.10 m and home landing
offset 0.31 m. Recorded FCU disarm, calibrated motor delivery, camera timeline,
runtime/source/archive hashes and owned module imports are verified in
logs/reliability_render_split_guard_full_s20261003_20261007/closed_full_review_20261007.json.
Search QR/red captures each measured 20.0 Hz in simulated time, about 5.16 Hz
on the host; p95 simulated processing latency is 0.233/0.231 s respectively.
This closes the previously active split run. The guard remains isolated:
coupled gust cases fail and other required courses/final source are pending.

The field-2 timing audit now separates return BANNER_ALIGN (142.38 s) from
outbound alignment, and records SEARCH_QR 595.53 s, 250.13 m of captured FCU
travel. Repeated braking/replanning is present even with unchanged exclusion
counts. A minimal regression proves 2 cm cross-track motion invalidates the
exact nearest-edge escape endpoint. The root router now allows continuation
through that same nearest exit edge only if distance to every observed paint
rectangle is nondecreasing; existing paint and other-obstacle checks remain.
The reproduction first fails (1 failed, 12 passed); related tests then pass
127/127 including rejection of a diagonal that initially approaches paint.
This correction is provisional. Frozen 900-file source archive SHA256 is
23eb0534d929bf23920bc7aafe96647ca1fee2a01c116458dd16211d3c55a5d9.
A field-seed-2 object-level trial and a full offline rerun are active under
logs/reliability_monotonic_search_escape_*_20261007. No new flight result is
claimed. The prior 1440/3 suite belongs to the earlier source. The 200-case
campaign and accepted-source designation remain pending.


Latest closed tests: monotonic escape source passes 1442 tests, 3 skipped,
and all offline checks, verified against its unchanged 900-file archive.
Field seed2 finds the target at 601.70 simulated seconds (previous source
707.15) but fails return alignment and lands/disarms at 998.5 s airborne.
It has no obstacle contacts/fence breaches. Its 1.169191 m corridor minimum
does not qualify return traversal, which was not completed. Source/assets
and actual FCU disarm are verified; rendered cameras and motor delivery are
explicitly unqualified for this object-level trial.

Recorded-pose return projection corrected to the runtime 0.851919 rad HFOV:
all ten early alignment captures give zero geometrically admissible headings
on the 45-degree sweep, while the 15-degree sweep supplies admissible views.
The level camera misses the board vertically; a 20-degree look sees it.
The original 60-degree replay is retained as invalid runtime configuration,
not a qualification result. Geometry is only a detection precondition.
An isolated fine-framing candidate adds one bounded finer sweep, restoring
the look angle only above gate height, before physical relocation. It retains
the original lettering, freshness, range and lidar checks. Four component
controls pass. Its 901-file archive SHA256 is
dec801079383efa322d64caecc60da2850ead40253b8a40cb72725c27ae641df.
Field seed2 is active under logs/reliability_fine_return_framing_field_s2_navigation_20261007.
An initial launcher registration path error occurred after the valid freeze;
the existing archive was preserved and registration completed separately.

Derivative-cap-only gust diagnostic: dirty0 contacts at 6.1 s, late1 at 19.0 s;
logged preintegration minima 0.402512/0.408085 m. The exact baseline/candidate
and runner are archived in logs/reliability_derivative_cap_1_6_coupled_20261007.
Baseline class methods match current root; its startup wrapper differs.
Candidate rejected. No wider lidar filter or clearance reduction is installed.
No accepted final source or 200-case qualification exists.

## Arrival braking and independent contact continuation

Latest continuation: the 903-file arrival-anchor/framing candidate passes
field seed 1, all navigation checks, 816.3 s airborne, corridor minimum
0.758250277 m, red minimum 2.298071264 m, zero independent fixture contacts,
both corridors and actual connected disarm. Source/assets/archive verified.
Seed 2 is running against the SAME archive; seed 3 remains pending.
Archive SHA256: 9431676002ac84aabb134924689a945a19eadee0837822cec2e3f1c7331c18c2.
These are object-level navigation trials, without rendered/motor qualification.

The preceding scoped/fine source passed seeds 2 and 3 (800.8/881.4 s),
but seed 1 exceeded time at 915.3 s; it cannot be adopted. The camera-focus
source then failed seed 1 gate braking and contacted the board during RTL
at 825.24 s. Its legacy geometric contact checkbox passed incorrectly;
the unchanged run.json contact record and closed review explicitly reject
contact-free qualification. Earlier grade files remain preserved.
The real gate crossing regression fails before the measured-arrival anchor
fix, then 227 gate/fail-closed/router tests pass with the fix. Independent
headless contact grading fails five controls before correction; 20 contact
and campaign controls pass afterward. All fixture contacts must be supplied;
missing or malformed evidence cannot qualify an empty contact history.

Native contact coverage is also incomplete in earlier acceptance recordings:
evaluation_contacts.jsonl covers PAYLOAD contacts only. New passive sensors
cover each directly collidable CAD vehicle link without changing collision
geometry or mass; two structural tests pass. A normal-startup unarmed native
smoke is testing actual native topics and ground-contact canary recording.
No mission qualification is claimed for this smoke. Existing 22/22 split
guard result remains an unchanged legacy grade, not proof of new body-contact
qualification. Future final rendered runs must include vehicle contact truth.

The scoped escape root offline archive passed 1443 tests, 3 skipped, and all
syntax/configuration/frontend checks. Archive SHA256:
8f01ab5ca6fe9ae2572bae62f6e38a6998aab016075dfc1b5eac6eb6f37db70f.
Root has changed since that checkpoint (arrival braking and contact evidence);
a new full offline run is required. No accepted final source exists.

The recent 1 s empirical reserve gust diagnostic is rejected: dirty0 and
late1 both time out without traversal; late1 minimum clearance is 0.500754 m.
The dirty-calm regression also stalls (0.822993 m minimum). Original failed
launch guard logs are retained separately. No wider lidar filter, reduced
clearance, empirical recent-reserve policy or faster delay is installed.
Strong coupled gusts remain unresolved. All five final rendered acceptance
cases, corrected 200-case campaign and accepted-source report remain pending.

## Reduced scope, 08 October

08 October reduced scope supersedes the original qualification target.
Strong-gust and artificially delayed-control work is deferred, unresolved,
and excluded; all existing failures remain archived. The original 200-case
campaign will not be claimed. Concrete weather filtering selects 120 of the
200 original world/preset/seed entries and excludes 80: mean wind >4 m/s
or gust >2 m/s, outside the existing moderate field preset. Exact selected
and excluded rows are in planned_campaign_scope.json. Feasibility auditing
may classify some selected entries without flight; such entries are not passes.

Normal mission startup now contains the camera-only clipped-bearing retry,
one bounded finer return sweep, measured-arrival gate braking, the native
zero-disturbance admission guard and independent native aircraft contact
grading. Aircraft geometry, mass, thin-obstacle filtering and clearance
thresholds remain unchanged. The contact recorder subscribes to actual
entity-scoped native channels, verifies publisher liveness, records skid
contacts and unsubscribes before teardown. The unarmed clean-shutdown smoke
passes with all seven vehicle channels, 25 native clock heartbeats and 258
contact rows; earlier topic and teardown failures are preserved.
Native contact grading requires a preflight skid-to-home-pad canary,
continuous publisher/clock coverage through flight, and no unexpected
vehicle contacts. Missing or malformed evidence fails qualification.

103 focused integration checks pass. Both ROS packages build and six installed
decision modules resolve to the exact root source; startup import hashes are
archived. The first reduced trial source c57104... inadvertently coupled
removal of the physical queue to an override of the controller timing model.
All three field seed trials failed (return/time, contacts in 1 and 2); they are
preserved, never qualification passes. V2 changes only the fixture setup:
physical extra queue 0 s, controller timing model unchanged at .4 s,
normal physical actuator response .6 s and computation budget .20 s.
The 909-file V2 archive SHA256 is
bc63e99f846ee8e3f712e8364ff22835855b7c992bd8d1b53e49ed06ad758966.
V2 field seeds 1/2/3 and the full native split acceptance are running in
parallel. No accepted final source exists. One final full offline suite,
all five rendered acceptances, the selected reduced campaign and final
accepted-source report remain pending; additional fixes will invalidate any
different-source passes. Detector rates from object-level trials are not
rendered perception qualification.
