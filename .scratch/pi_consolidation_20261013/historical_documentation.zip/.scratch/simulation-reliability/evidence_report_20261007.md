# Stopped by user, executive handoff checkpoint 2026-10-10T16:58:44.085439+05:30

No qualification or mission process is active. The five V39 targeted navigation
cases passed all 13 navigation checks and actually disarmed. The short native
moving-handover return completed all seven geometric/evidence checks at
0.758286655 m clearance and connected disarm. Its separate contact-free closure
FAILED: 6805 unexpected contact records are preserved. No full V39 offline suite,
five full native acceptances, or 96-flight campaign started. V39 remains unaccepted.

Source verification at handoff confirms all 951 controlled files unchanged and
archive SHA256 000dd0834aff203801af9fa8980597634b846ab7806084ed907719478ff2671e.
Strong gusts and artificially delayed control remain unresolved and excluded.
Do not resume automatically. See EXECUTIVE_HANDOFF_20261010.md and
handoff_stop_checkpoint_20261010.json for current state. Older headings below
are chronological checkpoints and may describe work that has since stopped.

## V39 continuous-clearance candidate; qualification active

Source freeze: 951 controlled files; archive SHA256
000dd0834aff203801af9fa8980597634b846ab7806084ed907719478ff2671e. Source remains unaccepted.

The actual native safe-origin scan reproduces an early planner stop
at 0.720 m. Fixed spatial sampling reserves were applied even to
stationary origins and short forecast intervals, then the compiled
shortcut stage repeated the same rejection. V39 uses a continuous
1-Lipschitz distance lower bound and bounded subdivision, with the
unchanged 0.70 m floor and unknown-space checks. The compiled fast
path and 0.025 m grid reserve remain; a failed shortcut batch can
use that same full-clearance certificate. Filtering, thin returns,
normal timing and actuator behaviour remain unchanged.

Six new controls failed before the fix, while four safety negatives
passed. Forty focused checks now pass. The actual normal 0.6 s
airframe hold, with zero added queue, changes from 0.615 m failure
to 0.700267746 m clearance. These are focused sensor/physical seams,
not a completed native mission. All required V39 gates remain.

The original V38 native 17/22 failure is sealed with all artifact
hashes, independent truth, exact archived source, recorded RTL and
actual disarm. The separate overhead-camera demonstration remains
separate configuration evidence. Strong gusts and artificially
delayed control remain unresolved and excluded.

## User-requested bird-eye recording, qualification still paused

A fresh V38 split_corridors.json calm seed 20261003 run was recorded
with an added passive native overhead camera. The flight completed
delivery, full return traversal and actual disarm. Its own grader
reports 22/22, while the previous V38 qualification run remains
17/22 FAILED. Different observation configuration and a private
provenance adapter are documented; this demonstration is not used
to resume or complete qualification. Both records remain preserved.
The overhead capture contains 1501 frames with zero drops; the
export contains 1340 frames at original capture intervals, 446.22
seconds, including confirmed disarm. Full-speed and 4x MP4 exports
decode successfully. Source hashes verify all 949 files unchanged.
The post-disarm native contact-recorder GIL shutdown abort remains
preserved and unresolved. Two unarmed setup attempts are retained.
Closed recording proof: logs/user_birdseye_split_v38_s20261003_retry3_20261009/birds_eye_recording_closed_review.json

## Qualification paused by user; custom-world recording supplied

Current V38 split_corridors.json, calm seed 20261003 completed recording
through actual disarm. Video decode passed; simulation-time export
duration is 471.201 seconds. Delivery was confirmed. The run FAILED
17/22 acceptance checks: return became STUCK and independent clearance
fell to 0.6949338146612648 m, below unchanged 0.70 m. Safe operator RTL
returned home and disarmed; associated mode, ceiling and incomplete
return checks remain failed. Original records and stop receipt retained.
No remaining native runs or campaign were started. Source is unaccepted.
Record: logs/reliability_reduced_v38_render_split_corridors_s20261003_20261008/user_recording_delivery_checkpoint.json

## V38 targeted navigation verified

All five exact-source cases passed all 13 navigation checks, with actual
connected disarm, zero contacts/fence breaches and verified source/archive
hashes. Normal actuator response 0.6 s, zero additional transport queue,
camera 20 Hz/lidar 10 Hz, 0.20 s computation budget and RTF1 are retained.
The table is navigation-only evidence. Rendered perception and motor delivery
were not exercised. Random seed 4 retains DEGRADED landing quality.

| Preset | Seed | Corridor metres | Red metres | Airborne seconds |
|---|---:|---:|---:|---:|
| random | 3 | 0.745196781 | 2.262071264 | 823.8 |
| field | 1 | 0.728426487 | 2.368071264 | 643.2 |
| field | 2 | 0.739602153 | 2.305071264 | 634.8 |
| field | 3 | 0.750233138 | 2.319071264 | 654.6 |
| random | 4 | 0.730813181 | 2.015071264 | 657.0 |

The complete reduced offline suite PASSED: 1697 tests passed, eight
skipped (five deferred strong-gust tests, three empty photograph-corpus
tests). Syntax, configuration parsing and the frontend build also pass.
Source closure verifies all 949 controlled files unchanged. The first
rendered split-course acceptance is active; all five final native 22/22
acceptances and 96 eligible campaign flights remain unqualified. No
source is accepted yet and no original 200-case qualification is claimed.

# Current checkpoint: V38 provisional, complete offline integration correction

V38 freezes 949 controlled files, archive SHA256
eb38b8d828445196fa6716461bd42f66c94ce90fb4b72b696d22b40129f2d213. 152 integrated focused checks pass.
The camera settlement stage now has its normal CAMERA_BANNER UI state.
Flight-logic AST is unchanged after excluding only STATE_NAMES. Seven
stationary-hold fixtures previously placed their expected stopped poses
inside the observed 1.50 m red margin. The toy boundary now puts those
stops outside that unchanged margin; the requested trip still crosses
red. Every original assertion is retained. Two additional actual-command
controls require an inside-margin stop to keep escaping and require
distinct fresh captures after actual certified escape arrival. Existing
observed-exclusion, actual gate/vertical physics, camera handoff, stale
motion, braking, landing and scan-registration regressions also pass.
No world geometry, filtering, acceptance threshold or flight policy changed.

V37's five navigation passes remain archived on their original source.
Its complete reduced offline suite FAILED eight checks: one UI-state
mapping and seven invalid stationary-hold fixtures; 1687 passed, eight
skipped, with syntax/configuration and frontend checks passing. The exact
source, failure names, complete log and hashes are preserved in
failed_full_offline_closed_review.json. They are not counted as V38 passes.
No native acceptance or campaign ran on V37.

V38 runs all five targeted flights again on the final source and exact
RTF1 configuration, then one complete reduced-scope offline suite, five
native 22/22 acceptances and 96 eligible campaign flights. Strong gusts and
artificial delayed control remain unresolved and excluded. No source is
accepted yet, and no original 200-case qualification is claimed.

## V37 completed verification result

All five exact-source normal-timing navigation cases passed all 13 checks,
with actual disarm and zero contacts/fence breaches. The complete reduced
offline suite then FAILED: 8 failed, 1687 passed, 8 skipped, 3158.98 seconds.
Python/shell syntax, XML/YAML parsing and the frontend build passed. One
failure is a missing UI state for CameraBannerReturnAlignment. Seven
search-hold fixtures expect completion while still inside the observed
1.50 m exclusion margin; their interaction with the stricter escape policy
requires correction and validation. No threshold or assertion has been
waived. The source, completed failed log, exclusion ledger and exact
failure names are preserved in failed_full_offline_closed_review.json.
No native acceptance or campaign ran, and V37 is not an accepted source.

# Current checkpoint: V37 provisional, exact-clock guard and real-time flights

V37 freezes 949 controlled files, archive SHA256
de2a300afd15027061feebdba752efb8c0ab294041bfbd471a96cf5cd59722fb. 107 integrated focused checks pass.
The recorded 682.02 to 682.32 capture interval reproduces a false gate
history-gap rejection from floating-point subtraction. The gap comparison
now uses the ROS clock's integer nanosecond precision: exactly 300000000 ns
is accepted, 300000001 ns is rejected at three different clock epochs.
The 0.30 s threshold is unchanged. Specific vector-history faults are now
recorded in gate failure reasons. Prior gate braking, camera handoff,
search braking, scan registration and physical altitude fixes are retained.

V36 safely closed two failed mild-weather flights; three queued field cases
were never flown. Random 4 failed its gate motion guard, then contacted
the board during abort and eventually disarmed. Random 3 experienced
computation-deadline misses and a genuine vertical-motion capture gap;
it stopped in return corridor, exceeded 900 s, then returned on battery
abort and actually disarmed. The operator stop watchdog subprocess timed
out after 15 host seconds and terminated; this limitation is retained in
the pipeline log. No older failure is excluded or upgraded to a pass.
The recordings demonstrate delayed arrivals on this accelerated host run;
they do not establish a callback race or prove the numerical boundary was
the sole cause of the actual gate failure. Immutable source/configuration,
every failed grade, contact and actual disarm are in the closed review.
No complete offline, native or campaign qualification ran on V36.

V37 object flights use real-time simulation speed, RTF 1, with two workers.
Controller and sensor rates in simulated time, the 0.20 s computation
budget, 0.6 s normal actuator response, zero additional transport queue and
all acceptance thresholds remain unchanged. This reduces host work per
second without adding control delay. Targeted and campaign verifiers
require this exact configuration. The watchdog records timeout attempts
and retries instead of exiting and leaving later stop requests unhandled.

All five normal-timing targeted passes, the complete reduced-scope offline
suite, five native 22/22 acceptances and 96 eligible campaign flights remain
required on the final source. Strong gusts and artificial delayed control
remain unresolved and excluded. No accepted source or original 200-case
qualification is claimed.

# Current checkpoint: V36 provisional, physical corridor altitude hold verification

V36 freezes 949 controlled files, archive SHA256
7a0e5214e6f25a3180c8ff4e10f79731074e55b8584d34db7634794a85d65dc2. 98 integrated focused checks pass.
The V35 captured barometer errors replay the corridor dip through the actual
published vertical command and unchanged normal airframe: minimum 0.274 m,
below the unchanged 0.30 m airborne floor. With constant barometer errors
the same control passes. Half gain also passes that trace but retains
estimator-driven physical motion; it was not adopted. The new hold uses
signed FCU vertical displacement from the actual control handover while
retaining the commanded altitude offset, original 0.8 gain and 0.6 m/s cap.
The replay minimum becomes 0.784 m. Distinct captures integrate actual
motion; duplicate captures and repeated unchanged target messages cannot
reset the hold. Invalid or discontinuous motion fails closed until an
actual new handover. True sink, target changes, stale/missing/future/nonfinite
captures, disabling and re-enabling controls pass. This isolated vertical
replay is diagnostic evidence; horizontal flight and native delivery are
not exercised by it. No geometric truth or venue configuration is a
production input; lidar filtering and all acceptance limits are unchanged.

V35 safely closed five trials. Field 1/2/3 and mild random 3 passed all
13 navigation checks. Mild random 3 retained 0.7424024489799385 m corridor
clearance and 2.204071263555253 m red clearance, with actual precise disarm.
Mild random 4 failed return traversal when true altitude dipped below 0.30 m
for eight samples despite 0.7339558114779715 m wall clearance. Zero contacts
and fence breaches, actual disarm and DEGRADED landing are retained.
The old failed grade remains failed. No complete offline, native or campaign
qualification ran on V35.

V36 runs mild random 4/3 first, then field 2/1/3 with normal actuator
response and zero added queue. Five exact-source navigation passes remain
required before the complete reduced-scope offline suite, five native
22/22 acceptances and 96 eligible campaign flights. Strong gusts and
artificial delayed control remain unresolved and excluded. No accepted
source or original 200-case qualification is claimed.

# Current checkpoint: V35 provisional, gate physical braking hold verification

V35 freezes 946 controlled files, archive SHA256
b97b74647bb4531e0b7f359d9653e726ab4276e7c0045bf19844c1dfd0aaa510. 66 integrated focused checks pass.
The existing recorded entry replay retains 0.913 m clearance; the new
recorded braking seam changes from 0.668 m failure to 0.986 m pass with
normal 0.6 s actuator response and zero additional control queue. A fixed
estimated XY hold chased GPS changes. The new estimated-frame anchor
cancels those changes while preserving the physical arrival from distinct
continuous FCU ground velocities. Missing, malformed, nonfinite, future or
gapped vectors fail closed. Duplicate captures cannot finish braking.
Pending speed acknowledgement remains a physical hold. Altitude, freshness,
speed, settling and clearance thresholds and the lidar filter are unchanged.
These replays regenerate wind and lidar; they are diagnostic evidence,
not reconstructed ROS scheduling or rendered qualification.

V34 safely closed three trials: field seeds 2 and 3 passed navigation and
landed precisely; mild random seed 3 failed only corridor clearance at
0.6560762476749438 m, with zero contacts/fence breaches and actual disarm.
The minimum occurred during gate crossing/braking before the corridor
velocity controller was enabled. The full old failure, source, configuration
and telemetry hashes are preserved. Two queued flights were cancelled
before flight. No offline, native or campaign qualification ran on V34.

V35 runs mild random 3 first alongside field 3, then field 2/1 and mild
random 4. Five exact-source navigation passes are required before the
complete reduced-scope offline suite, five native 22/22 acceptances and
96 eligible campaign flights. Strong gusts and artificial delayed control
remain unresolved and excluded; no original 200-case qualification or
accepted final source is claimed.

# Current checkpoint: V34 provisional, return camera handoff verification

V34 freezes 944 controlled files, archive SHA256
34aad95e05f1fface7dd8b931892fb1d909d86e7004d2b7af554e2cc694dbd15. 59 focused normal-startup camera,
framing, gate-motion, corridor registration and return-climb checks pass.
The actual built return handoff went RED at the inherited -10 degree search
tilt before the change. It now restores BANNER and waits for measured camera
settlement before alignment. Existing timeout and low-view level-camera
retry remain unchanged. Stale readback, wrong measured angle and timeout
controls pass. No movement is authorized by camera framing.

V33 safely closed five targeted trials: four navigation passes, one failure.
Field seed 3 found the delivery QR and return gate, then failed alignment
after seven vantages. A custom camera tilt from distant search remained
active after the approach; subsequent clipped/missing lettering led to
230 seconds of alignment and eventual safe return. The actual connected
disarm, failure grade, zero contacts/fence breaches, source archive,
configurations and every recording/telemetry hash are retained in the closed
review. Field 1/2 and mild random 3/4 passed navigation. Random 4 retains
DEGRADED landing quality. No offline, native or campaign ran on V33.

Field 3 reruns first in parallel with mild random 3. All five exact-source
targeted passes remain required before the complete reduced-scope offline
suite, five native 22/22 acceptances and 96 eligible campaign flights.
The five strong-gust positive offline flight tests remain explicitly
excluded, with their original V32 failures preserved. Three empty photograph
corpus checks remain skipped. Neither exclusion counts as a pass.
Strong gusts and artificially delayed control remain unresolved/excluded.
The reduced campaign has 120 selected entries, 80 weather exclusions and
24 negative geometry classifications. No accepted source or original
200-case qualification is claimed. Thin obstacles and all acceptance
thresholds remain unchanged.

# Current checkpoint: V33 provisional, explicit reduced offline scope

V33 freezes 943 controlled files, archive SHA256
6998503b93f268a808b75e1108d34dd52e09d37102c373c6e64b46747f6b96f2. All 121 combined focused checks pass.
Controller and perception source bytes are unchanged from V32. The changes
are the QR regression's hazard cadence and explicit offline scope/reporting.
Its original assertions remain: at least six replans, zero skipped lanes and
coverage of every clear lane part. The actual pytest collection checks prove
that five strong-gust positive flight tests are excluded while dirty lidar,
slow-airframe checks and the negative wind-fixture guard remain included.
Default offline runs still collect and execute every test without exclusions.

V32 passed all five targeted navigation cases, including field seeds 1/2/3,
with zero contacts/fence breaches and actual connected disarm. Random seed 4
retains DEGRADED visual-landing quality. Its exhaustive offline attempt was
interrupted for diagnosis: five failures and 1085 passes before interruption.
Four failures use mean wind 8 m/s, gust 4 m/s and are unresolved/deferred.
The fifth was the QR regression fixture timing. Python/shell syntax, config
parsing and frontend build passed. The original interrupted log, exact grades,
source archive, recordings and disarms are retained. No native or campaign
was executed on V32. No exhaustive offline pass is claimed.

Five targeted cases now rerun against the complete V33 freeze. The complete
reduced-scope offline suite follows, with five strong-gust flight tests
explicitly skipped and recorded, plus the three empty photograph corpus
skips. Neither exclusion is a pass. Five native 22/22 acceptances and the
96 eligible campaign flights remain pending. No accepted source exists.
Strong gusts and artificially delayed control remain unresolved and excluded.
The campaign retains 120 selected entries, 80 weather exclusions and 24
negative geometry classifications. No original 200-case qualification is
claimed. Acceptance thresholds and thin obstacles remain unchanged.

# Current checkpoint: V32 targeted navigation passed; final qualification pending

All five exact-source targeted cases passed all 13 navigation checks,
with zero contacts/fence breaches and independently recorded connected
actual disarm. Field seeds 1, 2 and 3 and mild random seeds 3 and 4 passed.
Native perception and motor delivery remain unqualified. Random seed 4
retains its DEGRADED visual-landing label; it is not upgraded to PRECISE.

| Conditions | Seed | Corridor m | Restricted-zone m | Airborne s |
|---|---:|---:|---:|---:|
| random | 3 | 0.7406553573819102 | 2.2310712635552505 | 792.1 |
| field | 1 | 0.7397704722994515 | 2.233071263555253 | 667.4 |
| field | 2 | 0.7324389980934507 | 2.1670712635552505 | 688.4 |
| field | 3 | 0.7445042161212453 | 2.3400712635552523 | 709.4 |
| random | 4 | 0.7384869906322743 | 2.0360712635552503 | 772.7 |

The one final offline suite is next, followed by five exact-source native
22/22 acceptances and 96 eligible campaign flights. Strong gusts and
artificially delayed control remain unresolved and excluded; original
failures remain unchanged. No reduced qualification completion or
original 200-case qualification is claimed.

# Current checkpoint: V32 provisional, hazard-hold verification active

V32 freezes 941 controlled files, archive SHA256
853b371de0ab27472d5f88a272df1703cd6e0bf5dedfceab81513adb3b70a767. All 99 focused checks pass, covering search-anchor
revalidation, unknown or stale motion, obstructed escape, distinct stopping
captures, corridor registration, gate motion and visual landing capture gaps.
Normal startup resolves all 11 decision/perception modules to this freeze.

V31 safely closed three targeted navigation trials. Field seeds 2 and 3 passed
all 13 navigation checks and actually disarmed with PRECISE landing. Mild
random seed 3 passed corridor clearance (.7372377792461882 m), return, time
and actual disarm, but FAILED restricted-zone clearance at 1.2139113263915782
m against the unchanged 1.50 m requirement. All three had zero contacts and
fence breaches; two unflown trials were cancelled. These headless trials do
not qualify rendered perception or motor delivery. Original grades, source,
configurations, recordings and disarms remain in the closed failure review.

The failed minimum occurred during QR search while the controller repeatedly
held an anchor newly covered by observed restricted-zone paint. The actual
search-braking seam failed before the fix. V32 revalidates both active and
completed stationary anchors against current observed exclusions, requires
fresh measured motion, and uses the existing router to certify the nearest
edge escape. If new paint blocks that escape, it latches a fresh stationary
position. It cannot finish escape while inside the original safety margin.
Acceptance thresholds, thin obstacles, filters, actuator response and timing
are unchanged. Whole-flight restricted-zone clearance remains unverified.

Five exact-source targeted cases rerun before one final offline suite, five
native rendered 22/22 acceptances and the 96 eligible campaign flights.
No accepted source exists. Strong gusts and artificially delayed control
remain unresolved, preserved and excluded. The reduced matrix has 120
selected entries, 80 weather exclusions and 24 negative geometry
classifications; those negative entries are not passes. No original
200-case qualification is claimed.

# Current checkpoint: V31 provisional, scan-motion verification active

V31 freezes 940 controlled files, archive SHA256
8ef5b87efad7833eae8f358b418f00ab6ed2bea31ff668d80ead715197841b25. 51 focused capture/controller/landing/gate checks pass;
80 further controller, scan geometry, velocity timing and command regressions
pass. These batches overlap and are not summed as unique tests.

V30 closed three targeted trials. Field seeds 2 and 3 passed all navigation
checks and actually disarmed with PRECISE visual landing quality. Landing took
about 24 seconds on each. Mild random seed 3 landed and disarmed within the
900-second limit, but failed corridor clearance at .6908234714203971 m.
All three had zero contacts and zero fence breaches. Two unflown cases were
cancelled. Original grades, source hashes and actual disarms are retained in
the exact-source closed review. No offline suite, native or campaign was run.

At the failed clearance minimum, recorded observed clearance .7289959824800055
m exceeded independently measured truth .6908234714203971 m by about 38 mm.
Subscription timing prevents treating the two captures as exactly simultaneous.
The actual scan registration and packet/normal-airframe regression reproduces
clearance .6920706531937814 m when stationary ground velocity is accompanied
by 40 mm GPS position jitter. Scan alignment previously treated that GPS jitter
as short aircraft displacement, shifting obstacle points away from the aircraft.

V31 uses distinct fresh FCU world ground-velocity captures to integrate the
short displacement between scan capture and current pose. Broken, stale or
uncovered histories fail closed; at most .06 s of last-sample continuation is
allowed for normal pose/velocity callback skew. Capture orientation, relative
sensor mount, all original ranges, thin obstacles, filters, motion budget,
actuator response and acceptance thresholds remain unchanged. Existing paired
pose fallback is retained when no FCU velocity stream exists.

The actual registration/packet regression went RED before this fix and GREEN
after it. The recorded-entry corridor replay reaches 10.34 m progress in 22.5
s, .72650807605208 m minimum clearance, zero contacts. It regenerates lidar
and does not reconstruct ROS callback ordering or qualify a whole mission.
The earlier 50 mm reserve prototype fixed the narrow range-error seam but got
stuck in the recorded corridor at 2.93 m progress. It was rejected and was
never integrated into production.

Five targeted cases now rerun. All five passes are required before one final
offline suite, five rendered 22/22 acceptances and 96 eligible campaign flights.
No accepted source exists. Strong gusts and artificially delayed control remain
unresolved, preserved and excluded. The reduced matrix retains 120 selected
entries, 80 weather exclusions and 24 negative geometry classifications.
No original 200-case qualification is claimed.

# Current checkpoint: V30 provisional, targeted verification active

V30 freezes 939 controlled files. Archive SHA256
dfdc35d4be06d18e8871cde00147b3ff2b846af93decff25fdb74373a1701696. The change retains the latest visual horizontal
landing correction during the existing brief-loss grace period while holding
current height. Prolonged loss still invokes the original recovery; no descent
continues without visual lock. The actual descent regression went RED before
the fix; 52 focused checks passed after it. The simplified 10.79-second landing
physics replay does not reproduce the full failure and is not whole-flight
evidence. All previous failures and all acceptance thresholds remain intact.

Five targeted cases now run on this source with normal actuator behaviour and
zero injected delay. Only five passes unlock one final offline suite, five
full rendered acceptances, and the 96 eligible campaign flights. No accepted
source exists. Strong gusts and artificially delayed control remain unresolved,
preserved and excluded. No original 200-case qualification is claimed.

# Current checkpoint: V29 closed, timing failures unresolved

V29 executed three of five planned targeted navigation trials. Field seed 2
passed all navigation checks and actually disarmed at 776.60 s, with DEGRADED
visual landing quality. Mild random seed 3 and field seed 3 failed the
unchanged 900-second limit; both safely returned and actually disarmed.
All three recorded zero obstacle contacts and zero geofence breaches. Mild
seed 3 passed both corridors with .7230623482323127 m minimum clearance.
Two unflown trials were cancelled, never counted as passes. The original
failed results and all telemetry remain archived. No full suite, rendered
acceptance or campaign was run on V29. No accepted source exists.

Landing diagnosis is active. A simplified free-airframe replay finished in
10.79 s and does not reproduce the full timing failure. Replaying recorded
aircraft positions reproduces the long camera outage but cannot verify a
counterfactual controller change. A separate actual PrecisionDescent regression
does reproduce early climb toward the stale initial home-marker fix after
one missing camera result, before the existing loss grace expires. The first
candidate correction retains the latest visual horizontal target during
that existing grace while holding current height. It does not continue
descent without lock or change the prolonged-loss recovery, timeout or any
acceptance threshold. Whole-flight verification is required before adoption.

Strong-gust and artificially delayed-control failures remain unresolved,
preserved and excluded. Reduced scope remains 120 weather-selected cases,
80 weather exclusions and 24 negative geometry classifications, leaving 96
eligible campaign flights. None has qualified; original 200-case qualification
is not claimed.

# Current checkpoint: V29 provisional

No accepted source. V29 freezes 938 controlled files, archive SHA256
a65281dcfbb00b3203bf8a1ee069dfc7633c59d793c4db2c6e31519c86c7be66. All 11 normal-startup module hashes match.
91 focused checks pass, including the actual gate leaf, normal actuator
airframe, streamed lidar keep-out guard and frozen failing observation stream.

V28 closed three trials: field seeds 2 and 3 passed all navigation checks and
actually disarmed. Field 2 retained DEGRADED visual landing quality. Mild
random 3 found its return gate in 15.15 s, versus V27's 187.64 s, but later
timed out at GateAdvance. It recorded two wall contacts and .4034108728140693 m
minimum corridor clearance. Automatic RTL and actual connected disarm were
recorded; the original failed grade is preserved. Two unflown cases were
cancelled, never counted as passes. Its exact-source closed failure review,
recorded setpoints, estimate/truth alignment and original sensor data remain
archived. The contacts occurred during crossing, before the braking phase;
the late phase label did not establish a braking root cause.

The actual gate replay reproduced timeout, wall contact and .4003839764804563 m
clearance with normal .6 s response and zero transport queue. Changing only
the settle-position window did not fix it. Damping the original braking
anchor with measured velocity also did not fix it; neither prototype was
adopted. The successful change confirms signed forward crossing distance
from distinct fresh FCU world-frame ground-velocity captures since speed
admission. It retains the original measured distance, latched heading,
arrival tolerance, fresh pose/velocity/lidar requirements, .08 m/s braking
limit, three distinct braking samples, .3 s settling span and speed ACKs.
Duplicate, pre-admission, backward, sideways, stale, nonfinite and broken
capture histories cannot supply this extra arrival confirmation. The
existing position arrival path and latched streamed setpoint are retained.

The permanent replay regression went RED before the fix and GREEN after it:
crossing/braking completed in 20.8 s, minimum clearance .9145067912135068 m,
zero contact, normal physics. This is a focused diagnostic regression with
recorded estimator error and regenerated scan noise, not rendered or whole
mission qualification. No production node reads the evaluation fixture.

V29 now reruns five exact-source targeted cases, beginning with mild random 3
and field 2. Only all five passes unlock one final offline suite, five native
22/22 acceptance runs and 96 eligible campaign flights. Reduced scope remains
120 selected, 80 weather exclusions and 24 negative geometry classifications.
No campaign flight has qualified. Strong gusts and artificially delayed
control remain unresolved, preserved and excluded. No original 200-case
qualification is claimed. All acceptance limits and thin-obstacle filtering
remain unchanged.

# Current checkpoint: V28 provisional

No accepted source. V28 freezes 935 controlled files, archive SHA256
20ac779c2748d870980b75fd95f7b159ad2341f05d0abe8d3d1442b8ec7188ef. All 11 normal-startup imports match. The return-camera
restart seam and 92 related focused checks pass.

V26 closed with four navigation passes and one failure. Field seeds 1, 2 and 3
and mild random 4 passed navigation and actually disarmed. Mild random 3
failed the high-return altitude handover; automatic RTL and actual disarm
were retained. V27 closed with field seed 2 navigation PASS, corridor minimum
.7354888194818544 m and actual disarm. Mild random 3 found its delivery QR,
completed the stricter climb and entered return search. Search took 187.64 s;
the flight exceeded the unchanged 900 s limit before completing the return.
The safety watcher requested RTL, and actual connected disarm was recorded.
Zero contact and fence events were recorded in both closed V27 trials.
Three unflown cases were cancelled, never counted as passes. Both candidates'
original grades, configurations, source archives and complete file hashes
are retained in their targeted_failure_closed_review.json files.

The actual FindReturnBanner state machine reproduced a missed first orbit
view carrying its final BANNER camera tilt and exhausted second-look flag
into later orbit vantages. V28 starts each orbit vantage at FORWARD, resets
its second BANNER look, and starts a fresh heading dwell. The existing orbit
altitude, bounded speed, fence/red-ground/lidar guards and identity/range
checks remain unchanged. Captured-geometry projection showed readable level
views at later recorded orbit positions, while a 2 m raise did not repair
the early incidence-limited view. These are diagnostic replays, not rendered
qualification or a reconstruction of every runtime detector callback.

The initial focused fixture lacked the speed acknowledgement stub; that
fixture was corrected without changing production speed behavior. A premature
V28 freeze is retained under the explicitly named preverification directories;
it ran no flights and cannot qualify. The final V28 freeze is the hash above.

Five same-source targeted passes still gate one final offline suite, five
native 22/22 rendered acceptances, and 96 eligible campaign flights. The exact
reduced matrix remains 120 selected cases, 80 weather exclusions, and 24
negative geometry classifications. No campaign flight has qualified. Strong
gust and artificially delayed-control failures remain unresolved and excluded.
No original 200-case qualification is claimed. V28 retains the strict return
climb and zero-disturbance certificate; all .70 m corridor and other required
acceptance limits remain unchanged.

# Current checkpoint: V27 provisional

No accepted source. V27 freezes 934 controlled files, archive SHA256
a4291e9f8f93b0b98d008b6be6f9182a8090f8eae0b37bc2058fa6af3adb7fda.
All 11 normal-startup imports match; 226 focused checks pass. The actual
built mission reproduced the return handover failure at measured altitudes
9.41, 9.50 and 9.69 m: ClimbForReturn inherited a .60 m tolerance, while
RestoreNavigationSpeed correctly requires at least 9.70 m for a 10 m transit.
V27 finishes this particular climb within .20 m, retaining the following
.30 m guard, fresh pose, nadir settlement, acknowledgement and bounded cap.
The climb continues commanding 10 m without restoring horizontal speed early.
Other climb tolerances, target height and acceptance thresholds are unchanged.

V26 field 2 passed navigation with .7318246284671641 m minimum corridor
clearance and actual disarm. Mild random 3 found the delivery QR, but failed
at the high-return handover before return search. The original failed grade,
fresh-pose diagnosis, automatic RTL and actual disarm are preserved. The
remaining isolated V26 flights continue to close; none can qualify V27.

V27 starts its priority mild seed 3 on the already closed V26 domain 41.
Its second worker waits until the entire V26 batch closes before reusing
domain 40, maintaining at most two active flights across both candidates.
Five same-source navigation passes are still required. A failed V27 case
stops queueing unflown cases; already armed flights finish safely and retain
telemetry through actual disarm. Cancelled unflown cases are not passes.

Only five V27 targeted passes unlock one final offline suite, five full native
22/22 rendered acceptances and 96 eligible campaign flights. Reduced scope
remains 120 selected, 24 negative geometry classifications and 80 weather
exclusions. No campaign flight has qualified. Strong-gust and artificially
delayed-control failures remain unresolved and excluded. Original 200-case
qualification is not claimed. V26's conservative zero-queue certificate and
side-to-vertical framing fix are retained; no .70 m clearance or thin-obstacle
filter has been weakened.

# Current checkpoint: V26 provisional

No accepted source. V26 freezes 933 controlled files, archive SHA256
5060d02d8a7ccdf8abb852bd405651ba90231135ceb975d68e7102fad9b9fb6e.
All 11 normal-startup imports match. 122 integrated focused checks and 24
normal navigation/timing checks pass. Two actual decision seams reproduced
defects before their respective fixes:

* FindReturnBanner used one retry key for both a side crop and the horizontally
  centred vertical crop at the same vantage/tilt. Centring consumed the later
  vertical recovery. V26 includes horizontal completeness in the key. Each
  framing class still receives only one retry after distinct fresh captures;
  camera settlement and the three-adjustment tilt bound remain required.
  Clipped range remains unusable and cannot authorize gate crossing.
* The actual motion certificate skipped its zero-disturbance prediction when
  transport queue was zero. A modest .06 m/s helpful response error authorized
  a packet whose actual .6 s response/braking tail reduced clearance to
  0.6990529898953362 m. The frozen V25 publication method reproduces this with
  the normal .20 s computation budget. V26 requires both predictions even with
  zero queue. A prior narrow (.85 m) forecast test now checks refusal rather
  than authorizing a packet safe only if the estimated disturbance occurs.
  A separate wider case proves forecast compensation remains available when
  both predictions preserve the same .70 m minimum. No threshold was reduced.

V25 closed four navigation passes. Fields 1/2/3 and mild random 4 completed
and actually disarmed. Mild random 3 found its delivery QR but spent 190.85 s
in return-gate search; it failed time/unexpected mode and actual corridor
clearance 0.6849396857248734 m. Watchdog RTL was requested only after the
unchanged 900 s airborne limit; recording continued through actual disarm.
All five closed with zero contacts/fence breaches. Mild random 4 reported
DEGRADED precision, retained as a quality limitation. The exact-source closed
review preserves every failed grade and artifact. Fixture delivery remains
unmeasured and unqualified. No full offline suite was run on failed V25.

Five V26 two-worker targeted trials are active with normal .6 s response,
20 Hz camera/10 Hz lidar, .20 s computation budget and zero artificial queue.
Only five same-source navigation passes unlock one final offline suite, then
five native 22/22 rendered acceptances and 96 eligible campaign flights.
Reduced scope is 120 selected, 24 negative geometry classifications and 80
weather exclusions. No campaign flight has qualified. Strong-gust and
artificially delayed-control failures remain unresolved and excluded.
Original 200-case qualification is not claimed.

Isolated V24 corridor probes are diagnostic only. Full-entry regenerated-noise,
normal-computation and full-attitude variants passed; 12 other normal lidar
realizations also passed. Starting from the recorded near-boundary state
reproduced a .69172 m deficit, but does not prove what caused the approach.
The coherent .04 m outward-bias probe also passed and its original filename
containing "red" does not make it a reproduced failure. All diagnostic verdicts
are preserved; none replaces full-flight or native acceptance. The new modest
response-error seam proves a certificate gap, not exact causation of every
older runtime failure. Final source qualification remains required.

# Current checkpoint: V25 provisional

No accepted source. V25 freezes 931 controlled files, archive SHA256
97bb0330beb893151c3e94632ec013d560201ec5f6a594bf18cbb6359e5a1108.
All 11 normal-startup imports match; 297 focused checks pass. The actual
AlignToBanner transit reproduced a premature cancellation of the requested
2 m camera framing backoff: a still-clipped identified view passed the legacy
near-view shortcut before the backoff completed. V25 requires a complete view
for that shortcut. It preserves the existing complete near-board stop and
the bounded backoff, gate braking, perception and camera capture scheduling.

V24 closed with four of five navigation passes. Field seeds 1/2/3 and mild
random 4 passed navigation and actually disarmed with zero contacts/fence
breaches. Mild random 3 also completed and actually disarmed, but its actual
minimum corridor clearance was 0.6948520402727778 m, below the unchanged
0.70 m requirement. Airborne time was 792.1 s. This original failed grade,
source/configuration and all artifacts are preserved in the closed review.
Mild random 4's DEGRADED landing is retained as a quality limitation. Fixture
delivery is unmeasured and does not qualify motor delivery.

V25 same-source targeted trials are active with two workers, normal .6 s
actuator response, native-matching 20 Hz camera/10 Hz lidar, .20 s computation
budget and no injected transport queue. Five navigation passes are required
before one final offline suite, five full native 22/22 rendered acceptances
and 96 eligible campaign flights. No campaign flight has yet qualified.
Reduced scope remains 120 selected, 24 negative geometry classifications and
80 weather exclusions. Strong-gust and artificial delayed-control failures
remain unresolved and excluded. Original 200-case qualification is not claimed.

The V24 clearance minimum occurred in RETURN_CORRIDOR near obstacle 1.
At that sample the controller was BLOCKED, published zero horizontal velocity,
and reported no certified braking clearance. Measured lidar clearance was
0.70830 m while independent truth was 0.69485 m. Two isolated actual-controller
and normal-aircraft probes passed, at 0.72785 and 0.73045 m respectively. They
regenerated lidar streams and omit live ROS ordering, so neither reproduces
the runtime failure or qualifies a source. No speculative clearance change
has been made.

# Current checkpoint: V24 provisional

No accepted source. V24 freezes 930 controlled files, archive SHA256
c99e3bb6fb4dcbb0f74a0cb90dc3ffe13a9122cd8897fb75e6e21f9ae052b491.
All 11 normal-startup imports match; 314 focused checks pass. The actual search
leaf reproduced a camera-only framing deadlock: the same identified board was
cut off at the bottom with FORWARD and at the top with BANNER, and the recovery
oscillated between the two. V24 brackets opposing fresh vertical crops from the
same held view and commands an intermediate angle using camera_ctrl's existing
numeric-degree protocol. It allows at most three adjustments within the existing
0 to -20 degree range. Numeric requests must match the measured camera controller
readback and settled/fresh state. Duplicate, stale, unidentified, unsettled,
moved-view, changed-bearing, side-crop and exhausted cases refuse the bracket.

Framing moves only the camera. Clipped images still cannot provide accepted
range, identity acceptance or crossing permission. Body translation, altitude,
search pacing, the .30 s trust age/.08 m/s braking checks, .70 m corridor and
1.50 m red clearance, 900 s time limit, sensor schedules, lidar filters and
actuator response are unchanged from V23.

Five two-worker V24 same-source targeted navigation trials are active. They
must all pass before one final offline suite, five full native rendered
acceptances and 96 eligible campaign flights. Reduced scope remains 120
selected, 24 negative geometry classifications and 80 weather exclusions.
Strong gusts and artificial control delay remain unresolved and excluded.
Original 200-case qualification is not claimed.

## V23 closed result

V23 fields 1/2 and mild random 4 passed navigation. Field 3 and mild random 3
failed time/unexpected mode; mild random 3 also failed return. All five actually
disarmed with zero contacts/fence breaches. Their original grades are preserved
in the exact-source per-artifact closed review. Mild random 4 reported DEGRADED
precision, retained as a quality limitation. Fixture motor delivery remains
unmeasured and unqualified. No full offline suite was run on failed V23.

High return transit measured 11.04 s for field 2 and 11.46 s for mild random 3,
versus 70.64 s in the retained V22 mild failure. The acknowledged speed lease
release is integrated and retained in V24. Remaining return searches were slow:
field 3 spent 194.96 s before alignment, while mild random 3 remained searching
through watchdog return. Passive snapshots show the opposing crop pattern;
they are not a complete 20 Hz banner ledger and do not prove an exact runtime
capture streak. The large level top-crop hypothesis had zero matching observed
examples and was not adopted. The real leaf's opposing-tilt red and focused
green results drive V24 instead.

# Current checkpoint: V23 provisional

No accepted source. V23 freezes 928 controlled files, archive SHA256
8b4af0bcf992a1b55ea4c55114d8cca1effd4d5e96e3154e0c3fbcaa67bb904c.
All 11 normal-startup imports match; 272 focused checks pass. The actual normal
mission sequence failed the regression: a .65 m/s admitted search cap persisted
into the high return transit. Retained V22 mild seed 3 measurements show the
same pattern with a .60 m/s cap: 41.70 m horizontal travel took 70.64 seconds,
mean .590 m/s and median recorded velocity .600 m/s.

V23 records the previously admitted navigation cap before search. Only after
delivery, return climb and confirmed nadir camera, a new stage holds position
until the FCU acknowledges restoration bounded by that previous cap and the
existing configured navigation ceiling. Fresh pose, high altitude and camera
prerequisites are mandatory. Rejection, unavailable service and timeout fail
safely. Search pacing, .30 s capture freshness, .08 m/s braking, all acceptance
thresholds, sensors, lidar filtering and actuator physics remain unchanged.

V22 is closed: all five actually disarmed; fields 1/2/3 and mild random 4
passed navigation, while mild random 3 retained its time/return failure.
V23 five two-worker same-source targeted trials are active and must pass
before one final offline suite, five
full native rendered acceptances and 96 eligible campaign flights. Reduced
scope remains 120 selected, 24 negative geometry classifications and 80 weather
exclusions. Strong gusts and artificial control delay remain unresolved and
excluded. Original 200-case qualification is not claimed.

V22 fields 1, 2 and 3 have completed and actually disarmed. Field seed 2 passed
all navigation checks with precise landing, .730684650 m corridor clearance,
757.4 airborne seconds and .32 m home distance. Mild random seed 3 failed
return/time despite zero contacts/fence breaches and .732488875 m corridor
clearance; its original watchdog RTL and actual disarm remain preserved.
Mild random seed 4 passed navigation at 863.2 airborne seconds. Field 3
and mild random 4 reported DEGRADED precision, a retained quality limitation.
V22 cannot qualify and no full suite was run on it. Exact source/configuration,
original grades and connected disarm are closed in its per-artifact review.
V23 now owns ROOT and the new trials.

# Current checkpoint: V22 provisional

No accepted source. V22 freezes 926 controlled files, archive SHA256
bd6a5c76a5432a93a71eefb01b106851143c812a4e9aa58260b9b6e26d9bf529.
All 11 normal-startup imports match. 287 focused checks pass. V21's early-orbit
change was rejected after flight results and removed from this candidate.
V22 keeps all twelve initial search headings, then tries the existing bounded
guarded orbit before repeating a full sweep if that first sweep observed a
stable, whole, fresh non-outbound green lead. Green is observation geometry,
never identity or crossing permission. Empty/invalid leads retain normal search.

Gate crossing still requires pose, velocity and lidar age at most .30 s and
the same .08 m/s braking threshold and distinct-sample confirmation. A transient
capture gap commands only a hold, resets settling evidence, and allows .30 s
to recover before failing. It cannot cross or hand over on stale observations.
Normal timing/actuator behavior, camera/perception and lidar filters are unchanged.

Five two-worker exact-source targeted trials are running, mild random seed 3
and field seed 2 first. One final offline suite, all five native rendered
acceptances and 96 eligible campaign flights remain gated. Reduced scope is
120 selected, 24 negative geometry classifications and 80 weather exclusions.
No original 200-case qualification is claimed. Strong gusts and artificial
control delay remain unresolved and excluded.

## V21 rejected and interrupted batch

Field seed 1 passed navigation. Field seed 2 failed return after a .31-.37 s
recorded lidar-age interval triggered GateAdvance's immediate stale-data abort.
Mild random seed 3 failed return/time, and field seed 3 failed time. Those four
actually disarmed and their original grades remain failed where applicable.
Mild random seed 4's process was interrupted with last telemetry armed at
606.01 s; final disarm and final grade are unverified. The WSL simulator owning
processes were absent and WSL uptime reset on inspection. The partial batch is
not a completed qualification. Source/run manifests and archive are verified;
all telemetry and original stderr remain in the closed interrupted-batch review.

The landing probe using the recorded initial home reference and return pose
passed before any new landing change, achieving visual lock in 9.8 s. It is
a fixture diagnostic with regenerated random streams and no ROS delivery;
it does not reproduce the field seed 2 timeout or qualify landing.

# Current checkpoint: V21 provisional

No accepted source. V21 freezes 924 controlled files, archive SHA256
8e23f88b3e18959f524b83d6ec9abcbcf424af15757cdc55d4ea6914038327ce.
All 11 normal-startup imports match this freeze. A real search-leaf regression
failed before the fix: three distinct fresh whole-region captures still waited
through repeated full sweeps. V21 starts the existing guarded orbit from a
stable non-outbound whole green lead. It requires distinct capture-associated
poses, freshness, settled camera and consistent measured lead positions.
Green alone never supplies identity or gate-crossing permission. Existing
orbit bounds, fence/red/lidar guards, normal timing and all acceptance thresholds
remain unchanged. 124 focused search/capture/framing/handover/landing checks pass.

Five two-worker same-source navigation cases are active, with retained mild
random seed 3 and field seed 2 first. Final offline, five full native rendered
acceptances and 96 eligible campaign flights remain gated. Scope stays 120
selected, 24 negative geometry classifications and 80 weather exclusions.
No original 200-case qualification is claimed. Strong gusts and artificial
control delay remain unresolved and excluded. Earlier failures are preserved.

## V20 closed result

V20 is unaccepted. Fields 1, 2 and 3 and mild random seed 4 passed all 13
navigation checks. Mild random seed 3 exceeded 900 seconds and was safely
returned by the watchdog; its original time and unexpected-mode failures
remain failed. All five actually disarmed, with zero contacts or fence breaches.
Field 2 and mild random 4 reported degraded precision landing; their navigation
checks passed but this quality limitation is preserved. Fixture payload delivery
remains unmeasured and no motor delivery qualification is claimed.

The mild seed 3 search occupied simulated seconds 717.57 to 817.20. A whole
green region near the later orbit lead was visible in recorded snapshots by
724.13, but the orbit began after both complete sweeps. Snapshot green replay
uses the recorded pose and no lidar and is an approximate diagnostic, not a
complete 20 Hz identity history. The landing physics probe passed before any
new landing change, achieving visual lock in 8.6 seconds; it did not reproduce
the field seed 2 precision timeout. No landing metric change followed it.

Exact source, configuration, original grades, videos, telemetry and connected
disarm are closed in
`logs/reliability_reduced_scope_v20_source_20261008/targeted_failure_closed_review.json`.
The search diagnosis is
`logs/reliability_reduced_v20_targeted_20261008/my_world_random_s3/return_search_latency_diagnosis.json`.
Final offline, all five native rendered acceptances and the 96 eligible campaign
flights remain pending. Scope stays 120 selected, 24 negative geometry
classifications and 80 excluded weather cases. Strong gust and artificial delay
remain unresolved; original 200-case qualification is not claimed.

# Reduced-scope qualification evidence â€” incomplete

Accepted source: **none**. Reduced-scope qualification has not passed. The
original 200-case qualification is not claimed. Strong-gust and artificially
delayed-control failures remain unresolved and excluded by the user's instruction.

## Current provisional V20

No accepted source. V20 freezes 923 controlled files, archive SHA256
`ecf1a1db32d94d422929b4b8bdf3979640036e8429a27980876548f150e37175`. All 11 normal-startup imports match. Two-worker targeted trials are
active, with retained mild random 3 and field 2 first. The final offline suite,
five full native acceptances and 96 campaign flights remain gated.

V19 closed 3/5 navigation passes: field 1, field 3 and mild random 4. All five
passed QR search, both corridor traversals, .70 m clearance and the 900 s limit.
Field 2 and mild random 3 failed only home landing (1.67 and 2.19 m), with actual
disarm and zero contacts/fence breaches. Mild random 3 flew 890.5 airborne seconds
with .726310539 m corridor clearance; it remains a failed navigation result.
Original payload grades remain unqualified. The full per-artifact closure is
`logs/reliability_reduced_scope_v19_source_20261008/targeted_failure_closed_review.json`.

The normal built tree returned at 5 m while the landing leaf calculated 6.98 m
tracking floor and 8.48 m acquisition altitude. Its first tick immediately
committed without visual acquisition. The actual built-tree regression failed.
V20 commands the already-derived acquisition altitude before descent; 230 focused
checks pass. The landing diagnosis, commands and independent fixture track are
archived in `logs/reliability_reduced_v19_targeted_20261008/my_world_field_s2/landing_startup_height_diagnosis.json`.
The change does not alter LAND physics, aircraft actuator timing, perception,
return framing, lidar filtering or grading thresholds. No V19 pass is reused as
V20 qualification. Reduced scope remains 120 selected, 96 eligible flights,
24 negative geometry classifications and 80 weather exclusions; zero campaign
flights have executed. Strong-gust and artificial-delay failures remain excluded
and unresolved.

## Prior provisional V19

Frozen source: 922 files, archive SHA256 `79d3aa68390c2c0fd90ab6a449f2528ae396cc23fa3d5357f1749cc56144f5cc`. Accepted source remains
**none**. The 11 normal-startup imports match this freeze. The new return
framing correction passed 92 focused checks and is not yet mission-qualified.
`logs/reliability_reduced_scope_v19_source_20261008/change_from_v18.json`
records the controller change and the added regression file.

V18's normal-timing two-worker probe closed 4/5 navigation cases. Fields 1/2/3
passed with corridor clearances .741351961/.716641203/.729317782 m and airborne
times 780.3/776.9/777.8 s. Mild random 4 passed; mild random 3 failed return/time.
Its operator RTL, actual disarm and unchanged failed grade are preserved.
Full object-fixture payload grades remain unqualified, not motor-delivery passes.
`logs/reliability_reduced_scope_v18_source_20261008/targeted_failure_closed_review.json`
contains configurations, source identities, per-artifact hashes and disarms.

The normal LAND model now latches estimated XY and retains horizontal position
control, matching the installed ArduPilot implementation. The actual closed-loop
seam reproduced 1.2705 m wind drift before the correction; 69 focused model and
recording checks pass. The upstream source review and hashes are archived in
`logs/reliability_land_model_primary_source_20261008/primary_source_review.json`.
This remains an object model, not a replacement for native rendered acceptance.

V17's lower-load retry closed 1/3 navigation cases: field 3 passed; field 1
failed home landing at 1.54 m; mild random 3 failed return/time. All disarmed.
The latter recorded 15 distinct identified horizontally clipped return views
during alignment. These passive snapshots do not establish the full 20 Hz
capture history; the actual-leaf regression supplies the repeatable failing seam.
Diagnosis: `logs/reliability_reduced_v17_normal_timing_retry_20261008/my_world_random_s3/return_width_framing_diagnosis.json`.
Closed review: `logs/reliability_reduced_scope_v17_source_20261008/normal_timing_retry_closed_review.json`.

V19 has no final offline, rendered or campaign passes yet. All five full native
acceptances and the 96-flight matrix remain gated. Every previous failure remains
listed below; older passes are source-specific and are not final qualification.

## Prior provisional V17

The prior provisional source is V17: 920 controlled files, archive SHA256
`e5317625c74e9cce0edc19c1ad567ebe4cee48cae8aea9dc32cde810d262b25d`.
The final offline suite passed 1,544 tests, three empty real-photograph corpus
skips, and all syntax/configuration/frontend checks. Normal startup imports
match the freeze. Five simultaneous navigation cases passed 2/5 (field 2 and
retained random 4); field 1 failed return/clearance, field 3 failed time, and
retained random 3 failed time/home landing. All five actually disarmed. The
failed cases were probed with two workers after the full offline suite finished;
that retry closed 1/3 navigation passes, as recorded above.
The recorder now journals every actual winch status arrival before the next
5 Hz video snapshot; video cadence and every flight/grading threshold are unchanged.
The actual callback/contact-grader regression failed before the fix; 62 focused
checks pass, including stale/future arrivals, stowed/faulted winch, wrong phase,
off-target contact, wall contact and missing positions. Controller/perception and
the contact grader match V16 byte for byte. Source differences are archived in
`logs/reliability_reduced_scope_v17_source_20261008/change_from_v16.json`.
No earlier source evidence is counted as final qualification for V17.

## Prior-source V16 targeted navigation

| Conditions | Seed | Airborne seconds | Corridor metres | Red clearance metres | Result |
|---|---:|---:|---:|---:|---|
| random | 3 | 882.3 | 0.738496400 | 2.171071264 | 13/13 navigation; actual disarm |
| field | 1 | 751.7 | 0.740502577 | 2.184071264 | 13/13 navigation; actual disarm |
| field | 2 | 797.2 | 0.737166208 | 2.150071264 | 13/13 navigation; actual disarm |
| field | 3 | 770.2 | 0.728011360 | 2.322071264 | 13/13 navigation; actual disarm |
| random | 4 | 763.3 | 0.733465483 | 2.046071264 | 13/13 navigation; actual disarm |

Every case has zero recorded contacts and fence breaches. The full fixture
grades preserve their unqualified payload failures; those are not delivery passes.
Object-level navigation and motor delivery remain separate evidence.
Source/configuration and per-artifact hashes are in `targeted_closed_review.json`.

## Scope and configuration

The original matrix has 10 worlds Ã— 4 weather presets Ã— 5 seeds = 200 entries.
The existing moderate field envelope is mean wind â‰¤4 m/s and gust â‰¤2 m/s.
Calm and field retain 50 entries each; concrete random seeds 3 and 4 retain
20. Worst weather excludes 50; random seeds 1, 2 and 5 exclude another 30.
Thus **120 selected entries and 80 weather exclusions**.

Existing geometry checks classify 12 selected `editor_test` entries as invalid
and 12 `my_world_offaxis` entries as infeasible at the required clearance.
These are preserved negative classifications, never traversal passes. The
remaining **96 eligible flights** span eight valid worlds. Executed reduced
campaign flights: **zero**. Exact rows and reasons are in
`logs/reliability_reduced_scope_v16_source_20261008/planned_geometry_scope.json`.

Object-navigation trials use RTF2, no added transport queue, calibrated zero
extra queue in the controller model, unchanged .6 s physical actuator response,
normal controller callbacks and .20 s computation budget. Native mission startup
retains its normal timing and actuator defaults. Object fixtures cannot qualify
rendered vision, motor delivery, or video capture. Full native acceptance must
use normal mission startup, the calibrated delivery profile and actual FCU disarm.

## Current fixes and checks

Normal startup integrates camera capture scheduling, perception, measured-arrival
gate braking, bounded camera-only return framing and the motion admission guard.
The motion certificate batches exactly the same sampled trajectory points.
The 104-segment benchmark measured 6.332 ms versus 1.159 ms median, 5.465Ã— faster;
its 160-path equivalence test includes retained thin obstacle observations.

The search guard checks the current position intent rather than an obsolete
preview. V8 repeatedly braked its own completed hold. V9 allowed a single handoff
but then interrupted stationary turns. Real command-getter and leaf regressions
reproduced both. V10 keeps an exact completed hold eligible only while fresh
settled-motion evidence remains valid, clears that eligibility for any replacement
position command, and restarts the turn anchor from the measured stop position.
V11 additionally freezes the measured stopped pose for turn and speed-ACK holds,
and prevents detector/speed waits from chasing new noisy pose observations.
The focused search/router/detector/hover set passes **137** relevant checks. Unsafe replacement commands,
stale observations, distinct settled samples and the certified escape are covered.

V13 consumes actual delivered FCU velocity samples for search braking. All
three captures must remain distinct, fresh, after the brake command, and at or
below the existing .10 m/s limit; intervening motion resets the streak. Real
callback/leaf controls reproduce missed short settled intervals and previously
missed movement between leaf snapshots. Return-gate stability limits are intact.

A fixture scheduling defect tied camera captures to the 10 Hz lidar timer,
while both native vehicle definitions specify 20 Hz. The corrected object
fixture matches the existing native rate. Drops and latency are retained, and
per-run configuration now explicitly records 20 Hz camera and 10 Hz lidar.
The production native camera rate was not increased. Earlier 10 Hz fixture
results cannot qualify this source/configuration.

V14 return dwell processes all distinct fresh captured banner observations with
associated onboard poses. It preserves identity, range and confidence checks,
and enables existing bounded back-off after four identified clipped captures.
Small speed increases keep the already acknowledged lower safe cap; every
speed decrease and larger increase still requires acknowledgement. The focused
search/detector set passes 154, and return/gate set passes 252; these overlap.
Real seam red controls and green results are archived.

V15 extends the existing bounded return height recovery to yaw settlement.
Three distinct fresh identified top-cropped level-camera captures may raise
0.5 m at unchanged XY and retry the captured world bearing; maximum three
climbs and all subsequent full-identity/range/lidar requirements remain.
The real leaf reproduced the missed turn captures before the fix. The final
focused return/gate set passes 258, including stale/replay/tilted/outbound controls.

V15 extends the existing bounded return height recovery to yaw settlement; V17 retains it.
Three distinct fresh identified top-cropped level-camera captures may raise
0.5 m at unchanged XY and retry the captured world bearing; maximum three
climbs and all subsequent full-identity/range/lidar requirements remain.
The real leaf reproduced the missed turn captures before the fix. The final
focused return/gate set passes 258, including stale/replay/tilted/outbound controls.

V16 corrects a conservative merge artifact in the active-segment certificate.
The full line and both endpoints must clear every original observed rectangle
inflated by the unchanged 1.50 m margin. Merged route planning remains; starts
inside any actual margin retain the restricted nearest-edge escape. A captured
V15 issued command reproduced the false brake at the real search-braking seam.
Two red controls became green; paint crossing and 1.499 m margin controls fail
closed. Search/detector checks pass 166; focused routing/return/gate checks pass
378 (overlap, not additive). No acceptance threshold or lidar filtering changed.

Required thresholds remain .70 m corridor clearance, 1.50 m restricted-zone
clearance, 900 s airborne, complete camera evidence, independent aircraft contacts,
qualified delivery and actual connected FCU disarm. No wider lidar filter is used.

## Closed evidence and remaining failures

| Evidence | Result | Qualification limit |
|---|---|---|
| V3 fields 1/2/3 | All 13 navigation checks passed; actual disarm; zero contacts/fence | Different source; object navigation only |
| V3 offline | 1477 passed, 3 skipped; syntax/configuration/frontend passed | Different source; final suite still pending |
| V3 native split, 20261003 | 21/22; completed, motor delivery and actual disarm; .717815 m clearance | Aircraft-contact check failed; 215 lowered-jaw target-floor contact pairs |
| V5 field 3, RTF4 | Failed corridor clearance .619442 m after .36 s certificate exceeded .20 s budget | Preserved failure |
| Exact V5 field 3, RTF2 | All 13 navigation checks passed | Different source; no rendered qualification |
| V7 retained random 4 | All 13 navigation checks passed | Different source |
| V7 retained random 3 | Failed; QR search lasted 799.6 s before return; battery RTL | Remains in scope |
| V8 fields 1/2/3 and random 3/4 | All five failed in battery RTL; connected disarm verified | Completed-hold braking deadlock; archived failures |
| V9 field 1 | All 13 navigation checks passed; zero contacts/fence; disarmed, 845.1 s total sim | Different source; no delivery qualification |
| V9 retained random 3 | Failed QR time/return/mode/ceiling/red-clearance checks; recorded operator RTL and disarm | Remains in scope; turn holds repeatedly interrupted |
| V10 field 1 | All 13 navigation checks; both corridors and connected disarm, 845.7 s total sim | Different source |
| V10 retained random 3 | Failed; operator RTL after 900 s, connected disarm | Remains in scope; moving hold anchors reproduced |
| V11 retained random 3 | QR found at 802 s; failed time and return; recorded RTL/disarm | Remains in scope |
| V12 retained random 3 | Failed QR time; recorded RTL/disarm; normal native-matching camera cadence | Remains in scope; FCU sample aliasing reproduced |
| V13 retained random 3 | QR found at 712.2 s; return alignment stalled; failed return and time; recorded RTL and actual disarm | Remains in scope; capture aliasing reproduced |
| V14 retained random 3 | QR found at 676.4 s; return alignment stalled; failed return/time; RTL and actual disarm | Remains in scope; top-cropped captures during yaw settlement reproduced |
| V15 retained random 3 | 12/13 navigation checks; flight 905.0 s; failures: flight within 900 s; actual disarm; stop request preserved | Preserved failure; remains in scope |
| V16 retained random 3 | 13/13 navigation checks; 882.3 s airborne; zero contacts/fence and actual disarm | Prior source; object navigation only |
| V16 rendered split | 17/22; 18 target-floor contacts failed only winch freshness; safely interrupted, delivery confirmed and actual disarm | Preserved failure; not qualified |
| V17 parallel targeted field 1 | Return STUCK; .671739 m corridor clearance; actual disarm; no contacts | Preserved failure; remains in scope |
| V17 parallel targeted field 3 | Return/corridor passed; flight exceeded 900 s; actual disarm | Preserved failure; remains in scope |
| V17 parallel targeted random 3 | Return/corridor passed; time/home landing failed; actual disarm | Preserved failure; remains in scope |
| V17 two-worker field 1 | Return/clearance passed; home landing failed at 1.54 m; actual disarm | Preserved failure; LAND model mismatch reproduced |
| V17 two-worker random 3 | Return/time failed; operator RTL and actual disarm | Preserved failure; width-cropped return views during turning archived |
| V18 retained random 3 | Return/time failed; operator RTL and actual disarm; zero contacts/fence breaches | Preserved failure; remains in reduced scope |
| V19 field 2 | Return/time/clearance passed; home landing failed at 1.67 m; actual disarm | Preserved failure; remains in scope |
| V19 retained random 3 | Return/time/clearance passed; home landing failed at 2.19 m; actual disarm | Preserved failure; landing startup mismatch reproduced |
| V20 retained random 3 | Return/corridor clearance passed; 900 s and unexpected-mode checks failed; watchdog RTL and actual disarm | Preserved failure; 100 s return-search delay diagnosed |
| V20 field 2 and mild random 4 | All navigation checks passed; precision landing reported DEGRADED | Quality limitation retained; fixture motor delivery unqualified |
| V21 field 2 | Gate timestamp failure; failed return/mode/ceiling; actual disarm | Preserved failure; bounded hold seam reproduced |
| V21 field 3 and mild random 3 | Time failure; mild seed 3 also failed return; actual disarm | Preserved failures; early-orbit candidate rejected |
| V21 mild random 4 | Simulator interrupted with last telemetry armed at 606.01 s | Final disarm and grade unverified; never counted as a pass |
| V22 mild random 3 | QR found at 746.99 s; failed return/time; watchdog RTL and actual disarm; zero contacts/fence | Preserved failure; search speed lease leak reproduced in actual tree |
| V23 field 3 | Search 194.96 s; time/unexpected mode failed; actual disarm | Preserved failure; opposing camera crops reproduced |
| V23 mild random 3 | High transit shortened to 11.46 s; return search still failed time/return; watchdog RTL and actual disarm | Preserved failure; camera bracket candidate unaccepted |
| V23 mild random 4 | Navigation passed; precision landing DEGRADED | Quality limitation retained; fixture motor delivery unqualified |
| V24 mild random 3 | Actual clearance 0.6948520402727778 m; 792.1 s airborne; mission completed and actually disarmed | Original clearance FAIL preserved; isolated probes do not reproduce runtime |
| V24 mild random 4 | Navigation passed; landing DEGRADED | Quality limitation; fixture motor delivery unqualified |
| V25 mild random 3 | QR found; return search 190.85 s; actual corridor clearance 0.6849396857248734 m; time/unexpected mode failed; actual disarm | Original FAIL preserved; V26 fixes proven framing and certificate gaps, runtime acceptance pending |
| V25 mild random 4 | Navigation passed; landing DEGRADED | Quality limitation; fixture motor delivery unqualified |
| V26 mild random 3 | QR found; high-return speed guard rejected climb handover; automatic RTL and actual disarm | Original FAIL preserved; built mission reproduces .60 m/.30 m tolerance mismatch; V27 strict climb unaccepted |
| V27 mild random 3 | QR found and strict climb complete; return search 187.64 s; 900 s limit exceeded, watcher RTL, actual disarm | FAIL preserved; three unflown cases cancelled; camera state leak reproduced and V28 still unaccepted |
| V28 mild random 3 | Return search 15.15 s, then gate-crossing timeout and two wall contacts; corridor .4034108728140693 m; automatic RTL and actual disarm | FAIL preserved; two unflown cases cancelled; V29 ground-motion arrival still unaccepted |
| V29 timing failures | Mild random 3 and field 3 exceeded 900 s; both zero contacts/fence breaches, all corridor checks passed, automatic RTL and actual connected disarm recorded; field 2 navigation PASS with DEGRADED precision | Original failures retained in exact-source closed review; two unflown cancelled; V30 capture-gap correction unaccepted |
| V30 mild random 3 | Actual disarm within 900 s, but corridor clearance .6908234714203971 m; zero contacts/fence breaches; field 2 and 3 navigation PASS with PRECISE landing, two unflown cancelled | FAIL retained; simple reserve prototype rejected for STUCK; V31 scan-motion alignment still unaccepted |
| V31 mild random 3 | Restricted-zone clearance 1.2139113263915782 m FAIL; corridor .7372377792461882 m, 835 s airborne, actual disarm, zero contacts/fence breaches; field 2 and 3 navigation PASS; two unflown cancelled | FAIL preserved; V32 hazard-hold recovery remains unaccepted |
| V32 exhaustive offline attempt | Interrupted: 5 failed, 1085 passed; four physical tests at mean 8 m/s/gust 4 m/s remain unresolved/deferred; QR fixture failed six-replan count, corrected cadence passes unchanged count/skip/coverage assertions; all five navigation flights passed/disarmed | Original failures preserved; never a full offline PASS; V33 explicit scope is unaccepted |
| V33 field 3 | Delivery QR and return gate found; alignment lost lettering at inherited custom camera tilt after approach, failed seven vantages; safe return and actual disarm, zero contacts/fence breaches; other four targeted navigation cases passed | Original failure preserved; V34 normal-startup camera settlement fix remains unaccepted |
| V34 mild random 3 | Corridor clearance 0.656 m during gate crossing/braking, zero contacts/fence breaches, actual disarm; field 2/3 navigation passed; two unflown cases cancelled | Original failure preserved; V35 physical braking hold remains unaccepted |
| V35 mild random 4 | Return corridor below 0.30 m floor for eight samples; corridor clearance 0.734 m, zero contacts/fence, actual disarm; DEGRADED landing retained; other four cases passed navigation | Original failed grade preserved; V36 physical vertical hold remains unaccepted |
| V36 mild random 3/4 | Random 4 gate history guard failed, board contact during abort, actual disarm; random 3 deadlines/capture gap, return stopped, flight over 900 s, battery return and actual disarm; stop watchdog timed out | Both failures preserved; three queued cases unflown; V37 remains unaccepted |
| V37 offline integration | Five navigation passes; complete offline suite 8 failed, 1687 passed, 8 skipped; UI state and seven inside-margin stationary-hold fixtures | Complete failed suite preserved; V38 source and fixture corrections remain unaccepted |
| Strong gust/delayed control | Preserved obstacle contacts and other failures | Deferred, unresolved, excluded |

The passive native contact recorder covers all seven vehicle contact channels,
checks publisher/clock coverage through disarm, and requires a preflight skid
canary. New evidence includes actual contact positions and fresh winch receipt
timestamps. Intended lowered-hook contact with the target floor is classified
only with fresh onboard winch/mission state, fresh independent elevated aircraft
pose, and actual surface contact positions on the target. Airframe obstacle,
wall, stowed-hook, off-target, missing-position and stale-evidence contacts fail.
V3 lacks the new measurements and remains failed; it is not retroactively passed.

V3 split detector evidence: camera 2808 distinct captures, 5.0246 captures/s in
sim time and 1.1511 delivered/s on the host. Search QR 19.1074 captures/s sim,
4.4936 delivered/s host, .234 s p95 sim latency; red 19.0909 captures/s sim,
4.4897 delivered/s host, .232 s p95 sim latency. These rates describe that failed
run and cannot establish current-source rendered qualification.

The V16 native contact recorder aborted during shutdown with a pybind11 GIL error after disarm. Contact coverage was valid; original stderr is preserved. This cleanup issue remains unresolved.

Headless teardown sometimes logs `rcl_shutdown already called` after the
recorded final disarm. The original stderr is preserved. This cleanup issue
remains unresolved; flight and disarm checks use the preceding recorded evidence.

All earlier diagnostic outcomes, recordings and telemetry remain available via
`evidence_index_20261007.json` and the unchanged historical report
`evidence_report_20261007_prior_20261008.md`. Closed per-run reviews store source,
configuration and artifact hashes. Every prior failure retains its original grade.

## Work still required

Finish the five targeted navigation cases and final offline suite on V24, then
five full rendered acceptances (standard 20261003 and 1001; shipped, rotated and
split 20261003) and the 96-flight reduced campaign. Twenty-four negative geometry
classifications and 80 explicit weather exclusions are not passes. Preserve exact
source/configuration hashes, per-run detector rates, recordings, telemetry and
all failures. This report and machine index remain incomplete.
