# AeroTHON Mission 2 executive handoff

Prepared 10 October 2026, 16:58 IST. Workspace: `D:\MY DOCUMENTS\VIT\Team Rotor Fpv\AEROTHON`.

## Executive position

Work is stopped at the user's request. The current V39 controller candidate has passed five targeted navigation flights, including the previously failing field seed 2. All five recorded connected disarm. The short rendered split-corridor return completed with 0.758287 m minimum clearance, above the unchanged 0.70 m threshold. It did not receive evidence acceptance because its independent contact check failed. The pipeline exited before the final offline suite, five full rendered missions and the reduced campaign.

**No final source version is accepted. Reduced qualification is incomplete.** No original 200-case qualification is claimed. Strong gusts and artificially delayed control remain unresolved and excluded by the user's instruction.

The stop audit found no active mission, SITL, Gazebo, qualification worker or watchdog process. Unified execution session 43454 had already finished with exit code 1. No armed flight needed interruption during this handoff. The five object-navigation flights and focused native flight had already disarmed. The previous custom-world bird's-eye recording was delivered and remains available.

The highest priority on an authorized restart is the focused native contact failure. Preserve the original failed evidence, establish whether the unloaded scene and landing contact rules match the trial contract, and repeat into a new output directory if a correction is needed. After that, complete the final offline, native and campaign gates on one unchanged source version.

Authoritative stop record: {{.scratch/simulation-reliability/handoff_stop_checkpoint_20261010.json|Stop checkpoint and artifact hashes}}. This report supersedes older "active" headings in the historical progress files. Their chronological evidence remains preserved.

## Status against the requested work

| Workstream | Verified position at handoff | Remaining work |
|---|---|---|
| QR search, field seeds 1/2/3 | All three pass 13/13 navigation checks on V39, without added control delay | Verify real rendered detection and delivery in final full missions |
| Gate braking and corridor return | V39 also passes retained mild random seeds 3/4; short native return passes seven focused checks and clearance | Resolve focused contact closure, then pass full split mission and other courses |
| Normal startup integration | Controller, camera scheduling and perception code are integrated; build and 12 installed imports match frozen source | One complete reduced offline suite on V39; complete mission integration evidence |
| Full rendered acceptance | No required full V39 acceptance has started | Five required full missions, every check passing |
| Reduced campaign | Zero of 96 eligible campaign flights executed | Run and close all 96; record 80 weather exclusions and 24 negative geometry classifications |
| Consolidated final evidence | Source freeze, targeted closure, recordings and failures retained; stop checkpoint written | Accepted source, final detector rates, all required results and source/configuration closure |
| Strong gusts and delayed control | Failures retained; user-deferred and unresolved | Outside this qualification scope; requires separate future work |

## Current source and integration

The candidate is V39, containing 951 controlled files. A fresh handoff comparison found zero file mismatches against its frozen manifest. The frozen ZIP was rehashed successfully.

```
V39 frozen-source archive SHA256
000dd0834aff203801af9fa8980597634b846ab7806084ed907719478ff2671e
Git base commit
c6348a1fbacea45548287ba89a7fdba44a31a72c
```

The workspace contains extensive uncommitted and untracked work. The Git base alone does not identify the tested implementation. The frozen archive and manifests do. No reset, commit or push was performed for this handoff.

- {{logs/reliability_reduced_scope_v39_source_20261008/frozen_source.zip|Frozen V39 source archive}}
- {{.scratch/reduced_scope_v39_candidate_20261008/source_manifest.json|951-file source manifest}}
- {{logs/reliability_reduced_scope_v39_source_20261008/provenance.json|Source provenance}}
- {{logs/reliability_reduced_scope_v39_source_20261008/installed_startup_imports.json|12 installed decision-module paths and hashes}}
- {{logs/reliability_v39_build_20261009.log|Avoidance package build, passed}}
- {{logs/reliability_v39_startup_verify_20261009.log|Installed startup verification, passed}}

The installed import check includes the actual `FastConnectedPlanner` module used by the velocity controller, as well as mission tree, gate and search braking, local planner, commander, routing, banner captures, camera controller, banner and QR perception. This closes the earlier risk of testing only a base planner while the running controller used the compiled planner.

### Changes already integrated

1. **Continuous corridor certification, V39.** The captured native V38 scan showed a safe origin near 0.720 m, but fixed sampling reserves rejected zero-length and short forecast intervals. A second rejection occurred in compiled path shortcuts. The shared planner now uses a 1-Lipschitz clearance bound and bounded subdivision of uncertain intervals. It keeps the 0.70 m floor, unknown-space rejection, 0.025 m grid reserve and normal compiled fast path. A failed shortcut batch can use the same continuous certificate. Ten refinements are the limit. Thin obstacles and unsafe endpoints still fail closed.
2. **Physical gate hold, V35.** Gate braking uses distinct fresh measured ground velocity to integrate signed displacement and correct the hold anchor, avoiding pursuit of estimator wander. Existing speed, settling, tolerance and timeout limits remain.
3. **Physical vertical corridor hold, V36/V37.** Fresh vertical velocity tracks displacement from the enabled corridor altitude. The exact 0.30 s capture-gap boundary uses integer nanoseconds, avoiding rejection caused by floating-point representation. Missing or invalid motion evidence still faults.
4. **Camera and perception scheduling.** The normal startup code retains buffered distinct captures and capture-time registration while navigation computes. Object fixtures now match the existing native 20 Hz camera and 10 Hz lidar, with recorded drops and latency. The production camera rate was not raised to hide failures.
5. **Return camera handoff, V34.** Normal mission startup explicitly restores the banner camera pose before return alignment and waits for measured joint settlement. This addresses a custom search tilt leaking into alignment.
6. **Search and return sequencing.** Fresh settled-motion captures, bounded camera framing, corrected QR capture-gap holds, ground-motion gate advance and strict return climb completion are retained. Search holds revalidate new red exclusion evidence and preserve the existing escape rules.
7. **Observed geometry and lidar registration.** Motion registration uses fresh onboard ground velocity and captured attitude/static mount transforms. Red exclusion margins stay at 1.50 m. The rejected wider lidar filter was not adopted.
8. **V38 offline integration correction.** The banner-alignment camera stage has its UI state. Seven toy stationary-hold fixtures were corrected because their expected stop lay inside the existing red exclusion margin; original assertions remain, with added inside-margin negative controls.

Main V39 production changes are {{src/aerothon_avoidance/avoidance/avoidance/local_planner.py|LocalPlanner}} and {{src/aerothon_avoidance/avoidance/avoidance/fast_connected_planner_candidate.py|FastConnectedPlanner}}. Controls are in {{sim/test_continuous_corridor_certificate.py|Continuous-certificate regression tests}} and {{sim/fixtures/corridor_native_safe_origin_split_s20261003_20261009.json|Captured native origin fixture}}. Other integrated changes are recorded in the frozen source and historical evidence report.

## Verified V39 results

### Focused software and physical controls

Before the V39 fix, six controls failed and four safety negatives passed. After the fix, 40 focused tests passed. The actual published hold through the normal 0.6 s airframe response, with zero added queue, improved from 0.615 m minimum clearance to 0.700267746 m. Thin surfaces between clear endpoints, subthreshold origins and masked reverse space remain rejected.

The captured native input replay recreated 0.720316952 m observed clearance against 0.719975550 m in the original log. Attitude sampling error was 0.054 s. The actual compiled planner probe then found a route whose densely sampled minimum was 0.709985959 m. This is a captured sensor-input diagnostic, not an exact reconstruction of native ROS callback timing or a full mission.

Evidence: {{logs/reliability_v39_continuous_certificate_focused_20261009.log|40 passing focused checks}}, {{logs/reliability_v38_continuous_certificate_red_20261009.log|Preserved pre-fix failures}}, and {{logs/reliability_v38_native_compiled_origin_causes_20261009.json|Actual compiled planner cause probe}}.

### Five targeted navigation flights

All five pass every one of the 13 navigation checks, with zero contacts and fence breaches and actual connected disarm. This is object-level navigation evidence. Rendered images and motor delivery are not exercised; original overall `DELIVERY_UNCONFIRMED`/`FAIL` labels remain preserved.

| Preset | Seed | Corridor minimum, m | Red minimum, m | Airborne, s | Navigation |
|---|---:|---:|---:|---:|---|
| field | 1 | 0.735022 | 2.230071 | 636.7 | 13/13 |
| field | 2 | 0.721266 | 2.275071 | 647.8 | 13/13 |
| field | 3 | 0.727705 | 2.359071 | 650.8 | 13/13 |
| mild random | 3 | 0.733650 | 2.176071 | 824.6 | 13/13 |
| mild random | 4 | 0.718289 | 2.122071 | 770.6 | 13/13 |

Configuration: RTF 1, two workers on ROS domains 40/41, camera 20 Hz, lidar 10 Hz, physical actuator response 0.6 s, computation budget 0.20 s, zero injected command delay and zero extra transport queue. Native mission defaults remain the qualification reference. Random seed 4 retains a `DEGRADED` precision-landing label, although its navigation checks pass.

Evidence: {{logs/reliability_reduced_v39_targeted_20261008/report.json|Five-case report}} and {{logs/reliability_reduced_scope_v39_source_20261008/targeted_closed_review.json|Exact-source targeted evidence closure}}. Per-run onboard telemetry, commands, lidar, independent tracks, configuration, navigation grades and hashes are retained under that batch.

### Focused native split return and immediate blocker

The next pipeline stage ran the actual native moving-handover return, calm seed 20261003, CAD aircraft, unloaded payload fixture, ROS domain 30. It used a recorded onboard entry pose, with a fresh handover age limit of 0.7 s. It omitted search, outbound traversal, delivery and normal return-home landing. It is therefore a focused return test.

All seven focused checks passed. Independent clearance was **0.7582866549316181 m**. The aircraft traversed the full return lane below the walls. Connected disarm was captured at 150.345 simulated seconds and recorded at 150.4. The camera timeline decoded successfully and extended through disarm. Initial and navigation-time decision-input audits passed.

However, the separate contact closure failed. Evidence coverage is valid, all seven channels are present, and the ground canary passed. `contact_free` is false, with 6,805 unexpected contact records:

| Pair | Records | Simulated time, s | Interpretation established at handoff |
|---|---:|---|---|
| skid 1 to payload body | 6,566 | 47.328-63.994 | All precede first recorded arm at 67.4; scene is configured unloaded |
| skid 0 to ground | 126 | 146.670-151.241 | Landing/disarm interval; 106 within the recorded armed interval |
| skid 1 to ground | 113 | 146.670-151.241 | Landing/disarm interval; 93 within the recorded armed interval |

These are contact records, not independently established collision episodes. The placement/classification cause remains unverified. The ground contacts cannot all be dismissed as post-disarm cleanup. The original grade and raw events have not been altered.

The combined focused-pass/contact-valid/contact-free/canary assertion failed in the focused-stage shell. `focused_source_closed_review.json` was never created. The main pipeline exited with status 1. The full-mission grader also remains failed because the focused trial intentionally omits mission stages; its contact failure is an additional unresolved gate.

Evidence: {{logs/reliability_reduced_v39_focused_split_s20261003_20261009/focused_summary.json|Seven focused checks}}, {{logs/reliability_reduced_v39_focused_split_s20261003_20261009/grade.json|Preserved native grade and all contact events}}, {{logs/reliability_reduced_v39_focused_split_s20261003_20261009/recorded_result.json|Actual disarm}}, {{logs/reliability_reduced_v39_focused_split_s20261003_20261009/onboard_sim_time.mp4|Focused native recording}}, {{logs/reliability_v39_qualification_pipeline_20261009.log|Pipeline failure log}}, and {{.scratch/simulation-reliability/issues/42-focused-return-contact-evidence.md|New handoff issue 42}}.

## Earlier evidence and delivered recordings

### V38 reduced offline suite

V38 passed its five targeted navigation flights and a complete reduced offline suite: **1,697 passed, eight skipped**, with frontend build, syntax and configuration checks passing. The skips are five explicitly deferred strong-gust positive flight tests and three empty real-photograph corpus tests. The unrestricted suite was not qualified.

This is prior-source evidence. V39 changed both planners and added controls, so V38's offline pass cannot replace the pending V39 suite.

{{logs/reliability_reduced_scope_v38_source_20261008/full_offline_closed_review.json|V38 offline closure}} and {{logs/reliability_reduced_v38_full_offline_20261008.log|Complete V38 offline log}}.

### V38 full split qualification failure

The original normal-startup V38 split run failed **17/22**, with independent minimum clearance **0.694933815 m**. Delivery was confirmed at 0.110438 m offset, but the return became `STUCK` at 429.2 simulated seconds. The operator requested safe RTL; the aircraft returned and actually disarmed. The five failed checks cover incomplete return, above-corridor flight, unexpected mode, zone ceiling and corridor clearance. Contact evidence was valid and contact-free. Flight time was 422.1 s and landing was 0.07 m from home.

The source, configuration, recordings, received scans, controller commands and safe-stop receipt are sealed. V39 was developed from this failure. It stays failed even though a later demonstration succeeded.

{{logs/reliability_reduced_v38_render_split_corridors_s20261003_20261008/summary.json|Original 17/22 result}}; {{logs/reliability_reduced_scope_v38_source_20261008/native_split_failure_closed_review.json|Sealed failed-run evidence}}; {{logs/reliability_reduced_v38_render_split_corridors_s20261003_20261008/return_clearance_diagnosis.json|Return clearance diagnosis}}.

### User-requested bird's-eye recording

The user paused qualification and selected `split_corridors.json`, then requested a bird's-eye view instead of onboard camera video. A fresh V38 calm seed 20261003 flight used a passive fixed native overhead camera. That demonstration completed delivery, full return and actual disarm and passed its own **22/22** grade. Clearance was 0.733833424 m; flight time 441.1 s; delivery offset 0.120191357 m; landing 0.14 m from home.

The added camera and private runtime-provenance adapter give it a different observation configuration. It is retained as demonstration evidence, not final V39 qualification or a replacement for the failed V38 run. Its post-disarm contact-recorder GIL abort remains unresolved. Two earlier unarmed setup failures are preserved.

- {{logs/user_birdseye_split_v38_s20261003_retry3_20261009/birds_eye.mp4|Full bird's-eye video, 7 min 26 s}}
- {{logs/user_birdseye_split_v38_s20261003_retry3_20261009/birds_eye_4x.mp4|4x bird's-eye video, 1 min 52 s}}
- {{logs/user_birdseye_split_v38_s20261003_retry3_20261009/birds_eye_recording_closed_review.json|Recording provenance, decode and disarm closure}}

The overhead camera captured 1,501 frames with zero recorded drops. The exported video contains 1,340 frames at their capture intervals, including disarm. The full video SHA256 is `6c8e9f2a4dd074beeedb8c5f65f8d30ef683f2afd7f24d2b420f3a8620df2535`; the 4x video SHA256 is `8ba4b2fd8d7238f12a6c18ceb2afce3def5e8a06e50fc1ca44c0662c54a6037e`.

## Work remaining, in execution order

1. **Resolve the focused native contact failure.** Inspect unloaded payload placement and landing contact evidence against the existing contract. Keep airborne obstacle protection, all seven channels, the canary, continuous evidence and every threshold. Make a narrow correction only after reproducing the cause. Preserve the failed run and repeat into a new directory. If controlled source changes, freeze a new version and rerun affected targeted checks; V39 evidence must retain its original version label.
2. **Complete final startup/integration verification.** Recheck installed imports after any code/build change. The current 12-import/build proof is complete for unchanged V39; it does not cover a future correction automatically. Keep normal mission startup, camera scheduling, actuator response and perception code in the same final source.
3. **Run one complete reduced offline suite on the final integrated source.** This has not started on V39. Record exact passes, failures and all skips/exclusions. Do not repeatedly run the full suite before a relevant change or diagnostic need. V38's 1,697 passes remain useful regression history only.
4. **Pass five full rendered missions on that same source and configuration.** Required courses are standard `my_world` seeds 20261003 and 1001, `shipped` seed 20261003, `rb_rotated` seed 20261003, and `split_corridors` seed 20261003. Each must pass every required check, including clearance, qualified delivery, aircraft contacts, complete video, input audits and actual disarm. None has started on V39. The earlier rotated result remains a historical failure; no live rotated search is active.
5. **Run and close the 96-flight reduced campaign.** Start only after targeted/native gates pass. Use independent workers where practical, keep normal response and zero injected delay, and stop a failed trial safely after sufficient diagnostic evidence. Preserve cancelled and unflown cases explicitly.
6. **Close the consolidated evidence report.** Identify the accepted archive/manifest, installed modules and configurations. Include every final run, detector rates with time basis, video/telemetry hashes, actual disarm, all exclusions, geometry classifications, precision-landing limitations and every unresolved failure. Run the final closure checks before making any qualification claim.
7. **Retain deferred work separately.** Strong-gust and artificially delayed-control failures remain open. Hardware and real-camera qualification also remain separate from simulation acceptance.

## Reduced campaign accounting

The original matrix is 10 worlds x four weather presets x five seeds, or 200 entries. The selected moderate envelope is mean wind at most 4 m/s and gust at most 2 m/s.

| Accounting category | Exact cases | Treatment |
|---|---:|---|
| calm | 50 | Selected |
| field | 50 | Selected |
| mild random seeds 3 and 4 | 20 | Selected |
| worst preset | 50 | Strong weather excluded, unresolved |
| random seeds 1, 2 and 5 | 30 | Strong weather excluded, unresolved |
| Selected entries | 120 | Before geometry classification |
| Invalid `editor_test` entries | 12 | Negative geometry classification, no flight pass |
| Infeasible `my_world_offaxis` entries | 12 | Negative geometry classification at 0.70 m, no flight pass |
| Eligible navigation flights | 96 | All remain to be run |

Accounting reconciles as **200 = 80 excluded + 24 negative classifications + 96 eligible flights**. Zero campaign flights have executed. The five targeted flights are separate and do not reduce the campaign count.

The eight eligible worlds are `example_custom`, `my_world`, `rb_high_board`, `rb_long_tight`, `rb_low_board`, `rb_rotated`, `shipped` and `split_corridors`. Retained seeds are calm 1-5, field 1-5 and random 3/4 for each world, giving 12 flights per world. Artificial delay is excluded throughout, rather than counted as another set of matrix passes.

Object-navigation campaign fixtures do not qualify rendered detection or motor delivery. The five full native missions supply that evidence. {{logs/reliability_reduced_scope_v16_source_20261008/planned_geometry_scope.json|Original geometry accounting}} and {{.scratch/simulation-reliability/evidence_index_20261007.json|Current scope and exclusion index}} preserve the exact reasons.

## Detector rates and recording limits

Configured capture rate is not measured recorder rate. The table distinguishes simulated capture cadence, host delivery cadence and simulated latency. These historical measurements belong to their exact source/configuration.

| Run | Camera distinct captures | Camera capture Hz, sim | QR capture Hz, sim | QR delivered Hz, host | QR p95 latency, sim s |
|---|---:|---:|---:|---:|---:|
| V38 original failed split | 2,699 | 5.7264 | 20.0000 | 4.8181 | 0.1910 |
| V38 bird's-eye demonstration | 3,197 | 6.5165 | 20.0000 | 4.2311 | 0.1401 |
| V39 focused return | 893 | 6.2773 | Unmeasured | Unmeasured | Unmeasured |

V38 original red captures are also 20.0000 Hz sim, 4.8182 Hz host, with 0.1910 s p95 simulated latency. The demonstration red captures are 20.0000 Hz sim, 4.2309 Hz host, with 0.13605 s p95 simulated latency. V39 focused return had no search phase, so zero search detector observations cannot qualify QR/red detection. Its camera p95 simulated latency is 0.023 s; the source video timeline is 142.251 s and decodes through disarm.

The V39 object trials contain synthetic detector outputs and empty image recordings by design. Final rendered detector-rate evidence remains pending. Three skipped empty real-photo corpus tests also leave physical camera validation unproven.

## Unresolved failures and risks

- **Current contact blocker.** Focused return scene/contact classification is unresolved, issue 42. Keep its 6,805 unexpected records and failed closure.
- **Full rendered reliability.** V38 original split clearance failure remains; V39 full split and rotated course are unverified. Earlier rotated time/red-clearance failures remain preserved. Passing a short return segment does not establish normal full-mission behaviour.
- **Strong gusts and added delay.** Existing obstacle contacts and return-gate failures are deferred, not fixed. The wider lidar filter was rejected because it can erase thin obstacles.
- **Host timing sensitivity.** V36 had real deadline/capture-gap failures even without artificially injected delay. RTF 1 and exact capture-time guards are retained. Final native runs must expose actual timing rather than weakening guards.
- **Landing quality.** V39 mild random seed 4 remains `DEGRADED` despite navigation acceptance. Record this quality limitation in the final report.
- **Native recorder shutdown.** The pybind11 GIL shutdown abort occurred in prior native runs, including the bird's-eye demonstration after disarm. Preserve stderr/core evidence; do not call the cleanup issue resolved.
- **Headless shutdown.** Some prior runs report `rcl_shutdown already called` after actual disarm. The error is unresolved and must remain separate from recorded flight/disarm evidence.
- **Historical incomplete evidence.** V21 mild random seed 4 was interrupted while the last telemetry remained armed at 606.01 s. Its final disarm/grade is unverified. No pass may be assigned retroactively.
- **Physical validation.** Real-camera corpus, motor/load calibration on actual hardware, full sensor/FCU/winch integration and staged real flights are not qualified by this simulation work. Issue 06 is `ready-for-human`.
- **Environment startup.** The handoff's first WSL inspection failed with `CreateInstance/CreateVm/ConfigureNetworking/0x8007054f`; a retry succeeded and proved no active process. Mirrored-network fallback is a restart risk, not an aircraft result.
- **Documentation lag.** Earlier report paragraphs refer to old V24/V38 work as pending or active. Current stop preambles and this report are authoritative. The machine index now marks `stopped_by_user`, no accepted source and zero campaign flights.

## Restart instructions for the next owner

Do not restart until the user authorizes continuation. No new trial or test is part of this handoff.

The pipeline launcher cannot simply be rerun: its first targeted output directory already exists and its worker uses `mkdir(exist_ok=False)`. It would fail or require unsafe reuse. Preserve completed targeted evidence and resume from the unresolved focused stage, using fresh repeat paths and updated closure references as needed. Do not delete or overwrite previous outputs to make the pipeline start.

The focused-stage helper is {{.scratch/simulation-reliability/run_reduced_v39_focused_split_20261009.sh|Focused moving-return stage}}. Its stricter contact closure is the point that failed. The next stages, when authorized and prerequisite gates are valid, are:

```bash
# Run from the WSL repository, after source and prerequisite checks.
bash .scratch/simulation-reliability/run_reduced_v39_full_offline_20261008.sh
bash .scratch/simulation-reliability/run_reduced_v39_split_render_20261008.sh
bash .scratch/simulation-reliability/run_reduced_v39_remaining_rendered_20261008.sh
bash .scratch/simulation-reliability/run_reduced_v39_campaign_20261008.sh
python3 .scratch/simulation-reliability/close_reduced_v39_qualification_20261008.py
```

These are sequencing references, not instructions to bypass unresolved gates. Full rendered and campaign trials require their matching watchdogs, fresh outputs and normal launcher defaults. The final closer explicitly requires the missing focused source closure, final offline closure, 12 startup imports, all five native records and 96 campaign results. If source/configuration changes, prepare a new candidate and adjust helpers and final closure coherently.

Environment: WSL Ubuntu user `sarthak`, ROS Jazzy at `/opt/ros/jazzy`, native overlay `$HOME/aerothon_stack/install/setup.bash`, repository `install/setup.bash`, Node `/home/sarthak/.nvm/versions/node/v24.18.0/bin/node`. Native stages use ROS domain 30; headless targeted workers use 40/41; offline uses 20. The Windows workspace maps to `/mnt/d/MY DOCUMENTS/VIT/Team Rotor Fpv/AEROTHON`. Check live availability before reuse.

The calibrated delivery profile is {{logs/delivery_profile_20261005.json|Delivery profile}}. Native acceptance uses the CAD aircraft with loaded payload, normal mission startup and independent passive evaluators. Simulator truth and evaluation cameras must not enter navigation decisions. Both initial and navigation-time input audits are required.

On a failed armed trial, request safe RTL through the owned MAVROS domain and confirm actual connected disarm before stopping child processes. Preserve each stop attempt and mode receipt. Do not kill an armed process group. Watchdogs exist for targeted, native and campaign stages, with retained timeout receipts and retries.

## Evidence locations and preservation rules

The latest checkpoint hashes every existing focused-native artifact, including onboard/lidar/command logs, camera/video, independent aircraft/contact truth, grade, source and runtime configuration. Targeted closure already hashes its five runs. Historical failures retain their original grades and source versions.

- {{.scratch/simulation-reliability/status.md|Current status with historical checkpoints}}
- {{.scratch/simulation-reliability/evidence_report_20261007.md|Consolidated working evidence history}}
- {{.scratch/simulation-reliability/evidence_index_20261007.json|Machine-readable evidence index}}
- {{.scratch/simulation-reliability/handoff_inventory_20261010.jsonl|Read-only handoff inventory}}
- {{.scratch/simulation-reliability/run_v39_qualification_gates_20261008.py|Prepared qualification sequencing}}
- {{.scratch/simulation-reliability/close_reduced_v39_qualification_20261008.py|Final acceptance and evidence closure requirements}}
- {{VERIFICATION.md|Repository verification history}}

Legacy `20261008` suffixes identify established candidate/output naming. Actual preparation/run timestamps may be 9 October, and this stop audit is 10 October. Use recorded timestamps and manifests, not directory names alone.

Reuse evidence only if source, configuration, evaluation tools and required scope match. Preserve recordings and telemetry per run, including failed, interrupted, cancelled and setup attempts. Do not weaken 0.70 m corridor clearance, 1.50 m restricted clearance, 900 s airborne limit, contact evidence, qualified delivery or actual disarm. No earlier failure becomes a pass because a later trial succeeds.

## Appendix A: preserved failure ledger

The following historical ledger is copied from the working evidence report without changing prior outcomes. References to a candidate being "unaccepted" describe that checkpoint. They do not undo later focused results, and they do not establish final acceptance. New V38/V39 outcomes are covered above.

{{HISTORICAL_LEDGER}}

## Appendix B: source versions and issue inventory

Key frozen source archives are listed below. All remain historical or provisional; none is the final accepted version.

| Version | Controlled files | Frozen archive SHA256 |
|---|---:|---|
| V34 | 944 | `34aad95e05f1fface7dd8b931892fb1d909d86e7004d2b7af554e2cc694dbd15` |
| V35 | 946 | `b97b74647bb4531e0b7f359d9653e726ab4276e7c0045bf19844c1dfd0aaa510` |
| V36 | 949 | `7a0e5214e6f25a3180c8ff4e10f79731074e55b8584d34db7634794a85d65dc2` |
| V37 | 949 | `de2a300afd15027061feebdba752efb8c0ab294041bfbd471a96cf5cd59722fb` |
| V38 | 949 | `eb38b8d828445196fa6716461bd42f66c94ce90fb4b72b696d22b40129f2d213` |
| V39 | 951 | `000dd0834aff203801af9fa8980597634b846ab7806084ed907719478ff2671e` |

Local issues still carry their original triage labels. Many describe code that has since changed but still lacks final qualification closure. An open label should not be read as proof that every historical bug reproduces on V39. Issues 08, 23, 26, 37, 40, 41 and 42 carry the main remaining clearance/search/qualification thread; 10/15 cover deferred gust/delay; 06 covers hardware work.

{{ISSUE_INVENTORY}}

The handoff is complete as a stopped-state report. Mission qualification remains unfinished, and work will resume only on the user's instruction.
