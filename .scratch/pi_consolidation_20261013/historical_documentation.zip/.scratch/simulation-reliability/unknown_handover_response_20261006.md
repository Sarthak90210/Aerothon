# Unobserved prior position target in the response observer

This is a bounded calm-model diagnosis. It does not qualify flight, prove a
wind measurement, or explain the whole rendered return failure.

Ranked hypotheses for response residual during moving handover:

1. The unknown position-controller target is treated as zero before the first
   own velocity packet arrives. A calm constant-motion plant should then
   invent wind during the declared 0.4 s transport interval.
2. The declared response time differs from the physical response. Residual
   should remain after the own packet arrives and change with the response
   constant, even when prior-target uncertainty is handled.
3. Heading or sample interpolation adds error. Residual should disappear in
   a fixed-heading plant with exact, undelayed measurement times.
4. Clearance certificates depend too strongly on this point estimate. Fixing
   the residual alone would still fail the coupled changing-gust diagnostics.

The AST-only command is `python3
.scratch/simulation-reliability/prove_unknown_handover_response_20261006.py`.
It runs the actual current `_compensated` and `_effective_command` methods in
a known calm plant. Prior position control maintains 0.3 m/s until the own
zero command arrives. It produces 0.1368446465 m/s false pre-arrival residual
and fails its assertion. Log:
logs/reliability_unknown_handover_response_red_20261006.log.

A separate scratch probe waits until a measurement reflects an arrived own
command before evaluating response residual. It seeds from the aircraft's
observed motion during the unknown interval. On the same known calm plant,
pre-arrival residual is zero and later numerical residual is below 1e-16.
This only isolates hypothesis one. It does not establish the prior command,
physical wind, model uncertainty, or a safe initial motion certificate.

The probe source is probe_unknown_handover_guard_20261006.py and its retained
output is logs/reliability_unknown_handover_guard_scratch_20261006.log.
No production code changed. The running moving rendered return trial uses
the frozen current source and must close before any observer change.
