# Corrected headless return handover: independent evidence review

Status: ready-for-agent

Reviewed on 2026-10-07. Source remains frozen for the full suite and rendered recordings. This review changes no flight code, physics, fixtures, recorded output, or grading.

## Outcome and scope

`logs/reliability_corrected_headless_focus_20261007/my_world_calm_s1` failed. The mission reported `ReturnCorridor: corridor navigator reported STUCK at x=15.54` at 846.01 simulated seconds, then requested RTL. The independent navigation grade measured minimum obstacle/corridor clearance **0.5028028772238747 m**, below the required **0.70 m**. The aircraft landed and disarmed physically at 890.67 s. Outbound traversal passed; return traversal, staying below wall tops, flight-mode restriction, and clearance failed. Restricted-zone minimum was 2.28007126355525 m.

This is an object-level navigation run: calm conditions, seed 1, RTF 4, domain 222, declared raw-command transport delay 0.4 s and response time 0.6 s. It has no rendered camera recording or usable motor telemetry. Navigation-only mode did not exercise delivery. Its 10 Hz generated QR/red observations and zero declared processing latency cannot qualify rendered detector rates or motor-priority delivery.

## First clearance failure

The first failure is an entrance handover with incoming motion. It occurs before the return navigator produces any travel command. All **244 return raw commands have zero horizontal velocity**. Sampled return decisions contain BLOCKED, BACKOFF and STUCK, with no CRUISE state or executable return path. The evidence does not support an executed path shortcut as the trigger of this run's first breach.

| Time (simulation seconds) | Evidence | Observation |
| --- | --- | --- |
| 831.2 onward | Independent physical track; position commands | GateAdvance accelerates from about (20.121, -16.254), heading 169.3 degrees, toward the measured crossing target. |
| 833.31 | Controller position header | Last unmodified target (15.750005, -15.425014, 2.081542); independent static target clearance 0.761016 m to obstacle 0. |
| 833.41 | Controller position header | KEEP-OUT changes the target to (15.984638, -15.403419); static target clearance 0.996285 m. The nearest lidar return had reached 0.95 m. |
| 833.46 | First return raw command header | Zero horizontal velocity requested. Independent recorder receives it at 833.92 s. |
| 833.49 capture / 833.50 recording | Onboard FCU pose and velocity | RETURN_CORRIDOR at (15.823026, -15.438558, 2.076818), velocity (-1.198536, +0.233487, +0.010617) m/s; horizontal speed about 1.221 m/s. |
| 833.6 | Independent physical track | Clearance 0.719272 m to obstacle 0. |
| **833.7** | Independent physical track | **First clearance below 0.70 m: 0.640609 m**, at (15.622, -15.397, 2.079), RETURN_CORRIDOR/GUIDED. |
| 834.11 recording | Cached onboard avoidance detail | Observed clearance 0.513135 m, empty path, `aircraft lacks required surface clearance`, `braking_clearance_available=false`; scan age 0.06 s and pose age 0.03 s as reported by the controller. |
| **834.2** | Independent physical track | **Minimum 0.502803 m**, obstacle 0, at (15.461, -15.346, 2.081). |

Source semantics retain the previous position target until the world callback's queued raw packet reaches `callback_world_time + 0.4`. On causal common simulation clocks, the first return packet with header 833.46 cannot reach the physical raw controller before 833.86. Therefore the 833.7 breach precedes even that earliest possible raw ownership transition. Software has already selected RETURN_CORRIDOR, while the physical aircraft is still following the position target and braking from the gate advance. This is a handover/braking clearance gap: static endpoint clearance does not cover the incoming velocity and delayed transition.

The final position target moves away from obstacle 0, and velocity begins decreasing before the breach. That intervention still permits momentum to cross the clearance boundary. The corrected fixture now preserves actual position ownership until packet arrival; it does not erase this incoming motion at the ROS raw callback.

## Limits of the timing record

The run records controller-local ROS header stamps and a separate recorder's callback stamps. Across 543 raw packets, the header-to-recorder difference is median 0.03 s, p95 0.04 s, maximum 0.46 s. **These are not world callback times or measured physical receipt delays.** The headless world schedules 0.4 s after its own callback. That callback and its pending queue were not recorded.

The first return packet's 0.46 s gap could include publisher ROS-clock staleness while a planning callback blocks its executor, DDS/executor scheduling, and independent recorder delay. Current data cannot split those components. The controller stamps packets with `get_clock().now()` and publishes after its motion checks; that node's time may remain behind world time during a long single-thread callback. The same caveat applies to reported scan/pose ages computed from that clock. No capture stamp exists inside avoidance detail, so 834.11 is the recorder's cached-detail sample, not an exact decision timestamp.

Future diagnosis should record publisher wall entry/exit, local decision clock and fresh-sensor stamps, and the world's callback/queued physical receipt timestamps separately. Flight decisions must use onboard data only. A callback/receipt trace is evaluation evidence and must not become an onboard input.

## Actionable repair target after the source freeze

1. Certify gate advance and the control transition using fresh onboard scan, pose and FCU ground velocity, including pending command delay and the complete braking motion. Apply 0.70 m to the entire predicted movement, not only the target or the next navigator's path.
2. Preserve a safe, measured position target during a failed handover, or initiate a certified stop earlier. The keep-out's static 1 m trigger is too late for the observed 1.22 m/s approach here. Do not treat an uncertified raw-zero fallback as a certified hold.
3. Recheck sensor freshness and decision computation time before publishing after an expensive plan. Record timing provenance so real FCU transport, controller computation and simulator queuing can be compared without silently adding or deleting delay.
4. Keep the current failure as a regression with the unchanged world and physical timing. A rendered course pass, a headless navigation pass, and a narrow-gust control-envelope qualification remain separate requirements.

## Recording closure

`qualification_evidence.recorded_disarm` accepts the actual onboard transition: FCU capture 890.679999999, received 890.6799999990001, recorded 890.7699999990001. The final recorded row at 891.599999999 contains connected, disarmed LAND state captured at 891.399999999. This validates headless FCU evidence through real disarm. It does not establish camera/video coverage because the headless camera ledgers are empty.

## Reproducible evidence

- `.scratch/simulation-reliability/pinpoint_headless_return_20261007.py`: independent evaluator; reads the saved native track, actual onboard observations and command ledger; does not execute flight nodes.
- `.scratch/simulation-reliability/corrected_headless_first_breach_enriched_20261007.json`: native first breach/minimum, exact command and observation windows, static target evaluation, zero-command count, disarm transition.
- `.scratch/simulation-reliability/corrected_headless_traffic_closed_20261007.json`: closed-run traffic and generated detector-rate analysis.
- `logs/reliability_corrected_headless_focus_20261007/my_world_calm_s1/{configuration.json,run.json,navigation_grade.json,stack.log,onboard.jsonl,flight_commands.jsonl,evaluation_truth_track.csv,layout.json}`: original evidence remains untouched.
- `sim/headless_world.py`: `_on_sp_pos`, `_on_sp_raw`, `_desired_velocity`, `_to_point` implement the relevant ownership and physical timing semantics.
- `src/aerothon_mission/mission_bt/mission_bt/mission_tree.py`: GateAdvance returns success on 0.25 m target proximity; Corridor enables velocity avoidance next. GateAdvance's LegRouter handles red exclusions, not a dynamic lidar stopping certificate.
- `src/aerothon_mission/mission_bt/mission_bt/mav_commander.py`: `_kept_out` shifts position targets once the nearest valid return is inside the static keep-out range; enabling avoidance clears future position streaming.
- `src/aerothon_avoidance/avoidance/avoidance/velocity_controller.py`: failed travel/hold certificates can publish raw horizontal zero while recording `braking_clearance_available=false`.

The source manifest recorded by this focus has SHA256 `09b2debded0df8d938141f8b57f2b9614e2374f81ba53ef3a3b893e4578ad54e`. The primary reported the same frozen-source full suite as 1376 passed / 3 skipped in 813.17 s, followed by successful syntax/XML/YAML/frontend checks; those checks are not a traversal pass for this focus.

## Focused unchanged-physics replay

`replay_headless_handover_motion_20261007.py` initializes only the physical model from the saved onboard pose and FCU ground velocity at 833.28 s, then replays the original position and raw command ledger. It verifies the physical source hash against the focus manifest, uses the original calm physics, and keeps the declared 0.4 s packet delay and 0.6 s response. It does not execute a new mission decision or claim a traversal.

The independent-recorder callback proxy closely reproduces native motion across 38 saved track points: mean position error **0.000484 m**, maximum **0.000816 m**. Minimum clearance is **0.502704 m at 834.17 s**, still under physical position control; raw ownership begins at 834.33 s. There are no contacts in this proxy. This is strong circumstantial support for the handover diagnosis, while callback timing remains an assumption rather than an instrumented observation.

The earliest header-time callback proxy is worse: raw ownership begins at 833.87 s, minimum is **0.400285 m**, and the physical collision model reports obstacle contact at 834.74 s. Earlier raw zero cancels the old position target's active braking and lets the first-order response carry incoming velocity farther. Merely sending raw zero earlier is therefore not a demonstrated fix. Both proxies first cross 0.70 m while still physically position-owned.

The full result and its explicit limitations are in `.scratch/simulation-reliability/headless_handover_motion_replay_20261007.json`. The other diagnosis agent owns a separate actual GateAdvance early-speed/braking admission policy; this replay supplies the preserved failure mechanism without changing that policy or the production source.

## Actual SITL hold configuration

The parameter's actual ArduPilot name is **`GUID_OPTIONS`**, as registered in installed `ArduCopter/Parameters.cpp` at lines 996–1001. A single read-only ROS2 `/mavros/param/get_parameters` request on the new shipped rendered run (domain 218) returned a typed integer **0** at 97.515 simulated seconds. The simultaneously observed FCU state was connected, armed and GUIDED, captured at 97.514 s. Original observations are preserved in `logs/reliability_render_shipped_s20261003_observation_repairs_20261007/guid_options_ros2_observation_20261007.json`.

This is the live MAVROS FCU parameter cache, not a synchronous MAVLink `PARAM_VALUE` transaction. Bit 4 and bit 5 are clear: XY position stabilization and XY velocity stabilization are enabled. Bit 6 is clear: WPNav is not selected for position targets. The installed `ModeGuided::velaccel_control_run` feeds the velocity/acceleration target through the position controller and only removes position stabilization when its disabling bit is set. Thus the real FCU's raw-zero response includes its position stabilization; the simple velocity-only physical fixture does not reproduce that full hold behavior. No parameter was changed and no parameter-list pull occurred during flight.

Two earlier failed observations remain preserved: legacy `/mavros/param/get` was unavailable, and querying the nonexistent name `GUIDED_OPTIONS` via ROS2 returned type 0 (not set). Those responses were correctly treated as unknown, not zero. Exact installed source hashes/excerpts are stored in `.scratch/simulation-reliability/sitl_hold_source_observation_20261007.json`; they document firmware semantics without independently proving all running binary bytes derive from those source bytes. The live value does not qualify hardware or repair the failed headless mission.
