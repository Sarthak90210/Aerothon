# Wider lidar median filter rejected

The existing five-beam median setting was tested outside production on the
frozen command-deadline candidate. Geometry, wind, command delay 0.4 s,
response 0.6 s and clearance requirements stayed unchanged. Computation
budget was zero only because the offline fixture clock does not advance
inside a controller callback, matching the preceding diagnostic.

Both preserved physical coupled cases still contact an obstacle. Dirty
lidar seed 0 has minimum logged pre-integration clearance 0.4131998449 m;
late scans seed 1 has 0.4006406899 m. These minima are logged samples,
not a swept-path minimum through the final contact step.

An independent sensor-conditioning check ray-casts thin obstacles at 2, 4
and 8 m, with widths 0.1, 0.2 and 0.4 m and four sub-beam phases. It feeds
those observations through the actual controller's conditioning method.
The five-beam setting loses obstacle detection in seven of the 36 cases
where the current three-beam setting retains it. Consequently the wider
filter is rejected. It cannot be used to turn an uncertain observation
into permissive free space.

Production source and sensor configuration were unchanged. This test does
not qualify future gust bounds or motor delivery, and does not repair the
remaining strong disturbance and delay limitation.

Evidence is in logs/reliability_deadline_median5_coupled_20261007,
logs/reliability_median_thin_obstacles_20261007.json and their complete
owned output logs. Frozen source archive SHA-256 is
fa239ceba76e5ad03d34229197703bcd5972389111d76ec7a1c9b0df7ac164b9.
