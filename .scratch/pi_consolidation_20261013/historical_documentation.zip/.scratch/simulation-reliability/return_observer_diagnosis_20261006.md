The banner-fix full mission genuinely lost corridor clearance. Independent postflight geometry first falls below 0.70 m at simulation time 885.083 s, with 0.6994746304872781 m. The minimum is 0.6842457669223637 m at 887.514 s. This is not merely a noisy scan or conservative planner rejection.

At 881.031 s the onboard scan reports 0.7225102977434598 m. The local planner correctly rejects the aircraft origin because every segment needs 0.70 m plus the unchanged 0.025 m sampling reserve. The recorded scan replay reproduces the later origin rejection at 893.051 s, reconstructing 0.6959710429692584 m against the recorded 0.6928500985223941 m. Its 0.00312 m difference is consistent with reconstructing the original 25 Hz pose cache from the 5 Hz onboard recording. The aircraft origin is known; the failure is clearance, not a masked ray or stale sensor.

There is a separate, proved observer timing bug. Before the correction, `_compensated` advances the commanded response to controller receipt time and compares it with velocity measured at an earlier FCU header timestamp. A perfectly specified calm response with a 50 ms sample receipt delay then produces 0.12507327185726233 m/s of false estimated disturbance. Repeated samples also advance the response beyond their unchanged measurement time, and control handover seeds its response at receipt time rather than sample time.

The minimal correction in `velocity_controller.py` advances and seeds the response model at the measurement header timestamp. It preserves the raw measured ground velocity, every clearance threshold, the scan mask, recovery limits, the existing disturbance response parameters, and the motion certificate. `local_planner.py` is unchanged.

The archived source fails all three new regressions in 0.89 s. Current source passes the 31 related FCU, timestamp, delayed-command, yaw and clearance tests in 4.94 s. Commands and logs:

- `bash .scratch/simulation-reliability/check_archived_velocity_alignment_red_20261006.sh`, log `logs/reliability_fcu_alignment_archived_red_20261006.log`. It loads only the two archived methods into memory. It does not edit production files.
- `bash .scratch/simulation-reliability/check_fcu_alignment_related_20261006.sh`, log `logs/reliability_fcu_alignment_related_20261006.log`.

The timestamp correction is not proved to resolve the whole rendered failure. Recorded FCU sample ages near the critical burst are 17–24 ms. A bounded replay of the recorded command response attributes a peak 0.024060616235090065 m/s and RMS 0.006627910614115898 m/s contribution to sample-time mismatch over 869.5–880.5 s. The overall response residual remains about 0.07 m/s after alignment. That comparison uses 5 Hz interpolated headings and an approximate first-order response, so it does not reconstruct every original estimator tick.

The accepted body-velocity burst from 879.705 to 879.856 s rises from 0.855 to 1.354 m/s forward, with disturbance-rate estimates alternating near their 0.8 m/s² cap. Planner rejection starts around 881 s and the later native violation occurs during recovery holds. Further actuator-response or disturbance-estimation uncertainty remains a plausible cause. The old response-fit helper reaches its grid bounds, but its window includes the gate handover and cannot justify tuning delay or response time.

The next useful check is a focused rendered return using the failed banner-fix run's actual FCU entry state. A pass must retain native clearance, fresh onboard velocity, full recording through disarm and the existing isolation audit. No full-mission or broader-campaign pass is established by this correction alone.

Scratch evidence is in `bannerfix_clearance_attribution_20261006.json`, `bannerfix_observer_time_comparison_20261006.json`, `bannerfix_origin_fixture_20261006.json` and `bannerfix_return_windows_diagnosis_20261006.jsonl`, all under `.scratch/simulation-reliability/`.
