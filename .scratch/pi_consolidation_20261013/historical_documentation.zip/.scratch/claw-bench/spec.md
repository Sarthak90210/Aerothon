# Claw retention and release qualification

Status: needs-info
Started: 2026-10-05

User scope: resolve retention, release, re-grabbing and ground clearance;
verify with the real payload on a bench.

## Baseline

Replay the stored contact trials without launching a simulator or actuator:

```sh
python3 scripts/audit_claw_baseline.py --out logs/claw_baseline_20261005.json
```

An exit code of 1 is expected while the saved trials fail. Source evidence
is preserved. The report calculates nominal stowed ground clearance using
the CAD gear, simulated lifting ring and specified payload height. This is
not a measurement of the real assembly.

Executed 2026-10-05 in WSL Ubuntu with system Python. Exit 1:
`NOT_HELD_AFTER_LOADING`, `REGRABBED`, maximum post-touchdown lift 0.558 m,
nominal payload clearance -0.007962 m. Report:
`logs/claw_baseline_20261005.json`.

`python3 -m pytest sim/test_claw.py sim/test_physical_hook.py -q`:
15 passed in 46.64 s. These verify kinematics, fixtures and verdict logic;
they do not demonstrate reliable physical retention or release.

## Required inputs before a mechanical change

- Whether the real claw, winch and payload are assembled and accessible.
- Actual payload attachment shape, dimensions and permitted modifications.
- Payload mass, height and eye-to-bottom distance in its carried orientation.
- Actual jaw pocket dimensions, material, thickness and joint play.
- Ground-to-eye height with the aircraft on its gear and line stowed.
- Connected actuator/controller, wiring, output assignment and supply.
- Whether jaw, latch, mount or landing-gear changes are permitted.

## Candidate changes to evaluate, not selected designs

- Wider or laterally enclosed pocket seats to prevent uneven-load escape.
- A mechanical hold-open latch that engages after touchdown and resets at
  stow. The existing simulated latch is commanded behavior, not a physical
  latch design or proof of one.
- Clearance obtained by a revised stowed claw location or landing gear,
  sized from measured eye-to-bottom distance and required clearance.
- An attachment compatible with the organiser's actual payload. Do not
  substitute the simulation ring for a supplied attachment without approval.

## Completion

Physical evidence must show supported loading, retention after removing the
support, controlled lowering, touchdown-triggered release, full retraction
without lifting the payload again, and positive measured ground clearance
before takeoff. Test repeated cycles and uneven loading, using agreed load,
offset, clearance and cycle-count requirements. Record failures too.

See docs/CLAW_BENCH.md for the measurement and trial record.
