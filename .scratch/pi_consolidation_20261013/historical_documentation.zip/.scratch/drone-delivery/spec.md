# Drone-controlled delivery observation

Status: ready-for-agent
Started: 2026-10-05

Authoritative user constraints: drone commands all winch motion; Gazebo only
detaches on ground contact. No simulator contact, payload position or detach
acknowledgement may reach delivery decisions. Camera means the drone's onboard
camera. Per the updated user policy, qualified motor-output load observations
are the primary decision channel; camera evidence is supporting information.
Motor-based confirmation requires sustained unloading after hook retraction.
Fallback navigation may continue with delivery unconfirmed.
Three total attempts, then full hook retraction and normal mission continuation
with delivery unconfirmed, per the user's updated policy. Claw mechanics deferred.

Implementation and evidence boundaries: docs/DELIVERY_CONFIRMATION.md.

## Acceptance

- Frozen calibration from independent loaded/unloaded hover fixtures.
- Recorded rendered hover/drop with real camera processing and SITL outputs.
- No simulator truth in drone controller subscriptions or success inputs.
- Missing qualified load observations cannot declare delivery success.
- Returned load during retraction triggers retry; exhausted retries fully
  retract and continue with delivery unconfirmed.
