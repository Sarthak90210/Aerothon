# Delivery implementation status

2026-10-05

Implemented drone-controlled lowering, a provisional touchdown pause, independent
camera/load inference, short release-probe retraction, full retraction, final dual
confirmation and three-attempt failure handling. Simulator contact release has
no ROS interface. Drone winch status reports no contact or attachment knowledge.
Travel remains an estimate from commanded rates, not encoder measurement.

## Verification

- Colcon built all five changed ROS packages successfully.
- Full offline suite: 1225 passed, 3 skipped. Python, shell, XML and YAML checks passed.
- Latest focused regression: 218 passed, including 15 observer tests.
- Separate loaded hover: 83 stable samples, effort mean 0.4237461, std 0.0003789.
- Separate unloaded hover: 90 stable samples, mean 0.4070919, std 0.0005239.
- Frozen profile: logs/delivery_profile_20261005.json. These are motor-output
  effort observations, not current or measured thrust.
- First rendered trial failed when continued payout pressed the rigid simulated
  claw into the ground. Saved trace: logs/delivery_trial_20261005.
- Second rendered trial reached DONE at 139.227 simulated seconds, on attempt 3.
  Touchdown was inferred at 120.375, release-probe checked at 123.180, complete
  estimated retraction reached 135.614. All were drone-side decisions.
- Independent evaluation found payload centre z=0.10499987 m on the raised
  0.08 m takeoff pad. Position did not change during probe/full retraction or
  final confirmation. Simulator truth was never supplied to the observer.

## Limits and remaining work

The successful hover/drop trial exercises the contact-pause implementation.
The continuous-dropout timer correction, terminal evidence retention and built-in command recorder were
edited after this process loaded its modules; they passed the latest focused
regression, but are not claimed as live-tested in that flight. A separate
subscriber recorded winch commands during this flight.

Current flight demonstration uses calm simulation and a known payload size.
Monocular size ranging assumes payload orientation and the configured camera
optics. Motor-output effort qualification does not qualify actual current data.
There is no winch encoder, so hook stow is estimated. Adverse-condition rendered
trials and full mission continuation are still unverified. Missing-camera,
stale-telemetry, conflicting-evidence, retained-payload and retry-exhaustion
cases passed observer tests, not separate rendered acceptance flights.
Real-payload bench and hardware flight verification remain undone; claw
mechanism work is deferred as requested. No hardware readiness claim.

Evidence: logs/delivery_trial_hold_20261005, docs/DELIVERY_CONFIRMATION.md.

Trial result saved with final_armed=false. Wrapper edits during its execution
interrupted automatic video conversion; video was converted separately after
normal flight completion. The wrapper passes bash syntax checks.

## Updated motor-priority and recovery policy

Motor unloading is now the primary release-test trigger. Camera range supports
the decision but cannot veto sustained unloading through probe and full stow.
After three unsuccessful attempts, the hook is retracted fully by estimate and
the normal mission continues with delivery unconfirmed. Stale winch status,
faults or recovery timeout remain failures. Final reports name the evidence
basis. Real motor current and physical encoder feedback remain unavailable.

Rendered hover/drop validation completed DONE on attempt 1, then landed/disarmed.
Independent truth confirmed the payload stayed behind. Evidence is in
logs/delivery_motor_priority_20261005. This does not overwrite the preceding
failed seed-1001 full mission; a full run with this new policy is not yet verified.

Final motor-priority regression: 1234 passed, 3 skipped. Python, shell, XML
and YAML checks passed. Rendered validation remains the hover/drop check; the
full seed-1001 mission has not yet been repeated with this updated policy.

## Full seed 1001 with motor priority, 2026-10-05

Evidence: `logs/mission_seed1001_motor_priority_retry_20261005/`.
Rendered full mission completed, delivery independently inferred from calibrated motor effort after full hook retraction on attempt 2 at t=541.201 s, normal return corridor flown, landed and disarmed. Simulator-only contact detach was logged separately. Independent payload placement error 0.19 m; home landing error 0.25 m; flight 563.9 s; max altitude 10.15 m; max tilt 16.8 deg. Track grade FAIL solely due to SEARCH_QR red-zone entry at t=372.37 s, local (58.8,1.6,10). The delivery change does not close the search-planner red-zone issue.
Onboard MP4 decoded without errors, 1280x720, 1435 frames, 287 s nominal playback; variable capture rate makes playback accelerated relative to simulated time. Full trace, commands, observer transitions, frozen calibration, source hashes, exact world/vehicle and separate truth are preserved. The earlier new attempt in `logs/mission_seed1001_motor_priority_20261005/` is invalid due to MAVROS SIGSEGV before delivery. Exhaustion fallback was not reached in the completed run.
