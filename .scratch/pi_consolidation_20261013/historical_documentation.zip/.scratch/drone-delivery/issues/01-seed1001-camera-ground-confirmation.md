# Grounded payload fails onboard visual range check on seed 1001

Status: ready-for-agent

Seed 1001 full rendered mission reached A and physically dropped the payload
0.12 m from the pad centre. The observer never inferred touchdown and failed
after three attempts. Camera range settled at 10.85 m while onboard altitude
was about 5.5 m. Flight telemetry eventually settled, but visual support
inference never passed. The root cause of the detector bbox discrepancy still
needs diagnosis; do not tune it using simulator truth as a flight input.

Evidence: logs/mission_seed1001_delivery_20261005/onboard.jsonl,
delivery_frame.png, onboard.mp4 and grade.txt. Frozen source hashes and profile
are retained in source_manifest.json. Use this flight as the failing trace.

The updated motor-priority policy removes this camera-range veto from the
delivery gate. The image/range discrepancy itself is not repaired and remains
an open supporting-vision issue.
