# Delivery failure return does not stow the winch and fails flight grading

Status: ready-for-agent

Seed 1001 failed delivery confirmation, requested RTL, and returned with 6 m
estimated payout. It reached 15.12 m, bypassed the return corridor and tilted
36.8 degrees during descent before disarming 0.06 m from home. The extended
winch and tilt are observed together; a causal claim needs further testing.
Safety return must be validated against this full failure trace. No safe-return
acceptance can be inferred from final disarm alone.

Evidence: logs/mission_seed1001_delivery_20261005/full_track.csv, grade.txt,
winch_commands.jsonl, onboard.mp4 and stack.log.

Exhausted delivery attempts now enter full stow before normal mission
continuation, eliminating the immediate RTL-with-extended-winch path for
attempt exhaustion. Integration tests cover this policy. Recovery faults
and non-delivery safety aborts still need full-flight validation.
