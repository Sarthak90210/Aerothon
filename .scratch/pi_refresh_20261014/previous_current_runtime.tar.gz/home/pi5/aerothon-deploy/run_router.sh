#!/usr/bin/env bash
set -euo pipefail
source /home/pi5/aerothon-deploy/runtime.env
test -c "$AEROTHON_FCU_DEVICE"
exec /usr/bin/python3 /home/pi5/aerothon_ws/scripts/mav_router.py \
    --fcu-serial "$AEROTHON_FCU_DEVICE" --fcu-baud "$AEROTHON_FCU_BAUD" \
    --mavros-port 14555 --gcs-port 14550
