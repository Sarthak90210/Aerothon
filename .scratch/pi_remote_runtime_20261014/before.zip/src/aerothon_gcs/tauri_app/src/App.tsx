import { lazy, Suspense, useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import type { Telemetry } from "./types";
import { TelemetryHistory } from "./telemetryHistory";
import {
  acknowledgement,
  commandId,
  age,
  commandEnvelope,
  defaultProfile,
  endpoint,
  freshFcu,
  missionActive,
  startAllowed,
  reviewAllowed,
  taskCommand,
  tasks,
  videoUrl,
  type CommandOutcome,
  type ConnectionProfile,
} from "./runtime";
import ArenaDimensions from "./ArenaDimensions";
import LidarCalibration from "./LidarCalibration";
import coverage from "./satelliteCoverage.json";
import "./gcs.css";
const Graphs = lazy(() => import("./Graphs"));
type Grid = {
  w: number;
  h: number;
  res: number;
  ox: number;
  oy: number;
  yaw: number;
  frame: string;
  stamp: number;
  data: number[];
};
const value = (n: unknown, unit = "", precision = 1) =>
  typeof n === "number" && Number.isFinite(n)
    ? `${n.toFixed(precision)}${unit}`
    : "Unavailable";
const boundary = (text: string) =>
  text
    .trim()
    .split("\n")
    .filter(Boolean)
    .map((line) => {
      const [lat, lon, ...extra] = line.split(",").map(Number);
      if (extra.length || !Number.isFinite(lat) || !Number.isFinite(lon))
        throw new Error("Enter latitude, longitude on each line");
      return { lat, lon };
    });
function savedProfiles(): ConnectionProfile[] {
  try {
    const stored = JSON.parse(
      localStorage.getItem("gcs-connections-v2") || "[]",
    );
    if (Array.isArray(stored) && stored.length)
      return stored.map((p) => ({
        id: String(p.id),
        name: String(p.name),
        endpoint: endpoint(p.endpoint),
      }));
  } catch {
    /* A malformed profile must not prevent opening the GCS. */
  }
  return [defaultProfile(location.hostname || "127.0.0.1")];
}
export default function App() {
  const [mode, setMode] = useState<"flight" | "testing">("flight"),
    [theme, setTheme] = useState(localStorage.getItem("gcs-theme") || "light");
  const [view, setView] = useState<"camera" | "slam" | "map" | "graphs">("map");
  const [profiles, setProfiles] = useState(savedProfiles),
    [profile, setProfile] = useState<ConnectionProfile>(
      () => savedProfiles()[0],
    );
  const [activeEndpoint, setActiveEndpoint] = useState(
      () => savedProfiles()[0].endpoint,
    ),
    [enabled, setEnabled] = useState(true),
    [nonce, setNonce] = useState(0);
  const [linked, setLinked] = useState(false),
    [received, setReceived] = useState(0),
    [clock, setClock] = useState(Date.now()),
    [telemetry, setTelemetry] = useState<Telemetry | null>(null);
  const [events, setEvents] = useState<string[]>([]),
    [error, setError] = useState("");
  const [settings, setSettings] = useState(false),
    [arenaOpen, setArenaOpen] = useState(false),
    [lidarOpen, setLidarOpen] = useState(false);
  const [task, setTask] = useState("mission"),
    [action, setAction] = useState("stow"),
    [height, setHeight] = useState(5);
  const [review, setReview] = useState<{
      cmd: string;
      args: Record<string, unknown>;
      label: string;
    } | null>(null),
    [busy, setBusy] = useState(false),
    [starting, setStarting] = useState(false);
  const [outcome, setOutcome] = useState<CommandOutcome | null>(null);
  const [target, setTarget] = useState(""),
    [zoneText, setZoneText] = useState(""),
    [fenceText, setFenceText] = useState("");
  const [colours, setColours] = useState({
    green: "#07A03D",
    orange: "#EB5A0A",
    red: "#C4161C",
  });
  const [topic, setTopic] = useState("/percep/overlay"),
    [videoError, setVideoError] = useState(false);
  const [grid, setGrid] = useState<Grid | null>(null),
    [gridReceived, setGridReceived] = useState(0),
    [onlineMap, setOnlineMap] = useState(false),
    [mapError, setMapError] = useState(false);
  const history = useRef(new TelemetryHistory()),
    socket = useRef<WebSocket | null>(null),
    mapHost = useRef<HTMLDivElement>(null),
    map = useRef<maplibregl.Map | null>(null),
    marker = useRef<maplibregl.Marker | null>(null),
    centered = useRef(false);
  const pending = useRef(
    new Map<
      string,
      { timer: number; resolve: (result: CommandOutcome) => void; cmd: string }
    >(),
  );
  const fresh = linked && received > 0 && clock - received < 3000,
    t = fresh ? telemetry : null,
    fcu = freshFcu(t),
    running = missionActive(t) || starting;
  const selectedTask = mode === "flight" ? "mission" : task,
    taskInfo = tasks.find((item) => item.id === selectedTask)!;
  const canStart = !busy && !starting && startAllowed(t, fresh, selectedTask);
  const record = (text: string) =>
    setEvents((list) => [
      ...list.slice(-149),
      `${new Date().toLocaleTimeString()} ${text}`,
    ]);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("gcs-theme", theme);
  }, [theme]);
  useEffect(() => {
    const timer = window.setInterval(() => {
      setClock(Date.now());
      history.current.tick(performance.now(), Date.now());
    }, 500);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!enabled) return;
    let disposed = false,
      retry = 0;
    const open = () => {
      const ws = new WebSocket(activeEndpoint);
      socket.current = ws;
      ws.onopen = () => {
        if (disposed || socket.current !== ws) return;
        setLinked(true);
        record(`Connected to ${activeEndpoint}`);
      };
      ws.onmessage = (event) => {
        if (disposed || socket.current !== ws) return;
        try {
          const envelope = JSON.parse(event.data);
          if (envelope.kind === "telemetry") {
            history.current.ingest(
              envelope.data,
              envelope.t,
              performance.now(),
              Date.now(),
            );
            setTelemetry(envelope.data);
            setReceived(Date.now());
            if (
              age(envelope.data, "mission") < 3 &&
              envelope.data.mission?.state !== "STARTING"
            )
              setStarting(false);
          } else if (envelope.kind === "map") {
            setGrid(envelope.data);
            setGridReceived(Date.now());
          } else if (envelope.kind === "event")
            record(envelope.data.msg || "Runtime event");
          else if (envelope.kind === "ack") {
            const result = acknowledgement(envelope.data),
              entry = pending.current.get(result.command_id);
            if (entry) {
              window.clearTimeout(entry.timer);
              pending.current.delete(result.command_id);
              entry.resolve(result);
            }
            setOutcome(result);
            record(
              `${result.cmd}: ${result.state}${result.reason ? `, ${result.reason}` : ""}`,
            );
          }
        } catch {
          setError("The runtime sent an invalid message.");
        }
      };
      ws.onclose = () => {
        if (disposed || socket.current !== ws) return;
        setLinked(false);
        history.current.disconnect();
        for (const [id, entry] of pending.current) {
          window.clearTimeout(entry.timer);
          const result: CommandOutcome = {
            command_id: id,
            cmd: entry.cmd,
            state: "Outcome unknown",
            reason: "Connection lost; this command will not be replayed.",
          };
          entry.resolve(result);
          setOutcome(result);
        }
        pending.current.clear();
        if (!disposed) retry = window.setTimeout(open, 1500);
      };
    };
    open();
    return () => {
      disposed = true;
      window.clearTimeout(retry);
      socket.current?.close();
      for (const [id, entry] of pending.current) {
        window.clearTimeout(entry.timer);
        entry.resolve({
          command_id: id,
          cmd: entry.cmd,
          state: "Outcome unknown",
          reason: "Connection changed; no retry was sent.",
        });
      }
      pending.current.clear();
    };
  }, [activeEndpoint, nonce, enabled]);
  async function send(
    cmd: string,
    args: Record<string, unknown> = {},
  ): Promise<CommandOutcome> {
    const ws = socket.current;
    if (!ws || ws.readyState !== WebSocket.OPEN)
      throw new Error("Production runtime is disconnected.");
    const id = commandId(),
      submitted: CommandOutcome = {
        command_id: id,
        cmd,
        state: "Submitted",
        reason: "Awaiting runtime acknowledgement.",
      };
    setOutcome(submitted);
    record(`${cmd}: Submitted`);
    return new Promise((resolve) => {
      const timer = window.setTimeout(() => {
        pending.current.delete(id);
        const result: CommandOutcome = {
          ...submitted,
          state: "Outcome unknown",
          reason:
            "Acknowledgement timed out. Inspect the aircraft; no retry was sent.",
        };
        setOutcome(result);
        record(`${cmd}: Outcome unknown`);
        resolve(result);
      }, 8000);
      pending.current.set(id, { timer, resolve, cmd });
      try {
        ws.send(commandEnvelope(id, cmd, args));
      } catch {
        window.clearTimeout(timer);
        pending.current.delete(id);
        const result = {
          ...submitted,
          state: "Outcome unknown" as const,
          reason: "Transport failed; no retry was sent.",
        };
        setOutcome(result);
        resolve(result);
      }
    });
  }
  async function perform(cmd: string, args: Record<string, unknown> = {}) {
    setBusy(true);
    setError("");
    try {
      const result = await send(cmd, args);
      if (result.state === "Failed")
        throw new Error(result.reason || "Runtime rejected the request");
      if (cmd === "start_mission" || cmd === "start_test") setStarting(true);
      if (cmd === "abort" && result.state === "Accepted") setStarting(false);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason));
    } finally {
      setBusy(false);
    }
  }
  const reviewedSend = (
    cmd: string,
    args: Record<string, unknown> = {},
    danger = false,
  ) => {
    if (danger) {
      setArenaOpen(false);
      setLidarOpen(false);
      setReview({ cmd, args, label: `Review ${cmd.replace(/_/g, " ")}` });
    } else void perform(cmd, args);
  };
  function saveProfile() {
    try {
      if (linked || running)
        throw new Error(
          "Disconnect the browser before editing its saved connection.",
        );
      if (!profile.id.trim() || !profile.name.trim())
        throw new Error("Enter a profile ID and name");
      const clean = { ...profile, endpoint: endpoint(profile.endpoint) },
        list = [...profiles.filter((p) => p.id !== clean.id), clean];
      localStorage.setItem("gcs-connections-v2", JSON.stringify(list));
      setProfiles(list);
      setProfile(clean);
      record("Browser connection profile saved");
    } catch (reason) {
      setError(String(reason));
    }
  }
  function connectProfile() {
    try {
      const next = endpoint(profile.endpoint);
      if (running && next !== activeEndpoint)
        throw new Error(
          "An execution is active. Keep its current connection for recovery.",
        );
      if (next !== activeEndpoint) {
        history.current = new TelemetryHistory();
        setGrid(null);
        centered.current = false;
      }
      setLinked(false);
      setTelemetry(null);
      setReceived(0);
      setError("");
      setActiveEndpoint(next);
      setEnabled(true);
      setNonce((n) => n + 1);
    } catch (reason) {
      setError(String(reason));
    }
  }
  useEffect(() => {
    if (view !== "map" || !mapHost.current) return;
    const m = new maplibregl.Map({
      container: mapHost.current,
      center: coverage.center as [number, number],
      zoom: coverage.initial_zoom,
      maxZoom: 19,
      style: {
        version: 8,
        sources: {
          satellite: {
            type: "raster",
            tiles: [
              onlineMap
                ? "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
                : `${location.origin}/satellite/{z}/{x}/{y}.jpg`,
            ],
            tileSize: 256,
            bounds: onlineMap
              ? undefined
              : (coverage.bounds as [number, number, number, number]),
            minzoom: onlineMap ? 0 : coverage.minzoom,
            maxzoom: 19,
            attribution:
              "© Esri, Maxar, Earthstar Geographics, GIS User Community",
          },
        },
        layers: [
          {
            id: "background",
            type: "background",
            paint: {
              "background-color": theme === "dark" ? "#252627" : "#ecece8",
            },
          },
          { id: "satellite", type: "raster", source: "satellite" },
        ],
      },
    });
    map.current = m;
    marker.current = new maplibregl.Marker({
      color: theme === "dark" ? "#eee" : "#242424",
    });
    centered.current = false;
    setMapError(false);
    m.addControl(new maplibregl.NavigationControl(), "top-right");
    m.on("error", () => setMapError(true));
    return () => {
      marker.current?.remove();
      m.remove();
      map.current = null;
    };
  }, [view, onlineMap, theme]);
  useEffect(() => {
    const gps = t?.gps;
    if (
      view !== "map" ||
      !map.current ||
      !gps ||
      age(t, "gps") >= 3 ||
      gps.fix === "NO" ||
      !Number.isFinite(gps.lat) ||
      !Number.isFinite(gps.lon)
    ) {
      marker.current?.remove();
      return;
    }
    const ll: [number, number] = [gps.lon, gps.lat];
    marker.current?.setLngLat(ll).addTo(map.current);
    if (!centered.current) {
      map.current.jumpTo({ center: ll, zoom: 17 });
      centered.current = true;
    }
  }, [t, view]);
  return (
    <div className="app">
      <header>
        <div className="wordmark">
          AeroTHON <span>GCS</span>
        </div>
        <nav aria-label="Operating mode">
          <button
            aria-pressed={mode === "flight"}
            onClick={() => {
              setMode("flight");
              setReview(null);
            }}
          >
            Flight operations
          </button>
          <button
            aria-pressed={mode === "testing"}
            onClick={() => {
              setMode("testing");
              setReview(null);
            }}
          >
            Testing
          </button>
        </nav>
        <div className="header-end">
          <span>{activeEndpoint}</span>
          <button onClick={() => setArenaOpen(true)}>Arena</button>
          <button onClick={() => setLidarOpen(true)}>Lidar calibration</button>
          <button onClick={() => setSettings(!settings)}>Connections</button>
          <button
            aria-label="Switch theme"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? "Light" : "Dark"}
          </button>
        </div>
      </header>
      <section className="status-strip" aria-label="Aircraft status">
        <Datum
          label="Connection"
          text={
            fcu
              ? "Live FCU"
              : fresh
                ? "FCU unavailable"
                : linked
                  ? "Waiting for telemetry"
                  : "Disconnected"
          }
        />
        <Datum
          label="Aircraft mode"
          text={fcu ? t?.mission.mode || "Unavailable" : "Unavailable"}
        />
        <Datum
          label="Control owner"
          text={
            fcu
              ? running
                ? "Production mission / FCU"
                : "Transmitter / FCU"
              : "Unavailable"
          }
        />
        <Datum
          label="Armed"
          text={
            fcu && typeof t?.mission.armed === "boolean"
              ? t.mission.armed
                ? "Yes"
                : "No"
              : "Unavailable"
          }
        />
        <Datum
          label="Battery"
          text={value(age(t, "power") < 3 ? t?.power.pct : null, "%", 0)}
        />
        <Datum
          label="GPS satellites"
          text={value(age(t, "sats") < 3 ? t?.gps.sats : null, "", 0)}
        />
        <Datum
          label="Height"
          text={value(age(t, "pose") < 3 ? t?.flight.alt : null, " m")}
        />
        <Datum label="Execution" text={t?.mission.state || "Unavailable"} />
      </section>
      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {settings && (
        <section className="connections">
          <h2>Vehicle connections</h2>
          <p>
            Connect this browser to the production ROS aggregator. The router
            owns the FCU serial port; changing this endpoint does not change
            UART configuration or start a mission.
          </p>
          <div className="connection-fields">
            <label>
              Saved profile
              <select
                value={profile.id}
                onChange={(e) =>
                  setProfile(
                    profiles.find((p) => p.id === e.target.value) || {
                      id: "vehicle",
                      name: "Vehicle",
                      endpoint: activeEndpoint,
                    },
                  )
                }
              >
                <option value="vehicle">New profile</option>
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </label>
            <Field
              label="Profile ID"
              text={profile.id}
              change={(id) => setProfile({ ...profile, id })}
            />
            <Field
              label="Name"
              text={profile.name}
              change={(name) => setProfile({ ...profile, name })}
            />
            <Field
              label="Drone WebSocket endpoint"
              text={profile.endpoint}
              change={(url) => setProfile({ ...profile, endpoint: url })}
            />
          </div>
          <div className="actions">
            <button disabled={linked || running} onClick={saveProfile}>
              Save profile
            </button>
            <button disabled={busy} onClick={connectProfile}>
              Connect telemetry
            </button>
            <button
              onClick={() =>
                record(
                  fcu
                    ? `Fresh FCU state; mission readiness ${t?.safety.ready ? "ready" : "blocked"}`
                    : "No fresh FCU heartbeat; check the ROS console, router and endpoint.",
                )
              }
            >
              Connection check
            </button>
            <button
              disabled={!enabled || running}
              onClick={() => {
                setEnabled(false);
                setLinked(false);
                history.current.disconnect();
              }}
            >
              Disconnect browser
            </button>
          </div>
          <p className="view-note">
            The Pi page normally uses ws://Pi-address:8765. Local development
            uses ws://127.0.0.1:8765. Browser disconnect does not stop flight
            software.
          </p>
        </section>
      )}
      <main>
        <section className="workspace">
          <div
            className="view-tabs"
            role="tablist"
            aria-label="Monitoring view"
          >
            {(["camera", "slam", "map", "graphs"] as const).map((tab) => (
              <button
                role="tab"
                key={tab}
                id={`tab-${tab}`}
                aria-selected={view === tab}
                aria-controls={`view-${tab}`}
                onClick={() => setView(tab)}
              >
                {
                  {
                    camera: "Camera",
                    slam: "SLAM",
                    map: "Map",
                    graphs: "Graphs",
                  }[tab]
                }
              </button>
            ))}
          </div>
          <div
            role="tabpanel"
            id={`view-${view}`}
            aria-labelledby={`tab-${view}`}
          >
            {view === "map" && (
              <>
                <div ref={mapHost} className="map-host" />
                <label className="check">
                  <input
                    type="checkbox"
                    checked={onlineMap}
                    onChange={(e) => setOnlineMap(e.target.checked)}
                  />
                  Use online satellite imagery
                </label>
                <p className="view-note">
                  {age(t, "gps") < 3
                    ? `${value(t?.gps.lat, "°", 7)}, ${value(t?.gps.lon, "°", 7)}`
                    : "Cached coverage overview; aircraft position is unavailable."}{" "}
                  {onlineMap
                    ? "Online imagery needs an internet connection."
                    : "Offline imagery uses bundled coverage at its available zoom levels."}
                </p>
                {mapError && (
                  <p className="view-note">
                    Imagery unavailable for this view. Change zoom or use online
                    imagery; no substitute map is shown.
                  </p>
                )}
              </>
            )}
            {view === "camera" && (
              <>
                <div className="camera-tools">
                  <label>
                    Camera view
                    <select
                      value={topic}
                      onChange={(e) => {
                        setTopic(e.target.value);
                        setVideoError(false);
                      }}
                    >
                      <option value="/percep/overlay">
                        Composite detections
                      </option>
                      <option value="/image_raw">Raw camera</option>
                      <option value="/percep/qr/annotated">QR</option>
                      <option value="/percep/banner/annotated">Banner</option>
                      <option value="/percep/redzone/annotated">
                        Red zone
                      </option>
                    </select>
                  </label>
                </div>
                {fresh && !videoError ? (
                  <img
                    className="camera-feed"
                    src={videoUrl(activeEndpoint, topic)}
                    alt="Live aircraft camera"
                    onError={() => setVideoError(true)}
                  />
                ) : (
                  <div className="empty-view camera-feed">
                    Camera unavailable
                  </div>
                )}
                <p className="view-note">
                  Changing the displayed feed does not move the physical camera.
                  Camera tilt is a separate reviewed command.
                </p>
                <button onClick={() => setVideoError(false)}>
                  Retry video
                </button>
              </>
            )}
            {view === "slam" && (
              <Slam
                grid={grid}
                current={gridReceived > 0 && clock - gridReceived < 3000}
              />
            )}
            {view === "graphs" && (
              <Suspense fallback={<p>Loading graphs…</p>}>
                <Graphs history={history.current} theme={theme} live={fresh} />
              </Suspense>
            )}
          </div>
          <details>
            <summary>Flight and mission details</summary>
            <div className="details-grid">
              <Datum
                label="Roll / pitch"
                text={
                  age(t, "pose") < 3
                    ? `${value(t?.flight.roll_deg, "°")} / ${value(t?.flight.pitch_deg, "°")}`
                    : "Unavailable"
                }
              />
              <Datum
                label="Heading"
                text={value(age(t, "pose") < 3 ? t?.flight.yaw_deg : null, "°")}
              />
              <Datum
                label="Ground speed"
                text={value(
                  age(t, "velocity") < 3 ? t?.flight.gs : null,
                  " m/s",
                )}
              />
              <Datum
                label="Front lidar range"
                text={value(age(t, "lidar") < 3 ? t?.nav.front_m : null, " m")}
              />
              <Datum
                label="Gap bearing"
                text={value(
                  age(t, "avoidance") < 3 && age(t, "lidar") < 3
                    ? ((t?.nav.centering_err ?? NaN) * 180) / Math.PI
                    : null,
                  "°",
                )}
              />
              <Datum
                label="EKF"
                text={
                  age(t, "ekf") < 3
                    ? String(t?.safety.ekf ?? "Unavailable")
                    : "Unavailable"
                }
              />
              <Datum
                label="FC fence"
                text={
                  age(t, "fence") < 3
                    ? t?.safety.geofence || "Unavailable"
                    : "Unavailable"
                }
              />
              <Datum
                label="Delivery error"
                text={value(t?.mission.delivery_offset_m, " m")}
              />
              <Datum
                label="Landing"
                text={t?.mission.landing_precision || "Unavailable"}
              />
              <Datum
                label="Mission result"
                text={
                  t?.mission.result
                    ? `${t.mission.result}: ${t.mission.result_reason || ""}`
                    : "Unavailable"
                }
              />
            </div>
            <p className="view-note">
              Front lidar range is not aircraft clearance. Mission completion,
              disarm and physical delivery are separate observations.
            </p>
            {t?.checklist && (
              <p>
                {Object.entries(t.checklist)
                  .map(
                    ([step, done]) =>
                      `${step}: ${done ? "observed" : "not confirmed"}`,
                  )
                  .join(" · ")}
              </p>
            )}
          </details>
          <section className="observations">
            <h2>Detections</h2>
            <p className="observation-line">
              Start QR: {t?.percep.start_qr || "Unavailable"} · Target:{" "}
              {t?.percep.target_match ? "Matched" : "Unconfirmed"} · Banner:{" "}
              {t?.percep.banner ? "Detected" : "Unconfirmed"} · Red zone:{" "}
              {t?.percep.redzone_status || "UNKNOWN"}
            </p>
            <p className="view-note">
              Square on:{" "}
              {t?.percep.square_angle_deg == null
                ? t?.percep.square_reason || "Unavailable"
                : `${value(t.percep.square_angle_deg, "°")} at ${value(t.percep.square_standoff_m, " m")}`}{" "}
              · {t?.percep.redzone_exclusions?.length || 0} mapped red
              exclusions
            </p>
            <p className="view-note">
              {["qr", "banner", "red"]
                .map(
                  (kind) =>
                    `${kind}: ${value(t?.detector_rates?.[kind]?.hz, " Hz")}`,
                )
                .join(" · ")}
            </p>
            <table>
              <thead>
                <tr>
                  <th>Kind</th>
                  <th>Payload</th>
                  <th>Status</th>
                  <th>Reason</th>
                  <th>Count</th>
                </tr>
              </thead>
              <tbody>
                {t?.scans?.map((row) => (
                  <tr key={row.key}>
                    <td>{row.kind}</td>
                    <td>{row.payload || "Undecoded"}</td>
                    <td>{row.matched ? "Matched" : row.status}</td>
                    <td>{row.reason}</td>
                    <td>{row.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        </section>
        <aside className="task-area">
          <h2>{mode === "flight" ? "Normal mission" : "Test task"}</h2>
          {mode === "testing" && (
            <label>
              Task
              <select
                value={task}
                disabled={running}
                onChange={(e) => {
                  setTask(e.target.value);
                  setReview(null);
                }}
              >
                {tasks.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
          )}
          <p>{taskInfo.description}</p>
          {selectedTask === "mechanism" && (
            <label>
              Mechanism action
              <select
                value={action}
                onChange={(e) => setAction(e.target.value)}
              >
                {["lower", "release", "stow", "stop"].map((name) => (
                  <option key={name}>{name}</option>
                ))}
              </select>
            </label>
          )}
          <p className="task-note">
            {selectedTask === "mechanism"
              ? "Disarmed bench task. Accepted release does not prove detachment."
              : "Uses current mission behaviours and configured heights. Readiness and GUIDED mode are required. No browser joystick."}
          </p>
          <button
            disabled={!canStart}
            onClick={() => {
              const request = taskCommand(selectedTask, action);
              setReview({ ...request, label: `Start ${taskInfo.label}` });
            }}
          >
            Review start
          </button>
          <button
            disabled={!linked || busy}
            onClick={() =>
              setReview({
                cmd: "abort",
                args: {},
                label: "Stop and recover using the production abort procedure",
              })
            }
          >
            Stop and return
          </button>
          {review && (
            <section className="review">
              <h3>{review.label}</h3>
              <p>Endpoint: {activeEndpoint}</p>
              <p>
                Mode: {fcu ? t?.mission.mode : "Unavailable"} · Armed:{" "}
                {fcu ? (t?.mission.armed ? "Yes" : "No") : "Unavailable"}
              </p>
              <p>
                Runtime acceptance does not confirm the aircraft outcome. Stop
                uses the current stage-aware LAND/RTL procedure.
              </p>
              <button
                disabled={
                  busy || !reviewAllowed(t, linked, review.cmd, review.args)
                }
                onClick={() => {
                  const request = review;
                  setReview(null);
                  void perform(request.cmd, request.args);
                }}
              >
                Confirm{" "}
                {review.cmd === "start_mission" || review.cmd === "start_test"
                  ? "Start"
                  : "command"}
              </button>
              <button onClick={() => setReview(null)}>Cancel</button>
            </section>
          )}
          {outcome && (
            <p role="status">
              {outcome.cmd}: {outcome.state}. {outcome.reason}
            </p>
          )}
          <details open>
            <summary>Readiness</summary>
            {!fresh && <p>Readiness unavailable</p>}
            {t?.safety.ready_reasons?.map((reason) => (
              <p key={reason}>{reason}</p>
            ))}
            {t?.safety.ready_items?.map((item) => (
              <div className="readiness-row" key={item.key}>
                <span>
                  {item.label}: {item.ok ? "Ready" : "Blocked"}
                </span>
                <span>
                  {String(item.value ?? "Unavailable")} · {item.reason}
                </span>
              </div>
            ))}
            {fresh && !t?.safety.ready && (
              <p>
                {t?.mission.mode !== "GUIDED"
                  ? "GUIDED mode is required for flight tasks."
                  : "Correct the named inputs before starting."}
              </p>
            )}
          </details>
          <details>
            <summary>Organiser inputs</summary>
            <button onClick={() => setArenaOpen(true)}>Arena dimensions</button>
            <button onClick={() => setLidarOpen(true)}>
              Lidar calibration
            </button>
            <Field label="Target QR payload" text={target} change={setTarget} />
            <button
              disabled={!fresh || busy}
              onClick={() => void perform("set_target", { target })}
            >
              Set target
            </button>
            {(["green", "orange", "red"] as const).map((name) => (
              <Field
                key={name}
                label={`${name} banner HEX`}
                text={colours[name]}
                change={(shade) => setColours({ ...colours, [name]: shade })}
              />
            ))}
            <button
              disabled={!fresh || busy || t?.mission.armed !== false}
              onClick={() =>
                reviewedSend("set_banner_colours", { colours }, true)
              }
            >
              Apply banner colours
            </button>
            <label>
              Delivery-zone boundary, latitude then longitude
              <textarea
                value={zoneText}
                onChange={(e) => setZoneText(e.target.value)}
              />
            </label>
            <button
              disabled={!fcu || busy || t?.mission.armed !== false}
              onClick={() => {
                try {
                  reviewedSend(
                    "set_delivery_zone",
                    { vertices: boundary(zoneText) },
                    true,
                  );
                } catch (reason) {
                  setError(String(reason));
                }
              }}
            >
              Apply delivery zone
            </button>
            <label>
              Arena inclusion fence, latitude then longitude
              <textarea
                value={fenceText}
                onChange={(e) => setFenceText(e.target.value)}
              />
            </label>
            <button
              disabled={!fcu || busy || t?.mission.armed !== false}
              onClick={() => {
                try {
                  reviewedSend(
                    "set_geofence",
                    { vertices: boundary(fenceText) },
                    true,
                  );
                } catch (reason) {
                  setError(String(reason));
                }
              }}
            >
              Apply arena fence
            </button>
            <p className="view-note">
              Delivery zone, arena inclusion fence and camera red exclusions
              have different meanings. Aircraft validation remains
              authoritative.
            </p>
          </details>
          <details>
            <summary>Aircraft controls</summary>
            <p>
              Transmitter takeover and FCU failsafes retain priority. Recovery
              remains available when readiness is blocked.
            </p>
            <div className="actions">
              <button
                disabled={!fcu || busy || running}
                onClick={() =>
                  reviewedSend("set_mode", { mode: "GUIDED" }, true)
                }
              >
                GUIDED
              </button>
              <button
                disabled={
                  !fcu ||
                  !t?.safety.ready ||
                  t?.mission.mode !== "GUIDED" ||
                  busy ||
                  running
                }
                onClick={() => reviewedSend("arm", {}, true)}
              >
                Arm
              </button>
              <button
                disabled={
                  !fcu ||
                  busy ||
                  t?.mission.armed !== true ||
                  t?.safety.on_ground !== true ||
                  age(t, "extended_state") >= 3
                }
                onClick={() => reviewedSend("disarm", {}, true)}
              >
                Disarm
              </button>
              <button
                disabled={!linked || busy}
                onClick={() => reviewedSend("land", {}, true)}
              >
                Land
              </button>
              <button
                disabled={!linked || busy}
                onClick={() => reviewedSend("set_mode", { mode: "RTL" }, true)}
              >
                RTL
              </button>
              <button
                disabled={!linked || busy}
                onClick={() => reviewedSend("abort", {}, true)}
              >
                Abort
              </button>
            </div>
            <label>
              Takeoff height above home, metres
              <input
                type="number"
                min="1"
                max="10"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
              />
            </label>
            <button
              disabled={
                !fcu ||
                !t?.safety.ready ||
                t?.mission.mode !== "GUIDED" ||
                busy ||
                running
              }
              onClick={() => reviewedSend("takeoff", { alt: height }, true)}
            >
              Review takeoff
            </button>
            <div className="actions">
              <button
                disabled={!fcu || busy}
                onClick={() =>
                  reviewedSend("gimbal_pitch", { degrees: 0 }, true)
                }
              >
                Camera forward
              </button>
              <button
                disabled={!fcu || busy}
                onClick={() =>
                  reviewedSend("gimbal_pitch", { degrees: -90 }, true)
                }
              >
                Camera down
              </button>
            </div>
            <p className="view-note">
              Winch controls are under Testing → Mechanism only. Current
              hardware has no GPIO encoder acquisition.
            </p>
          </details>
        </aside>
      </main>
      <footer>
        <details open>
          <summary>Events</summary>
          <div className="event-log">
            {events.length
              ? events.map((event, index) => <div key={index}>{event}</div>)
              : "No events yet"}
          </div>
        </details>
      </footer>
      {arenaOpen && (
        <ArenaDimensions
          S={t}
          connected={fcu}
          send={reviewedSend}
          onClose={() => setArenaOpen(false)}
        />
      )}
      {lidarOpen && (
        <LidarCalibration
          S={t}
          connected={fcu}
          send={reviewedSend}
          onClose={() => setLidarOpen(false)}
        />
      )}
    </div>
  );
}
function Datum({ label, text }: { label: string; text: string }) {
  return (
    <dl>
      <dt>{label}</dt>
      <dd>{text}</dd>
    </dl>
  );
}
function Field({
  label,
  text,
  change,
}: {
  label: string;
  text: string;
  change: (text: string) => void;
}) {
  return (
    <label>
      {label}
      <input value={text} onChange={(event) => change(event.target.value)} />
    </label>
  );
}
function Slam({ grid, current }: { grid: Grid | null; current: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    if (!grid || !canvas.current || grid.data.length !== grid.w * grid.h)
      return;
    const context = canvas.current.getContext("2d");
    if (!context) return;
    const image = context.createImageData(grid.w, grid.h);
    grid.data.forEach((cell, index) => {
      const shade = cell < 0 ? 145 : Math.round(255 * (1 - cell / 100)),
        offset =
          ((grid.h - 1 - Math.floor(index / grid.w)) * grid.w +
            (index % grid.w)) *
          4;
      image.data.set([shade, shade, shade, 255], offset);
    });
    context.putImageData(image, 0, 0);
  }, [grid]);
  return (
    <div className="slam-view">
      <canvas
        ref={canvas}
        width={grid?.w || 1}
        height={grid?.h || 1}
        aria-label="SLAM occupancy grid"
      />
      {grid ? (
        <span>
          {current ? "Live" : "Stale"} SLAM · frame {grid.frame || "Unknown"} ·
          origin {value(grid.ox)}, {value(grid.oy)} m · yaw {value(grid.yaw)}{" "}
          rad · stamp {grid.stamp} · {grid.res} m/cell
        </span>
      ) : (
        <span>
          SLAM unavailable. It must be explicitly enabled in the current
          runtime.
        </span>
      )}
    </div>
  );
}
