import type { Telemetry } from "./types";

export interface ConnectionProfile {
  id: string;
  name: string;
  endpoint: string;
}

export function commandId(provider: {
  randomUUID?: () => string;
  getRandomValues: (bytes: Uint8Array) => Uint8Array;
} = globalThis.crypto): string {
  if (typeof provider?.randomUUID === 'function') return provider.randomUUID();
  if (typeof provider?.getRandomValues !== 'function') throw new Error('This browser cannot generate safe command IDs');
  // getRandomValues is available on HTTP intranet pages; randomUUID requires
  // a secure context. Keep the same UUID protocol without a weak fallback.
  const bytes = new Uint8Array(16);
  provider.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 15) | 64;
  bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}
export type CommandState =
  | "Submitted"
  | "Accepted"
  | "Running"
  | "Completed"
  | "Failed"
  | "Outcome unknown";
export interface CommandOutcome {
  command_id: string;
  cmd: string;
  state: CommandState;
  reason: string;
}
export const tasks = [
  {
    id: "mission",
    label: "Full mission",
    description:
      "Complete production workflow, including takeoff, delivery, return and landing.",
  },
  {
    id: "start_qr",
    label: "Start QR",
    description: "Production takeoff and start-QR identification test part.",
  },
  {
    id: "corridor_out",
    label: "Outbound corridor",
    description: "Production banner alignment and outbound corridor test part.",
  },
  {
    id: "search",
    label: "Target QR search",
    description:
      "Production target-search test part, using the configured arena.",
  },
  {
    id: "delivery",
    label: "Payload delivery",
    description:
      "Production delivery test part. Calibration and mission readiness still apply.",
  },
  {
    id: "return_corridor",
    label: "Return corridor",
    description: "Production return-corridor test part.",
  },
  {
    id: "mechanism",
    label: "Mechanism only",
    description:
      "Bench lower, release, stow or stop through the existing winch backend. No automatic arming.",
  },
] as const;

export function endpoint(value: string): string {
  const u = new URL(value.trim());
  if (
    !["ws:", "wss:"].includes(u.protocol) ||
    !u.hostname ||
    u.username ||
    u.password ||
    u.hash
  )
    throw new Error(
      "Use a WebSocket URL without credentials, such as ws://192.168.0.101:8765",
    );
  return u.toString().replace(/\/$/, "");
}
export function defaultProfile(host = "127.0.0.1"): ConnectionProfile {
  return {
    id: "local",
    name: "Production runtime",
    endpoint: `ws://${host}:8765`,
  };
}
export function videoUrl(value: string, topic: string): string {
  const u = new URL(endpoint(value));
  u.protocol = u.protocol === "wss:" ? "https:" : "http:";
  u.port = "8080";
  u.pathname = "/stream";
  u.search = "";
  u.searchParams.set("topic", topic);
  u.searchParams.set("type", "mjpeg");
  return u.toString();
}
export function age(t: Telemetry | null, source: string): number {
  const n = t?.sample_age_s?.[source];
  return typeof n === "number" && Number.isFinite(n) && n >= 0 ? n : Infinity;
}
export function freshFcu(t: Telemetry | null): boolean {
  return t?.safety?.fcu_connected === true && age(t, "state") < 3;
}
export function missionActive(t: Telemetry | null): boolean {
  const phase = t?.mission?.state?.toUpperCase();
  return (
    !!phase &&
    !["IDLE", "WAITING", "COMPLETED", "FAILED", "RESET"].includes(phase)
  );
}
export function startAllowed(
  t: Telemetry | null,
  connected: boolean,
  task: string,
): boolean {
  if (!connected || !freshFcu(t) || missionActive(t)) return false;
  if (task === "mechanism") return t?.mission.armed === false && age(t, "winch") < 3 && !!t.winch?.state && t.winch.state !== "FAULT";
  return (
    age(t, "readiness") < 3 &&
    t?.safety?.ready === true &&
    t.mission.mode === "GUIDED"
  );
}
export function taskCommand(
  task: string,
  action: string,
): { cmd: string; args: Record<string, unknown> } {
  if (!tasks.some((t) => t.id === task))
    throw new Error("Task is not implemented by the production runtime");
  if (task === "mechanism") {
    if (!["lower", "release", "stow", "stop"].includes(action))
      throw new Error("Select a mechanism action");
    return { cmd: "winch", args: { action } };
  }
  return task === "mission"
    ? { cmd: "start_mission", args: {} }
    : { cmd: "start_test", args: { part: task } };
}

export function reviewAllowed(
  t: Telemetry | null,
  connected: boolean,
  cmd: string,
  args: Record<string, unknown>,
): boolean {
  if (!connected) return false;
  if (
    ["abort", "land"].includes(cmd) ||
    (cmd === "set_mode" && args.mode === "RTL")
  )
    return true;
  if (!freshFcu(t)) return false;
  if (["start_mission", "start_test"].includes(cmd))
    return startAllowed(t, connected, "mission");
  if (["arm", "takeoff"].includes(cmd))
    return (
      startAllowed(t, connected, "mission") &&
      (cmd !== "takeoff" ||
        (typeof args.alt === "number" &&
          Number.isFinite(args.alt) &&
          args.alt >= 1 &&
          args.alt <= 10))
    );
  if (cmd === "disarm")
    return (
      t?.mission.armed === true &&
      t.safety.on_ground === true &&
      age(t, "extended_state") < 3
    );
  if (
    [
      "lidar_cal_apply",
      "set_banner_colours",
      "set_geofence",
      "set_delivery_zone",
    ].includes(cmd)
  )
    return t?.mission.armed === false && !missionActive(t);
  if (cmd === "winch") return startAllowed(t, connected, "mechanism");
  return !missionActive(t);
}
export function commandEnvelope(
  id: string,
  cmd: string,
  args: unknown,
  now = Date.now(),
): string {
  return JSON.stringify({
    v: 1,
    kind: "command",
    t: now / 1000,
    data: { cmd_id: id, cmd, args, confirm: true },
  });
}
export function acknowledgement(data: {
  cmd_id: string;
  cmd: string;
  result: string;
  reason?: string;
}): CommandOutcome {
  return {
    command_id: data.cmd_id,
    cmd: data.cmd,
    state:
      data.result === "accepted"
        ? "Accepted"
        : data.result === "rejected"
          ? "Failed"
          : "Outcome unknown",
    reason:
      data.reason ||
      (data.result === "accepted"
        ? "Request accepted by the runtime; physical outcome is not confirmed."
        : ""),
  };
}
