"""AeroTHON Gazebo integration helpers."""
