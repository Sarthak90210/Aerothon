#!/usr/bin/env bash
# Destination update 20261031-skip, run as pi5 on the Pi, on top of
# 20261031-venue. Installs the sources that differ from HEAD (SOURCE_COMMIT):
# the skip-corridor mission (mission_tree, contracts, execution_node) and the
# operator's actuator start waiver, plus the GCS built from the same source.
# --symlink-install: no rebuild (setup.py unchanged). The runtime is stopped
# first; only the web host is restarted, and autoconnect starts the new runtime.
#
#   bash deploy_skip.sh --dry-run    verify and print what would change
#   bash deploy_skip.sh              disconnect, back up, install, restart web host
set -euo pipefail
ws=/home/pi5/aerothon_ws
task=$(cd "$(dirname "$0")" && pwd)
api=http://127.0.0.1:8899
FILES=$(cat "$task/FILES")

state() { curl -s -m 10 "$api/api/state"; }
state | python3 -c '
import json, sys
s = json.load(sys.stdin)
e = s.get("execution") or {}
active = bool(e) and e.get("state") not in {"Completed", "Failed", "Outcome unknown"}
print("runtime", s["runtime"], "| profile", s["profile_id"], "| fresh", s["fresh"], "| can_disconnect", s["can_disconnect"], "| execution", e.get("state"))
assert not active, "a task is running: finish it first"
assert s["runtime"] == "Stopped" or s["can_disconnect"], "runtime up without a confirmed disarm"'

for f in $FILES; do case $f in *.py) python3 -c "import ast,sys; ast.parse(open(sys.argv[1]).read())" "$task/$f";; esac; done
for f in $FILES; do
    if [[ ! -e $ws/$f ]]; then echo "  new    $f"
    elif cmp -s "$task/$f" "$ws/$f"; then echo "  same   $f"
    else echo "  change $f"; fi
done
echo "  gcs: $(find "$task/gcs" -type f | wc -l) new files replace $(find "$ws/gcs" -type f | wc -l)"
[[ ${1:-} == --dry-run ]] && exit 0

# 0. Runtime off.
if [[ $(state | python3 -c 'import json,sys; print(json.load(sys.stdin)["runtime"])') != Stopped ]]; then
    curl -s -m 40 -X POST -H 'Content-Type: application/json' -d '{}' "$api/api/disconnect" | python3 -c \
        'import json,sys; d=json.load(sys.stdin); assert d.get("runtime")=="Stopped", d; print("runtime", d["runtime"])'
fi

# 1. Back up what is replaced (files that exist).
stamp=$(date +%Y%m%dT%H%M%S)
existing=$(for f in $FILES; do [[ -e $ws/$f ]] && echo "$f"; done)
tar -czf "$task/before_$stamp.tar.gz" -C "$ws" $existing gcs runtime_manifest.json
sha256sum "$task/before_$stamp.tar.gz" | tee "$task/backups_$stamp.sha256"

# 2. Install sources and GCS, then the manifest.
for f in $FILES; do
    mkdir -p "$(dirname "$ws/$f")"
    cp "$task/$f" "$ws/$f.deploy-skip"; chmod 644 "$ws/$f.deploy-skip"; mv "$ws/$f.deploy-skip" "$ws/$f"
done
chmod 755 "$ws/scripts/check_pi_runtime.sh"
rm -rf "$ws/gcs.deploy-skip"; cp -r "$task/gcs" "$ws/gcs.deploy-skip"
rm -rf "$ws/gcs.before-venue-skip"; mv "$ws/gcs" "$ws/gcs.before-venue-skip"; mv "$ws/gcs.deploy-skip" "$ws/gcs"; rm -rf "$ws/gcs.before-venue-skip"
python3 - "$ws" "$(cat "$task/SOURCE_COMMIT")" $FILES <<'PY'
import hashlib, json, sys
from pathlib import Path
root, commit, files = Path(sys.argv[1]), sys.argv[2], sys.argv[3:]
path = root / 'runtime_manifest.json'
m = json.loads(path.read_text())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for f in files:
    m['files'][f] = digest(root / f)
m['files'] = {k: v for k, v in m['files'].items() if not k.startswith('gcs/')}
for p in sorted((root / 'gcs').rglob('*')):
    if p.is_file():
        m['files'][p.relative_to(root).as_posix()] = digest(p)
m['deploy_20261031_skip'] = f'HEAD {commit[:7]}: {len(files)} sources (skip-corridor mission, actuator start waiver) and GCS'
tmp = path.with_suffix('.tmp'); tmp.write_text(json.dumps(m, indent=2)); tmp.replace(path)
bad = [k for k, v in m['files'].items() if not (root / k).is_file() or digest(root / k) != v]
print('MANIFEST', len(m['files']), 'files;', 'all verified' if not bad else f'{len(bad)} MISMATCH: {bad[:5]}')
PY

# 3. The installed links reach the changed sources, and the new modules work
# in the container's Python/OpenCV. Links chain through container paths.
docker exec aerothon-runtime bash -c 'set -e
f=$(readlink -f /workspace/install/mission_bringup/share/mission_bringup/launch/mission2.launch.py)
[[ $f == /workspace/src/* ]] && grep -q "marker_kind" "$f"
v=$(readlink -f /workspace/install/mission_bringup/share/mission_bringup/config/venue.yaml)
[[ $v == /workspace/src/* ]] && grep -q "search_brake_mps2: 1.0" "$v"
grep -q "record_point" "$(readlink -f /workspace/build/aerothon_runtime/aerothon_runtime)/web.py"
grep -q "organiser_points" "$(readlink -f /workspace/build/gcs_aggregator/gcs_aggregator)/aggregator.py"
grep -q "class HighTransit" "$(readlink -f /workspace/build/mission_bt/mission_bt)/mission_tree.py"
grep -q "mission_skip_corridor" "$(readlink -f /workspace/build/aerothon_runtime/aerothon_runtime)/contracts.py"
grep -q "waived_for" "$(readlink -f /workspace/build/aerothon_runtime/aerothon_runtime)/execution_node.py"
echo "installed links reach src/"
source /opt/ros/jazzy/setup.bash; source /workspace/install/setup.bash
python3 - <<PY2
import numpy as np, cv2
from perception_qr import tag_decode
from gcs_aggregator import organiser_points
from mission_bt import mission_tree, delivery_zone, mav_commander
from aerothon_runtime import contracts, execution_node
assert "mission_skip_corridor" in contracts.TASKS and contracts.MISSION_TASKS
print("imports ok; cv2", cv2.__version__)
cells = np.array(tag_decode.marker_cells("DICT_APRILTAG_36h11", 300), bool)
tag = np.where(np.kron(cells, np.ones((40, 40), bool)), 0, 255).astype(np.uint8)
img = np.full((720, 1280), 255, np.uint8); img[200:200 + tag.shape[0], 400:400 + tag.shape[1]] = tag
found, unread = tag_decode.TagDecoder().read(img)
assert [p for p, _ in found] == ["300"], (found, unread)
print("AprilTag 36h11 ID 300 decodes on this OpenCV")
PY2'

# 4. Restart the web host only (its container loop relaunches it in 2 s).
docker exec aerothon-runtime pkill -f 'aerothon_runtime/web_host' || true
docker exec aerothon-runtime pkill -f 'ros2 run aerothon_runtime web_host' || true
for i in $(seq 1 30); do sleep 1; state >/dev/null 2>&1 && break; done
state | python3 -c 'import json,sys; s=json.load(sys.stdin); print("web host back: runtime", s["runtime"], "| profile", s["profile_id"], "| autoconnect_suspended", s.get("autoconnect_suspended"))'
curl -s -m 10 "$api/" | grep -o 'assets/index-[A-Za-z0-9_-]*\.js'
echo "$(date -Is) DEPLOY 20261031-skip INSTALLED"
