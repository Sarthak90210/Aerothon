"""The arena's dimensions, entered at the GCS instead of fixed at launch.

The organisers give the arena in feet and inches and may change it between
practice and the competition: a 5 m or a 10 m corridor, a 1 m QR, a 5 ft red
zone. Every dimension the algorithms depend on is one field here, in metres,
validated once, shared by the GCS aggregator (which refuses bad input with a
reason) and by mission_bt (which rebuilds its tree with the values while the
aircraft is on the ground).

`mission_params(dims)` is the whole contract between the two: the mission
parameters each dimension sets. A field that sets none is still recorded,
because the operator needs one place that says what the arena is; the GCS
marks those "recorded only" so nobody believes they steer anything.
"""

import copy
import math

FT, INCH = 0.3048, 0.0254

# (group, key, label, default m, min, max, used_by) -- default is today's
# simulated arena, so nothing changes until an operator supplies values.
FIELDS = (
    ("corridor", "length_m", "Corridor length", 10.0, 2.0, 30.0,
     "clear distance needed to cross the gate"),
    ("corridor", "width_m", "Corridor width", 3.5, 1.0, 10.0, None),
    ("corridor", "wall_height_m", "Corridor wall height", 3.6, 1.0, 8.0,
     "upper bound on the navigation height"),
    ("corridor", "nav_height_m", "Navigation height", 3.0, 0.8, 7.0,
     "corridor flying altitude"),
    ("corridor", "spacing_m", "Corridor spacing, centre to centre", 4.0, 1.0, 30.0,
     "where the return lane is found"),
    ("hall", "length_m", "Hall length", 80.0, 10.0, 500.0, None),
    ("hall", "width_m", "Hall width", 45.0, 10.0, 500.0, None),
    ("hall", "ceiling_m", "Hall ceiling / max altitude", 30.0, 3.0, 120.0,
     "caps take-off, search and drop altitudes"),
    ("banner", "width_m", "Banner width", 3.7, 0.3, 10.0, "range to the banner"),
    ("banner", "height_m", "Banner height", 1.15, 0.2, 5.0, "range to the banner"),
    ("banner", "border_m", "Banner border", 3 * INCH, 0.0, 0.5, None),
    # The field PDF (23 Oct 2026) gives the hung arch board 1.5 ft and the
    # board on the ground 1 ft. Ground boards are ranged by where the ray to
    # them meets the ground, not by their size, so this one is recorded (and
    # builds the simulated board); omitted, it is the hung banner's height.
    ("banner", "ground_height_m", "Ground banner height", 1.15, 0.1, 5.0, None),
    ("banner", "suspended_bottom_m", "Hung banner lower edge", 2.805, 0.5, 8.0,
     "the height the square-up scans the hung banner at"),
    ("qr", "target_m", "Target QR side", 2.2, 0.2, 5.0,
     "search altitude and landing"),
    ("qr", "start_m", "Start QR side", 2.2, 0.2, 5.0,
     "precision landing on the start QR"),
    ("qr", "border_m", "QR white border", 3 * INCH, 0.0, 0.5, None),
    ("red_zone", "side_m", "Red zone side", 5 * FT, 0.3, 20.0, None),
    ("red_zone", "border_m", "Red zone border", 0.5 * FT, 0.0, 2.0, None),
    ("payload", "length_m", "Payload length", 0.10, 0.02, 0.5,
     "drop confirmation blob size"),
    ("payload", "width_m", "Payload width", 0.055, 0.02, 0.5,
     "drop confirmation blob size"),
    ("payload", "mass_kg", "Payload mass (kg)", 0.10, 0.01, 2.0, None),
    # "Obstacles extend across approximately half the corridor width from a
    # wall", in the exit corridor only. The lidar avoids what is there; this
    # records the organisers' figure and builds the simulated slalom.
    ("obstacle", "reach_frac", "Obstacle reach, fraction of corridor width",
     0.5, 0.1, 0.9, None),
    # The lidar is one plane at the corridor altitude: an obstacle whose top
    # is under it is not seen. The field PDF's boards are 6 ft tall; omitted,
    # 95% of the wall height (the simulated slalom's).
    ("obstacle", "height_m", "Obstacle height", 3.42, 0.3, 8.0,
     "the navigation height must keep the lidar on the obstacles"),
)
PLACEMENTS = ("suspended", "ground", "both")
RETURN_SIDES = ("right", "left")
# The scan plane above the body (mission_tree: the LD06 0.0815 m over
# base_link), and how far under an obstacle's top it must stay to see it.
LIDAR_ABOVE_BODY_M = 0.0815
OBSTACLE_SCAN_MARGIN_M = 0.1


def defaults():
    out = {}
    for group, key, _label, default, *_ in FIELDS:
        out.setdefault(group, {})[key] = default
    out["banner"]["placement"] = "suspended"
    out["corridor"]["return_side"] = "right"
    return out


def validate(supplied):
    """A complete, checked copy of `supplied` over the defaults, or ValueError.

    Missing fields take the defaults, so a preset written before a field
    existed still loads. Unknown groups or fields are REFUSED: a value the
    aircraft silently ignores is worse than one it rejects, because the
    operator believes it was taken.
    """
    if not isinstance(supplied, dict):
        raise ValueError("dimensions must be an object of groups")
    known = {}
    for group, key, *_ in FIELDS:
        known.setdefault(group, set()).add(key)
    known["banner"].add("placement")
    known["corridor"].add("return_side")
    out = defaults()
    for group, values in supplied.items():
        if group not in known:
            raise ValueError(f"unknown dimension group {group!r}")
        if not isinstance(values, dict):
            raise ValueError(f"{group} must be an object of fields")
        for key, value in values.items():
            if key not in known[group]:
                raise ValueError(f"unknown dimension {group}.{key}")
            out[group][key] = value
    # Fields added after presets were saved follow the field they used to
    # share: a preset without them builds and checks the same arena as before.
    if "ground_height_m" not in (supplied.get("banner") or {}):
        out["banner"]["ground_height_m"] = out["banner"]["height_m"]
    if "height_m" not in (supplied.get("obstacle") or {}):
        try:
            out["obstacle"]["height_m"] = round(0.95 * float(out["corridor"]["wall_height_m"]), 4)
        except (TypeError, ValueError):
            pass                                  # the range check below names it
    for group, key, label, _default, lo, hi, _ in FIELDS:
        value = out[group][key]
        if isinstance(value, bool):
            raise ValueError(f"{label} must be a number")
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise ValueError(f"{label} must be a number") from None
        if not math.isfinite(value) or not lo <= value <= hi:
            raise ValueError(f"{label} {value:g} is outside {lo:g}-{hi:g}")
        out[group][key] = value
    if out["banner"]["placement"] not in PLACEMENTS:
        raise ValueError(f"banner placement must be one of {', '.join(PLACEMENTS)}")
    if out["corridor"]["return_side"] not in RETURN_SIDES:
        raise ValueError(f"return side must be one of {', '.join(RETURN_SIDES)}")
    c, h = out["corridor"], out["hall"]
    # Relationships a typo breaks and the aircraft would discover in the air.
    if c["nav_height_m"] >= c["wall_height_m"]:
        raise ValueError("navigation height must be below the corridor wall height")
    if c["nav_height_m"] >= h["ceiling_m"]:
        raise ValueError("navigation height must be below the hall ceiling")
    if c["spacing_m"] < c["width_m"]:
        raise ValueError("corridor spacing must be at least the corridor width")
    if out["banner"]["border_m"] * 2 >= min(out["banner"]["width_m"],
                                            out["banner"]["height_m"],
                                            out["banner"]["ground_height_m"]):
        raise ValueError("banner border leaves no coloured panel")
    # The corridor is flown at the navigation height or lower (the gate
    # crossing only ducks). Above it, the scan plane passes over obstacles
    # shorter than it and the navigator steers round nothing.
    plane = c["nav_height_m"] + LIDAR_ABOVE_BODY_M
    see_below = out["obstacle"]["height_m"] - OBSTACLE_SCAN_MARGIN_M
    if plane > see_below:
        raise ValueError(
            f"navigation height {c['nav_height_m']:.2f} m puts the lidar at "
            f"{plane:.2f} m, over the {out['obstacle']['height_m']:.2f} m "
            f"obstacles: it would not see them. Enter a navigation height of "
            f"{see_below - LIDAR_ABOVE_BODY_M:.2f} m or less")
    return out


def mission_params(dims, base):
    """The mission parameters these dimensions set, given the launch `base`.

    Only parameters with a measured meaning are touched. Altitudes keep the
    launch values unless the hall ceiling is lower, which caps them one metre
    under it.
    """
    d = validate(dims)
    c, h = d["corridor"], d["hall"]
    cap = h["ceiling_m"] - 1.0
    side = -1.0 if c["return_side"] == "right" else 1.0
    out = {
        "corridor_alt": c["nav_height_m"],
        "corridor_wall_m": c["wall_height_m"],
        "gate_advance_m": c["length_m"],
        "return_lane_offset_m": side * c["spacing_m"],
        "banner_w_m": d["banner"]["width_m"],
        "banner_h_m": d["banner"]["height_m"],
        "banner_bottom_m": d["banner"]["suspended_bottom_m"],
        "target_marker_m": d["qr"]["target_m"],
        "start_marker_m": d["qr"]["start_m"],
        "payload_size_m": max(d["payload"]["length_m"], d["payload"]["width_m"]),
        "banner_placement": d["banner"]["placement"],
    }
    for key in ("takeoff_alt", "search_alt", "drop_alt"):
        if key in base:
            out[key] = min(float(base[key]), cap)
    return out


def apply(base, dims):
    """`base` with the dimensions' parameters applied; base is not modified."""
    merged = copy.deepcopy(base)
    merged.update(mission_params(dims, base))
    return merged


# Presets every GCS starts with. Operator presets are saved beside these and
# may not reuse their names.
BUILTIN_PRESETS = {
    "Simulator arena": defaults(),
    # The organisers' clarifications. Corridor width and banner height are
    # not given: the width stays the simulator's 3.5 m (the banner is "equal
    # to the width of the corridor"), the height the rulebook board's 1.15 m.
    # A hung banner hangs from "a horizontal rod connecting the two corridor
    # walls", so its top is the 10 ft wall top and its lower edge 1.9 m --
    # under the 8 ft navigation height, so the gate crossing ducks.
    "SAE Aerothon 2026 (clarified)": {
        **defaults(),
        "corridor": {"length_m": 10.0, "width_m": 3.5, "wall_height_m": 10 * FT,
                     "nav_height_m": 8 * FT, "spacing_m": 4.0,
                     "return_side": "right"},
        "banner": {"width_m": 3.5, "height_m": 1.15, "border_m": 3 * INCH,
                   "suspended_bottom_m": 10 * FT - 1.15, "placement": "suspended"},
        "qr": {"target_m": 1.0, "start_m": 1.0, "border_m": 3 * INCH},
        "red_zone": {"side_m": 5 * FT, "border_m": 0.5 * FT},
        "payload": {"length_m": 0.10, "width_m": 0.055, "mass_kg": 0.10},
        "obstacle": {"reach_frac": 0.5},
    },
    # "AeroTHON 2026 Track 1 Field Properties" (organisers' PDF, 23 Oct
    # 2026), Mission 2, with the operator's 25 Oct reading: corridor 10 ft
    # high, banner hung down to 8 ft. Walls 22 ft long and 11.5 ft apart;
    # arch boards 11.5 x 1.5 ft, ground boards 11.5 x 1 ft, 1 in white
    # border; QR 1 m with no white border (the venue's boards are tags on a
    # white margin, below); red zone 10 x 10 ft, 1 in border;
    # three 3.5 x 6 ft boards on legs in the exit corridor; payload
    # 100 x 50 x 50 mm, 100 g. NOT GIVEN, entered here as working values to
    # measure on the day: lane spacing (5 m centre to centre), the hall
    # (70 x 45 m round take-off, lanes and the 40 x 30 m zone, outdoors) and the navigation
    # height -- 1.5 m, under the 8 ft banner edge and low enough for the
    # lidar to stay on the 6 ft boards.
    "AeroTHON 2026 Track 1 field (organiser PDF)": {
        **defaults(),
        "corridor": {"length_m": 22 * FT, "width_m": 11.5 * FT, "wall_height_m": 10 * FT,
                     "nav_height_m": 1.5, "spacing_m": 5.0, "return_side": "right"},
        "hall": {"length_m": 70.0, "width_m": 45.0, "ceiling_m": 30.0},
        "banner": {"width_m": 11.5 * FT, "height_m": 1.5 * FT, "border_m": 1 * INCH,
                   "ground_height_m": 1 * FT, "suspended_bottom_m": 8 * FT,
                   "placement": "both"},
        # The boards at the venue (29 Oct 2026) are AprilTag 36h11 tags on a
        # white margin about one tag cell wide, a tenth of the board, not the
        # PDF's borderless QR: 1 m taken as the board, 0.1 m its margin.
        "qr": {"target_m": 1.0, "start_m": 1.0, "border_m": 0.1},
        "red_zone": {"side_m": 10 * FT, "border_m": 1 * INCH},
        "payload": {"length_m": 0.10, "width_m": 0.05, "mass_kg": 0.10},
        "obstacle": {"reach_frac": round(3.5 / 11.5, 4), "height_m": 6 * FT},
    },
    # The venue as the operator surveyed and measured it (30 Oct 2026), over
    # the PDF where they differ: lanes 6 m long, walls 3 m, the same 3.5 m
    # (11.5 ft, the banners' width) wide; a 1.5-2 m gap between them (2 m);
    # two obstacles in the exit lane, 2 m tall, at most 1.5 m from the wall
    # and 4-5 cm thick; one red zone 3 x 3 m. Hall: round the surveyed
    # fence, 36 m from the back points to the zone's far edge and 47 m
    # across at the back. Boards and banners as the PDF.
    "AeroTHON 2026 venue (30 Oct survey)": {
        **defaults(),
        "corridor": {"length_m": 6.0, "width_m": 11.5 * FT, "wall_height_m": 3.0,
                     "nav_height_m": 1.5, "spacing_m": 11.5 * FT + 2.0,
                     "return_side": "right"},
        "hall": {"length_m": 50.0, "width_m": 50.0, "ceiling_m": 30.0},
        "banner": {"width_m": 11.5 * FT, "height_m": 1.5 * FT, "border_m": 1 * INCH,
                   "ground_height_m": 1 * FT, "suspended_bottom_m": 8 * FT,
                   "placement": "both"},
        "qr": {"target_m": 1.0, "start_m": 1.0, "border_m": 0.1},
        "red_zone": {"side_m": 3.0, "border_m": 1 * INCH},
        "payload": {"length_m": 0.10, "width_m": 0.05, "mass_kg": 0.10},
        "obstacle": {"reach_frac": round(1.5 / 3.5, 4), "height_m": 2.0},
    },
}
