"""Request display telemetry through a local router, never aircraft controls."""
import argparse
import collections
import json
import socket
import time

from pymavlink.dialects.v20 import ardupilotmega as mav

# Bounded rates for a 115200-baud telemetry UART. No parameter writes.
STREAMS = {1: 1, 24: 2, 27: 10, 30: 10, 32: 5, 33: 5, 74: 5, 147: 2, 241: 2}


def request_packets(system, component):
    encoder = mav.MAVLink(None, srcSystem=250, srcComponent=190)
    for message_id, hz in STREAMS.items():
        yield message_id, mav.MAVLink_command_long_message(
            system, component, mav.MAV_CMD_SET_MESSAGE_INTERVAL, 0,
            message_id, 1_000_000 / hz, 0, 0, 0, 0, 0).pack(encoder)


def main():
    args = argparse.ArgumentParser()
    args.add_argument('--port', type=int, default=14571)
    args.add_argument('--system', type=int, default=1)
    args.add_argument('--component', type=int, default=1)
    args.add_argument('--seconds', type=float, default=0, help='0 runs until stopped')
    options = args.parse_args()
    parser = mav.MAVLink(None)
    parser.robust_parsing = True
    counts = collections.Counter()
    acknowledgements = collections.Counter()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('127.0.0.1', options.port))
    sock.settimeout(1)
    begin = time.monotonic()
    requested = None
    try:
        while options.seconds <= 0 or time.monotonic() - begin < options.seconds:
            try:
                body, peer = sock.recvfrom(65535)
            except socket.timeout:
                continue
            if peer[0] != '127.0.0.1':
                continue
            for message in parser.parse_buffer(body) or []:
                if (message.get_srcSystem(), message.get_srcComponent()) != (
                        options.system, options.component):
                    continue
                counts[message.get_type()] += 1
                if message.get_type() == 'COMMAND_ACK' and message.command == mav.MAV_CMD_SET_MESSAGE_INTERVAL:
                    acknowledgements[str(message.result)] += 1
                if (message.get_type() == 'HEARTBEAT'
                        and message.autopilot != mav.MAV_AUTOPILOT_INVALID
                        and (requested is None or time.monotonic() - requested >= 20)):
                    for message_id, packet in request_packets(options.system, options.component):
                        sock.sendto(packet, peer)
                    requested = time.monotonic()
                    print(json.dumps({'stream_requests_hz': STREAMS,
                                      'identity': [options.system, options.component]}), flush=True)
    finally:
        sock.close()
        print(json.dumps({'seconds': round(time.monotonic() - begin, 2),
                          'messages': dict(counts),
                          'set_interval_ack_results': dict(acknowledgements)}), flush=True)


if __name__ == '__main__':
    main()
