"""Pi-side remote device driver. It has no Gazebo dependency or world inputs."""
import asyncio
from collections import deque
import json
import threading
import time

from aiohttp import ClientSession, ClientTimeout, WSMsgType
from .device_wire import TOPICS, unpack


class RemoteDevices:
    def __init__(self, node):
        from cv_bridge import CvBridge
        from rclpy.qos import QoSProfile, QoSReliabilityPolicy
        from rosidl_runtime_py.utilities import get_message
        from sensor_msgs.msg import Image
        from std_msgs.msg import String
        self.node = node
        self.url = node.declare_parameter('gateway', '').value
        self.system_id = node.declare_parameter('system_id', 1).value
        self.expected_hfov = node.declare_parameter('camera_hfov', .851721).value
        self.calibration = None
        self.bridge = CvBridge()
        self.types = {k: get_message(v[0]) for k,v in TOPICS.items()}
        local_qos = QoSProfile(depth=1, reliability=QoSReliabilityPolicy.RELIABLE)
        self.pubs = {k: node.create_publisher(Image if k == 'camera' else self.types[k], v[1], local_qos)
                     for k,v in TOPICS.items()}
        self.status = node.create_publisher(String, '/devices/status', 10)
        self.samples = {}
        self.stamps = {}
        self.manifest = {}
        self.session = None
        self.fault = 'not connected'
        self.clock = None
        self.clock_changed = None
        self.shutdown = threading.Event()

    def deliver(self, packet):
        from rclpy.serialization import deserialize_message
        kind, body = unpack(packet, self.session)
        msg = deserialize_message(body, self.types[kind])
        stamp = time.monotonic()
        self.samples.setdefault(kind, deque(maxlen=100)).append(stamp)
        if kind == 'clock':
            value = msg.clock.sec + msg.clock.nanosec/1e9
            if self.clock is not None and value < self.clock:
                raise ValueError('vehicle clock moved backwards; explicit reconnect required')
            if value != self.clock:
                self.clock_changed = stamp
            self.clock = value
        elif kind == 'camera_info':
            import math
            self.calibration = {'width':msg.width,'height':msg.height,
                'hfov':2*math.atan(msg.width/(2*msg.k[0])) if msg.k[0]>0 else None}
            self.stamps[kind] = msg.header.stamp.sec + msg.header.stamp.nanosec/1e9
        elif hasattr(msg, 'header'):
            self.stamps[kind] = msg.header.stamp.sec + msg.header.stamp.nanosec/1e9
        if kind == 'camera':
            decoded = self.bridge.compressed_imgmsg_to_cv2(msg, 'bgr8')
            image = self.bridge.cv2_to_imgmsg(decoded, 'bgr8')
            image.header = msg.header  # never re-stamp an old capture as fresh
            msg = image
        self.pubs[kind].publish(msg)

    def metric(self, kind, min_hz):
        q = self.samples.get(kind, [])
        age = time.monotonic()-q[-1] if q else None
        hz = (len(q)-1)/(q[-1]-q[0]) if len(q)>1 and q[-1]>q[0] else 0
        capture_age = self.clock-self.stamps[kind] if self.clock is not None and kind in self.stamps else None
        # Rates are measured in vehicle time separately from network delivery
        # freshness. Wall-clock Hz is reported without inventing sim speed.
        return {'ok': not self.fault and age is not None and age < 1 and
                      capture_age is not None and 0 <= capture_age < .3,
                'hz': round(hz,2), 'receipt_age_s': age, 'capture_age_s': capture_age,
                'required_vehicle_hz': min_hz, 'reason': self.fault or ''}

    def publish_status(self):
        from std_msgs.msg import String
        now = time.monotonic()
        healthy = not self.fault
        camera = self.metric('camera', 10)
        calibration_ok = self.calibration is not None and self.calibration.get('hfov') is not None and abs(self.calibration['hfov']-self.expected_hfov)<.02
        camera['ok'] = camera['ok'] and calibration_ok
        if not calibration_ok:
            camera['reason'] = 'camera calibration missing or HFOV differs from profile'
        lidar = self.metric('scan', 8)
        clock = {'ok': healthy and self.clock_changed is not None and now-self.clock_changed < 1,
                 'reason': self.fault or 'vehicle clock must be advancing'}
        data = {'identity': {'ok': healthy and self.manifest.get('system_id') == self.system_id and self.manifest.get('fcu_ok') is True,
                             'value': self.manifest.get('system_id'), 'session': self.session},
                'camera': camera, 'lidar': lidar, 'clock': clock}
        for key in ('camera_actuator', 'winch_actuator'):
            data[key] = dict(self.manifest.get(key) or {'ok': False, 'reason': 'not measured'})
            data[key]['ok'] = healthy and data[key].get('ok') is True and self.metric('joints',1)['ok']
        self.status.publish(String(data=json.dumps(data)))

    async def stream(self, client, path):
        async with client.ws_connect(self.url+path, params={'session': self.session},
                                     max_msg_size=9*1024*1024, heartbeat=2) as ws:
            async for msg in ws:
                if msg.type == WSMsgType.BINARY:
                    self.deliver(msg.data)
                elif msg.type in {WSMsgType.ERROR, WSMsgType.CLOSED}:
                    raise ValueError('device stream lost')
            raise ValueError('device stream closed')

    async def poll(self, client):
        while not self.shutdown.is_set():
            async with client.get(self.url+'/manifest') as response:
                response.raise_for_status()
                manifest = await response.json()
            if manifest.get('session') != self.session or manifest.get('system_id') != self.system_id:
                raise ValueError('vehicle identity/session changed; reconnect explicitly')
            self.manifest = manifest
            self.publish_status()
            await asyncio.sleep(.2)

    async def run(self):
        async with ClientSession(timeout=ClientTimeout(total=3)) as client:
            try:
                async with client.get(self.url+'/manifest') as response:
                    response.raise_for_status()
                    self.manifest = await response.json()
                if self.manifest.get('v') != 1 or self.manifest.get('system_id') != self.system_id:
                    raise ValueError('remote protocol or FCU identity mismatch')
                self.session = self.manifest['session']
                self.fault = ''
                tasks = [asyncio.create_task(self.stream(client, '/sensors')),
                         asyncio.create_task(self.stream(client, '/camera')),
                         asyncio.create_task(self.poll(client))]
                try:
                    done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
                    for task in done:
                        task.result()
                finally:
                    for task in tasks:
                        task.cancel()
                    await asyncio.gather(*tasks, return_exceptions=True)
            except Exception as exc:
                self.fault = str(exc)
            # Never follow a changed vehicle automatically, even if the URL
            # comes back. Keep the fault visible until an explicit reconnect.
            while not self.shutdown.is_set():
                self.publish_status()
                await asyncio.sleep(.2)


def main():
    import rclpy
    rclpy.init()
    node = rclpy.create_node('remote_devices')
    driver = RemoteDevices(node)
    thread = threading.Thread(target=lambda: asyncio.run(driver.run()), daemon=True)
    thread.start()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        driver.shutdown.set()
        thread.join(4)
        node.destroy_node()
        rclpy.try_shutdown()
