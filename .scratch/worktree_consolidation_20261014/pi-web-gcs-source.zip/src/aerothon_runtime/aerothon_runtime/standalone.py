"""Receive-only MAVLink display adapter. No ROS, serial access or flight commands."""
import asyncio
import copy
import math
import socket
import time

from pymavlink import mavutil
from pymavlink.dialects.v20 import ardupilotmega as dialect

from .web import Host


def measured(value, scale=1, unknown=None):
    return None if value == unknown or not math.isfinite(value) else value * scale


class Measurements:
    def __init__(self, profile):
        self.profile = profile
        self.seen = {}
        self.wrong_identity = None
        self.data = {
            'mission': {'state': 'monitoring', 'armed': None, 'mode': '', 'elapsed': 0},
            'flight': {k: None for k in ('x', 'y', 'alt', 'gs', 'roll_deg', 'pitch_deg', 'yaw_deg')},
            'gps': {'lat': None, 'lon': None, 'sats': None, 'fix': 'NO'},
            'power': {'volt': None, 'pct': None, 'current_a': None},
            'sensor_diagnostics': {}, 'nav': {},
            'percep': {'start_qr': '', 'target_match': False, 'banner': False,
                       'redzone_visible': False, 'redzone_status': 'UNKNOWN'},
            'safety': {'ready': False, 'fcu_connected': False},
            'checklist': {}, 'scans': [], 'runtime_health': {'fresh': False},
        }

    def accept(self, message, now=None):
        now = time.monotonic() if now is None else now
        if (message.get_srcSystem(), message.get_srcComponent()) != (
                self.profile['system_id'], self.profile['component_id']):
            if message.get_type() == 'HEARTBEAT':
                self.wrong_identity = f'{message.get_srcSystem()}/{message.get_srcComponent()}'
            return
        kind = message.get_type()
        d = self.data
        if kind == 'HEARTBEAT' and message.autopilot != dialect.MAV_AUTOPILOT_INVALID:
            self.seen['state'] = now
            self.wrong_identity = None
            d['mission'].update(armed=bool(message.base_mode & dialect.MAV_MODE_FLAG_SAFETY_ARMED),
                                mode=mavutil.mode_string_v10(message))
        elif kind == 'ATTITUDE':
            self.seen['attitude'] = now
            d['flight'].update(roll_deg=measured(math.degrees(message.roll)),
                              pitch_deg=measured(math.degrees(message.pitch)),
                              yaw_deg=measured(math.degrees(message.yaw) % 360))
        elif kind == 'GLOBAL_POSITION_INT':
            self.seen['pose'] = self.seen['gps'] = self.seen['velocity'] = now
            d['gps'].update(lat=message.lat * 1e-7, lon=message.lon * 1e-7)
            d['flight'].update(alt=message.relative_alt * .001,
                              gs=math.hypot(message.vx, message.vy) * .01)
        elif kind == 'LOCAL_POSITION_NED':
            self.seen['local_position'] = now
            d['flight'].update(x=measured(message.x), y=measured(message.y))
        elif kind == 'GPS_RAW_INT':
            self.seen['gps_raw'] = now
            d['gps'].update(sats=measured(message.satellites_visible, unknown=255),
                            fix='3D' if message.fix_type >= 3 else '2D' if message.fix_type == 2 else 'NO')
        elif kind == 'SYS_STATUS':
            self.seen['battery'] = self.seen['power'] = now
            d['power'].update(volt=measured(message.voltage_battery, .001, 65535) if message.voltage_battery > 0 else None,
                              pct=measured(message.battery_remaining, unknown=-1),
                              current_a=measured(message.current_battery, .01, -1))
        elif kind == 'VIBRATION':
            self.seen['vibration'] = now
            d['sensor_diagnostics'].update(vibration_mps2=[measured(x) for x in (
                message.vibration_x, message.vibration_y, message.vibration_z)],
                clipping=[message.clipping_0, message.clipping_1, message.clipping_2])
        elif kind == 'RAW_IMU':
            self.seen['magnetic'] = now
            axes = [message.xmag * .1, message.ymag * .1, message.zmag * .1]
            d['sensor_diagnostics'].update(magnetic_ut=axes,
                magnetic_strength_ut=math.hypot(*axes), magnetic_frame='FCU RAW_IMU sensor',
                magnetic_capture_stamp=message.time_usec * 1e-6)

    def snapshot(self, now=None):
        now = time.monotonic() if now is None else now
        d = copy.deepcopy(self.data)
        ages = {key: max(0, now - stamp) for key, stamp in self.seen.items()}
        d['sample_age_s'] = ages
        connected = ages.get('state', 999) < 3
        d['safety']['fcu_connected'] = connected
        if not connected:
            d['mission'].update(armed=None, mode='')
        if ages.get('attitude', 999) >= 1:
            d['flight'].update(roll_deg=None, pitch_deg=None, yaw_deg=None)
        if ages.get('pose', 999) >= 1:
            d['flight']['alt'] = None
        if ages.get('velocity', 999) >= 1:
            d['flight']['gs'] = None
        if ages.get('gps', 999) >= 1:
            d['gps'].update(lat=None, lon=None)
        if ages.get('gps_raw', 999) >= 3:
            d['gps'].update(sats=None, fix='NO')
        if ages.get('battery', 999) >= 3:
            d['power'].update(volt=None, pct=None, current_a=None)
        d['devices'] = {'identity': {'ok': connected, 'reason': (
            f'expected {self.profile["system_id"]}/{self.profile["component_id"]}; '
            f'other heartbeat {self.wrong_identity}' if self.wrong_identity else 'matching FCU heartbeat' if connected else 'no fresh matching FCU heartbeat')}}
        return d


class StandaloneHost(Host):
    standalone = True

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.proc = None
        self.profile_id = None
        self.link_task = None
        self.measurements = None
        self.link_error = ''

    def stopped(self):
        return self.link_task is None

    def editable(self):
        return self.stopped()

    def fresh(self):
        return (super().fresh() and self.telemetry.get('safety', {}).get('fcu_connected') is True)

    def state(self):
        return {**super().state(), 'standalone': True, 'execution_available': False,
                'can_disconnect': True, 'link_error': self.link_error}

    async def command(self, data):
        raise ValueError('standalone GCS is receive-only; mission, test and aircraft commands are unavailable')

    async def check(self):
        result = await super().check()
        for item in result['items']:
            if item['key'] == 'runtime':
                item['reason'] = 'mission algorithms and ROS are not installed in this standalone GCS'
            elif item['key'] == 'clock':
                item['reason'] = 'receive ages use Pi steady time; production ROS clock is not installed'
        return result

    async def start(self, app):
        from aiohttp import ClientSession, ClientTimeout
        self.session = ClientSession(timeout=ClientTimeout(total=10))
        self.background = asyncio.create_task(self.publish())

    async def close(self, app):
        await self.disconnect_profile()
        await super().close(app)

    async def connect_profile(self, profile):
        if profile['transport'] not in {'udp', 'tcp'}:
            raise ValueError('standalone GCS requires a router TCP/UDP endpoint')
        self.measurements = Measurements(profile)
        self.telemetry = None
        self.received = 0
        self.profile_id = profile['id']
        self.link_error = ''
        self.link_task = asyncio.create_task(self.receive(profile))

    async def disconnect_profile(self):
        if self.link_task:
            self.link_task.cancel()
            await asyncio.gather(self.link_task, return_exceptions=True)
        self.link_task = None
        self.profile_id = None
        self.measurements = None
        self.telemetry = None
        self.received = 0

    async def receive(self, profile):
        while True:
            sock = writer = None
            try:
                parser = dialect.MAVLink(None)
                parser.robust_parsing = True
                if profile['transport'] == 'udp':
                    allowed = {info[4][0] for info in await asyncio.get_running_loop().getaddrinfo(
                        profile['host'], None, family=socket.AF_INET)}
                    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    sock.setblocking(False)
                    sock.bind(('0.0.0.0', profile['bind_port']))
                else:
                    reader, writer = await asyncio.wait_for(asyncio.open_connection(
                        profile['host'], profile['port']), 5)
                self.link_error = ''
                while True:
                    if sock:
                        body, peer = await asyncio.get_running_loop().sock_recvfrom(sock, 65535)
                        if peer[0] not in allowed:
                            continue
                    else:
                        body = await reader.read(65535)
                        if not body:
                            raise OSError('router TCP connection closed')
                    for message in parser.parse_buffer(body) or []:
                        if message.get_type() != 'BAD_DATA':
                            self.measurements.accept(message)
            except (OSError, ValueError, asyncio.TimeoutError) as exc:
                self.link_error = str(exc)
            finally:
                if sock:
                    sock.close()
                if writer:
                    writer.close()
                    await writer.wait_closed()
            await asyncio.sleep(1)

    async def publish(self):
        while True:
            if self.measurements:
                self.telemetry = self.measurements.snapshot()
                self.received = time.monotonic()
                envelope = {'v': 1, 'kind': 'telemetry', 't': time.time(), 'data': self.telemetry}
                for client in list(self.clients):
                    try:
                        await asyncio.wait_for(client.send_json(envelope), .1)
                    except (TimeoutError, ConnectionError, RuntimeError):
                        self.clients.discard(client)
            await asyncio.sleep(.2)
