import { lazy, Suspense, useEffect, useRef, useState } from "react";
import maplibregl, { type GeoJSONSource } from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import type { Telemetry } from "./types";
import { TelemetryHistory } from "./telemetryHistory";
const Graphs = lazy(() => import("./Graphs"));
import {
  api,
  newProfile,
  terminal,
  commandId,
  type Capability,
  type ConnectionProfile,
  type RuntimeState,
} from "./runtime";
import "./gcs.css";
interface Point {
  lat: number;
  lon: number;
}
interface Grid {
  w: number;
  h: number;
  res: number;
  ox: number;
  oy: number;
  yaw: number;
  frame: string;
  stamp: number;
  data: number[];
}
const value = (n: number | null | undefined, u = "", p = 1) =>
  typeof n === "number" && Number.isFinite(n)
    ? `${n.toFixed(p)}${u}`
    : "Unavailable";
const points = (s: string): Point[] =>
  s
    .trim()
    .split("\n")
    .filter(Boolean)
    .map((row) => {
      const p = row.split(",").map(Number);
      if (p.length !== 2 || !p.every(Number.isFinite))
        throw new Error("Use latitude, longitude on each line");
      return { lat: p[0], lon: p[1] };
    });

export default function App() {
  const [mode, setMode] = useState<"flight" | "testing">("flight");
  const [theme, setTheme] = useState(
    localStorage.getItem("gcs-theme") || "light",
  );
  const [view, setView] = useState<"camera" | "slam" | "map" | "graphs">("map");
  const history = useRef(new TelemetryHistory());
  const historyProfile = useRef<string | null | undefined>(undefined);
  const [state, setState] = useState<RuntimeState | null>(null);
  const standalone = state?.standalone === true;
  const executionAvailable = state?.execution_available !== false;
  const [telemetry, setTelemetry] = useState<Telemetry | null>(null);
  const [received, setReceived] = useState(0),
    [clock, setClock] = useState(Date.now()),
    [linked, setLinked] = useState(false);
  const [events, setEvents] = useState<string[]>([]),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const [settings, setSettings] = useState(false),
    [profile, setProfile] = useState<ConnectionProfile>(newProfile),
    [rcText, setRcText] = useState("{}");
  const [capabilities, setCapabilities] = useState<Capability[]>([]);
  const [task, setTask] = useState("mission"),
    [height, setHeight] = useState(5),
    [target, setTarget] = useState(""),
    [action, setAction] = useState("stow");
  const [waypoints, setWaypoints] = useState<Point[]>([]),
    [routeText, setRouteText] = useState(""),
    [pick, setPick] = useState(false);
  const [zoneText, setZoneText] = useState(""),
    [fenceText, setFenceText] = useState(""),
    [review, setReview] = useState(false);
  const [grid, setGrid] = useState<Grid | null>(null),
    [gridReceived, setGridReceived] = useState(0),
    [videoTopic, setVideoTopic] = useState("/percep/overlay"),
    [logs, setLogs] = useState("");
  const [mapError, setMapError] = useState("");
  const mapHost = useRef<HTMLDivElement>(null),
    map = useRef<maplibregl.Map | null>(null),
    marker = useRef<maplibregl.Marker | null>(null);
  const centered = useRef(false),
    picker = useRef(false),
    trail = useRef<[number, number][]>([]);
  const log = (s: string) =>
    setEvents((p) => [
      ...p.slice(-149),
      `${new Date().toLocaleTimeString()} ${s}`,
    ]);
  const run = state?.execution,
    active = !terminal(run);
  const fresh =
    linked && received > 0 && clock - received < 3000 && state?.fresh === true;
  const t = fresh ? telemetry : null;
  const powerKnown = !!t && (t.sample_age_s?.power ?? Infinity) < 3;
  const poseKnown = !!t && (t.sample_age_s?.pose ?? Infinity) < 3;
  const stateKnown =
    !!t &&
    t.safety.fcu_connected === true &&
    (t.sample_age_s?.state ?? Infinity) < 3;
  async function refresh() {
    const next = await api<RuntimeState>("state");
    if (historyProfile.current !== next.profile_id) {
      history.current = new TelemetryHistory();
      historyProfile.current = next.profile_id;
    }
    setState(next);
  }
  async function perform(fn: () => Promise<unknown>) {
    setBusy(true);
    setError("");
    try {
      await fn();
      await refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  }
  async function command(cmd: string, args: unknown = {}) {
    const r = await api<{ state: string; reason: string }>("commands", {
      command_id: commandId(),
      cmd,
      args,
    });
    log(`${cmd}: ${r.state}${r.reason ? ", " + r.reason : ""}`);
  }
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    localStorage.setItem("gcs-theme", theme);
  }, [theme]);
  useEffect(() => {
    let stopped = false,
      ws: WebSocket,
      retry: number,
      pollBusy = false;
    const poll = async () => {
      if (pollBusy) return;
      pollBusy = true;
      try {
        await refresh();
      } catch {
      } finally {
        pollBusy = false;
      }
    };
    void poll();
    const timer = window.setInterval(() => {
      setClock(Date.now());
      history.current.tick(performance.now(), Date.now());
      void poll();
    }, 1000);
    const open = () => {
      ws = new WebSocket(
        `${location.protocol === "https:" ? "wss:" : "ws:"}//${location.host}/ws`,
      );
      ws.onopen = () => setLinked(true);
      ws.onmessage = (e) => {
        try {
          const m = JSON.parse(e.data);
          if (m.kind === "telemetry") {
            history.current.ingest(m.data, m.t, performance.now(), Date.now());
            setTelemetry(m.data);
            setReceived(Date.now());
          }
          if (m.kind === "map") {
            setGrid(m.data);
            setGridReceived(Date.now());
          }
          if (m.kind === "event") log(m.data.msg);
          if (m.kind === "receipt")
            log(`${m.data.state}: ${m.data.reason || ""}`);
          if (m.kind === "ack")
            log(
              `${m.data.cmd}: ${m.data.result}${m.data.reason ? ", " + m.data.reason : ""}`,
            );
          if (m.kind === "execution")
            setState((s) => (s ? { ...s, execution: m.data } : s));
        } catch {
          setError("Invalid telemetry message");
        }
      };
      ws.onclose = () => {
        history.current.disconnect();
        setLinked(false);
        if (!stopped) retry = window.setTimeout(open, 1500);
      };
    };
    open();
    return () => {
      stopped = true;
      window.clearInterval(timer);
      window.clearTimeout(retry);
      ws?.close();
    };
  }, []);
  useEffect(() => {
    picker.current = pick;
  }, [pick]);
  useEffect(() => {
    if (!mapHost.current) return;
    const m = new maplibregl.Map({
      container: mapHost.current,
      center: [0, 0],
      zoom: 2,
      maxZoom: 19,
      style: {
        version: 8,
        sources: {
          satellite: {
            type: "raster",
            tiles: [`${location.origin}/satellite/{z}/{x}/{y}.jpg`],
            tileSize: 256,
            minzoom: 0,
            maxzoom: 19,
            attribution:
              "© Esri, Maxar, Earthstar Geographics, and the GIS User Community",
          },
        },
        layers: [
          {
            id: "background",
            type: "background",
            paint: { "background-color": "#d8dbd8" },
          },
          { id: "satellite", type: "raster", source: "satellite" },
        ],
      },
    });
    m.addControl(new maplibregl.NavigationControl());
    m.on("error", () =>
      setMapError(
        "Map imagery unavailable. Check internet access or cached coverage.",
      ),
    );
    m.on("movestart", () => setMapError(""));
    m.on("load", () => {
      for (const id of ["route", "trail"]) {
        m.addSource(id, {
          type: "geojson",
          data: {
            type: "Feature",
            properties: {},
            geometry: { type: "LineString", coordinates: [] },
          },
        });
        m.addLayer({
          id,
          type: "line",
          source: id,
          paint: {
            "line-color": id === "route" ? "#222" : "#fff",
            "line-width": 3,
          },
        });
      }
    });
    m.on("click", (e) => {
      if (picker.current)
        setWaypoints((p) => [...p, { lat: e.lngLat.lat, lon: e.lngLat.lng }]);
    });
    map.current = m;
    marker.current = new maplibregl.Marker({ color: "#444" });
    return () => {
      marker.current?.remove();
      m.remove();
      map.current = null;
    };
  }, []);
  useEffect(() => {
    if (view === "map") map.current?.resize();
  }, [view]);
  useEffect(() => {
    const gps = t?.gps;
    if (
      !gps ||
      !Number.isFinite(gps.lat) ||
      !Number.isFinite(gps.lon) ||
      gps.fix === "NO"
    )
      return;
    const ll: [number, number] = [gps.lon, gps.lat];
    if (map.current) marker.current?.setLngLat(ll).addTo(map.current);
    if (!centered.current) {
      map.current?.jumpTo({ center: ll, zoom: 18 });
      centered.current = true;
    }
    trail.current = [...trail.current.slice(-1999), ll];
    (map.current?.getSource("trail") as GeoJSONSource | undefined)?.setData({
      type: "Feature",
      properties: {},
      geometry: { type: "LineString", coordinates: trail.current },
    });
  }, [telemetry, fresh]);
  useEffect(() => {
    setRouteText(
      waypoints
        .map((p) => `${p.lat.toFixed(7)}, ${p.lon.toFixed(7)}`)
        .join("\n"),
    );
    (map.current?.getSource("route") as GeoJSONSource | undefined)?.setData({
      type: "Feature",
      properties: {},
      geometry: {
        type: "LineString",
        coordinates: waypoints.map((p) => [p.lon, p.lat]),
      },
    });
  }, [waypoints]);
  const selectedTask = mode === "flight" ? "mission" : task,
    movement = state?.tasks.find((x) => x.id === selectedTask)?.movement,
    selectedProfile = state?.profiles.find((p) => p.id === state.profile_id);
  return (
    <div className="app">
      <header>
        <span className="wordmark">
          AeroTHON <span>GCS</span>
        </span>
        <nav aria-label="Operating mode">
          <button
            aria-pressed={mode === "flight"}
            onClick={() => {
              setMode("flight");
              setReview(false);
            }}
          >
            Flight operations
          </button>
          <button
            aria-pressed={mode === "testing"}
            onClick={() => {
              setMode("testing");
              setReview(false);
            }}
          >
            Testing
          </button>
        </nav>
        <div className="header-end">
          <span>{selectedProfile?.name || "No vehicle selected"}</span>
          <button onClick={() => setSettings(!settings)}>Connections</button>
          <button
            aria-label="Switch theme"
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
          >
            {theme === "light" ? "Dark" : "Light"}
          </button>
        </div>
      </header>
      <section className="status-strip" aria-label="Aircraft status">
        <Datum
          label="Connection"
          value={
            standalone
              ? stateKnown
                ? "Live FCU"
                : state?.runtime === "Running"
                  ? "Waiting for FCU"
                  : "Unavailable"
              : fresh
                ? "Live"
                : received
                  ? "Stale"
                  : "Unavailable"
          }
        />
        <Datum
          label="Aircraft mode"
          value={stateKnown ? t?.mission.mode || "Unavailable" : "Unavailable"}
        />
        <Datum
          label="Control owner"
          value={run?.control_owner || "Transmitter / FCU"}
        />
        <Datum
          label="Armed"
          value={
            stateKnown && t ? (t.mission.armed ? "Yes" : "No") : "Unavailable"
          }
        />
        <Datum
          label="Battery"
          value={value(powerKnown ? t?.power.pct : null, "%", 0)}
        />
        <Datum label="GPS satellites" value={value(t?.gps.sats, "", 0)} />
        <Datum
          label="Height"
          value={value(poseKnown ? t?.flight.alt : null, " m")}
        />
        <Datum
          label="Execution"
          value={
            run ? `${run.state}${run.stage ? " · " + run.stage : ""}` : "Idle"
          }
        />
      </section>
      {error && (
        <div className="error" role="alert">
          {error}
        </div>
      )}
      {settings && (
        <section className="connections">
          <h2>Vehicle connections</h2>
          {standalone && (
            <p>
              Receive-only TCP/UDP telemetry from MAVLink Router or MAVProxy.
              For UDP, the router must send to the Pi listen port; the hostname
              filters the sender IP. This GCS never opens the GPIO serial port.
            </p>
          )}
          {state?.link_error && <p role="alert">{state.link_error}</p>}
          <div className="connection-fields">
            <label>
              Saved profile
              <select
                value={profile.id}
                onChange={(e) => {
                  const p =
                    state?.profiles.find((p) => p.id === e.target.value) ||
                    newProfile();
                  setProfile(p);
                  setRcText(JSON.stringify(p.rc_config, null, 2));
                }}
              >
                <option value="">New profile</option>
                {state?.profiles.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </label>
            <Field
              label="Profile ID"
              value={profile.id}
              onChange={(v) => setProfile({ ...profile, id: v })}
            />
            <Field
              label="Name"
              value={profile.name}
              onChange={(v) => setProfile({ ...profile, name: v })}
            />
            <label>
              FCU transport
              <select
                value={profile.transport}
                onChange={(e) =>
                  setProfile({
                    ...profile,
                    transport: e.target.value as ConnectionProfile["transport"],
                  })
                }
              >
                <option value="tcp">TCP</option>
                <option value="udp">UDP</option>
                {!standalone && <option value="serial">Local serial</option>}
              </select>
            </label>
            {profile.transport === "serial" ? (
              <>
                <Field
                  label="Serial device"
                  value={profile.device}
                  onChange={(v) => setProfile({ ...profile, device: v })}
                />
                <NumberField
                  label="Baud rate"
                  value={profile.baud}
                  onChange={(v) => setProfile({ ...profile, baud: v })}
                />
              </>
            ) : (
              <>
                <Field
                  label={
                    standalone
                      ? "Router hostname or IP"
                      : "Laptop hostname or IP"
                  }
                  value={profile.host}
                  onChange={(v) => setProfile({ ...profile, host: v })}
                />
                <NumberField
                  label="MAVLink port"
                  value={profile.port}
                  onChange={(v) => setProfile({ ...profile, port: v })}
                />
                {profile.transport === "udp" && (
                  <NumberField
                    label="Pi UDP listen port"
                    value={profile.bind_port}
                    onChange={(v) => setProfile({ ...profile, bind_port: v })}
                  />
                )}
              </>
            )}
            <NumberField
              label="Vehicle system ID"
              value={profile.system_id}
              onChange={(v) => setProfile({ ...profile, system_id: v })}
            />
            <NumberField
              label="Component ID"
              value={profile.component_id}
              onChange={(v) => setProfile({ ...profile, component_id: v })}
            />
            {!standalone && (
              <>
                <Field
                  label="Sensor gateway URL"
                  value={profile.gateway}
                  onChange={(v) => setProfile({ ...profile, gateway: v })}
                />
                <Field
                  label="Camera device"
                  value={profile.camera_device}
                  onChange={(v) => setProfile({ ...profile, camera_device: v })}
                />
                <Field
                  label="Lidar device"
                  value={profile.lidar_port}
                  onChange={(v) => setProfile({ ...profile, lidar_port: v })}
                />
                <NumberField
                  label="Lidar mount yaw, degrees"
                  value={profile.lidar_yaw_deg}
                  onChange={(v) => setProfile({ ...profile, lidar_yaw_deg: v })}
                />
                <label className="check">
                  <input
                    type="checkbox"
                    checked={profile.lidar_mirrored}
                    onChange={(e) =>
                      setProfile({
                        ...profile,
                        lidar_mirrored: e.target.checked,
                      })
                    }
                  />
                  Lidar angles mirrored
                </label>
                <NumberField
                  label="Camera HFOV, radians"
                  value={profile.camera_hfov}
                  onChange={(v) => setProfile({ ...profile, camera_hfov: v })}
                />
                <NumberField
                  label="Target marker edge, metres"
                  value={profile.marker_m}
                  onChange={(v) => setProfile({ ...profile, marker_m: v })}
                />
                <Field
                  label="Venue configuration file on Pi"
                  value={profile.venue_file}
                  onChange={(v) => setProfile({ ...profile, venue_file: v })}
                />
              </>
            )}
          </div>
          {!standalone && (
            <details>
              <summary>Transmitter channel calibration</summary>
              <p>
                Use the aircraft’s channel mappings, endpoints and takeover
                switch.
              </p>
              <textarea
                aria-label="Transmitter calibration JSON"
                value={rcText}
                onChange={(e) => setRcText(e.target.value)}
              />
            </details>
          )}
          <div className="actions">
            <button
              disabled={busy || state?.runtime === "Running"}
              onClick={() =>
                void perform(async () => {
                  await api("profiles", {
                    ...profile,
                    rc_config: JSON.parse(rcText),
                  });
                  log("Profile saved");
                })
              }
            >
              Save profile
            </button>
            <button
              disabled={busy || state?.runtime === "Running"}
              onClick={() =>
                void perform(() => api("connect", { profile_id: profile.id }))
              }
            >
              {standalone ? "Connect telemetry" : "Connect runtime"}
            </button>
            <button
              disabled={busy}
              onClick={() =>
                void perform(async () => {
                  const r = await api<{ items: Capability[] }>("check");
                  setCapabilities(r.items);
                })
              }
            >
              Connection check
            </button>
            <button
              disabled={
                busy || state?.runtime === "Stopped" || !state?.can_disconnect
              }
              onClick={() => void perform(() => api("disconnect", {}))}
            >
              {standalone ? "Disconnect telemetry" : "Disconnect runtime"}
            </button>
          </div>
          {capabilities.length > 0 && (
            <table>
              <thead>
                <tr>
                  <th>Interface</th>
                  <th>State</th>
                  <th>Rate</th>
                  <th>Capture age</th>
                  <th>Detail</th>
                </tr>
              </thead>
              <tbody>
                {capabilities.map((c) => (
                  <tr key={c.key}>
                    <td>{c.key.replace(/_/g, " ")}</td>
                    <td>{c.ok ? "Available" : "Unavailable"}</td>
                    <td>{value(c.hz, " Hz")}</td>
                    <td>{value(c.capture_age_s, " s", 3)}</td>
                    <td>{c.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      )}
      <main>
        <section className="workspace">
          <div
            className="view-tabs"
            role="tablist"
            aria-label="Monitoring view"
          >
            {(["camera", "slam", "map", "graphs"] as const).map((v) => (
              <button
                key={v}
                id={`tab-${v}`}
                aria-controls={`view-${v}`}
                role="tab"
                aria-selected={view === v}
                onClick={() => setView(v)}
              >
                {v === "slam"
                  ? "SLAM"
                  : v === "camera"
                    ? "Camera"
                    : v === "graphs"
                      ? "Graphs"
                      : "Map"}
              </button>
            ))}
          </div>
          <div
            id="view-map"
            role="tabpanel"
            aria-labelledby="tab-map"
            hidden={view !== "map"}
          >
            <div ref={mapHost} className="map-host" />
            {mapError && (
              <p role="status" className="view-note">
                {mapError}
              </p>
            )}
            <p className="view-note">
              {t?.gps && t.gps.fix !== "NO"
                ? `${value(t.gps.lat, "°", 7)}, ${value(t.gps.lon, "°", 7)}`
                : "Waiting for a live GPS position."}
              {pick
                ? " Click the map to add waypoints."
                : " Imagery loads through the Pi and is cached for offline use."}
            </p>
          </div>
          <div
            id="view-camera"
            role="tabpanel"
            aria-labelledby="tab-camera"
            hidden={view !== "camera"}
          >
            <div className="camera-tools">
              <label>
                Displayed feed
                <select
                  value={videoTopic}
                  onChange={(e) => setVideoTopic(e.target.value)}
                >
                  <option value="/percep/overlay">Detections overlay</option>
                  <option value="/image_raw">Raw camera</option>
                  <option value="/percep/qr/annotated">QR detector</option>
                  <option value="/percep/banner/annotated">
                    Banner detector
                  </option>
                  <option value="/percep/redzone/annotated">
                    Red-zone detector
                  </option>
                </select>
              </label>
              <span>Changing the feed leaves camera pointing unchanged.</span>
            </div>
            {fresh ? (
              <img
                className="camera-feed"
                alt="Live aircraft camera"
                src={`/video/stream?topic=${encodeURIComponent(videoTopic)}`}
              />
            ) : (
              <div className="empty-view">Camera unavailable</div>
            )}
          </div>
          <div
            id="view-slam"
            role="tabpanel"
            aria-labelledby="tab-slam"
            hidden={view !== "slam"}
          >
            {grid ? (
              <>
                <Slam grid={grid} />
                <p className="view-note">
                  Frame {grid.frame} · resolution {grid.res} m · capture{" "}
                  {grid.stamp.toFixed(3)} ·{" "}
                  {clock - gridReceived > 3000 ? "Stale" : "Live map"}
                </p>
              </>
            ) : (
              <div className="empty-view">Waiting for a SLAM occupancy map</div>
            )}
          </div>
          {view === "graphs" && (
            <div id="view-graphs" role="tabpanel" aria-labelledby="tab-graphs">
              <Suspense fallback={<p className="view-note">Loading graphs…</p>}>
                <Graphs
                  key={state?.profile_id || "no-profile"}
                  history={history.current}
                  theme={theme}
                  live={fresh}
                />
              </Suspense>
            </div>
          )}
          <details>
            <summary>Flight and mission details</summary>
            <div className="status-strip">
              <Datum label="Ground speed" value={value(t?.flight.gs, " m/s")} />
              <Datum label="Roll" value={value(t?.flight.roll_deg, "°")} />
              <Datum label="Pitch" value={value(t?.flight.pitch_deg, "°")} />
              <Datum label="Heading" value={value(t?.flight.yaw_deg, "°")} />
              <Datum label="Voltage" value={value(t?.power.volt, " V")} />
              <Datum
                label="Front lidar range"
                value={value(t?.nav.front_m, " m")}
              />
              <Datum
                label="Gap bearing"
                value={value(
                  t?.nav.centering_err === undefined
                    ? undefined
                    : (t.nav.centering_err * 180) / Math.PI,
                  "°",
                )}
              />
              <Datum
                label="Commanded forward speed"
                value={value(t?.nav.cmd_vx, " m/s")}
              />
              <Datum
                label="Square on"
                value={
                  t?.percep.square_ok === true
                    ? "Yes"
                    : t?.percep.square_ok === false
                      ? "No"
                      : "Unavailable"
                }
              />
              <Datum
                label="Square angle"
                value={value(t?.percep.square_angle_deg, "°")}
              />
              <Datum
                label="Standoff"
                value={value(t?.percep.square_standoff_m, " m")}
              />
              <Datum
                label="Delivery offset"
                value={value(t?.mission.delivery_offset_m, " m")}
              />
              <Datum
                label="Landing precision"
                value={t?.mission.landing_precision || "Unavailable"}
              />
            </div>
            <p>
              {t?.mission.result || "No mission result"}{" "}
              {t?.mission.result_reason || ""}
            </p>
            <p>
              {Object.entries(t?.checklist || {})
                .map(([k, v]) => `${k}: ${v ? "completed" : "pending"}`)
                .join(" · ")}
            </p>
          </details>
          <section className="observations">
            <h2>Detections</h2>
            <p className="view-note">
              {Object.entries(t?.detector_rates || {})
                .map(
                  ([k, v]) =>
                    `${k}: ${clock / 1000 - v.received > 3 ? "Stale" : value(v.hz, " Hz")}`,
                )
                .join(" · ") || "Detector rates unavailable"}
            </p>
            <div className="observation-line">
              <span>Start QR: {t?.percep.start_qr || "Unavailable"}</span>
              <span>
                Target: {t?.percep.target_match ? "Matched" : "Unconfirmed"}
              </span>
              <span>
                Banner: {t?.percep.banner ? "Detected" : "Unconfirmed"}
              </span>
              <span>Red zone: {t?.percep.redzone_status || "Unknown"}</span>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Kind</th>
                  <th>Payload</th>
                  <th>Status</th>
                  <th>Count</th>
                </tr>
              </thead>
              <tbody>
                {telemetry?.scans?.slice(-8).map((r) => (
                  <tr key={r.key}>
                    <td>{r.kind}</td>
                    <td>{r.payload || r.reason}</td>
                    <td>{r.matched ? "Matched" : r.status}</td>
                    <td>{r.count}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        </section>
        <aside className="task-area">
          <h2>{mode === "flight" ? "Normal mission" : "Test task"}</h2>
          {standalone && (
            <p>
              Standalone GCS: telemetry monitoring only. Mission, test and
              aircraft commands require the production runtime, which is not
              installed.
            </p>
          )}
          {mode === "testing" ? (
            <label>
              Task
              <select
                value={task}
                disabled={active}
                onChange={(e) => {
                  setTask(e.target.value);
                  setReview(false);
                }}
              >
                {state?.tasks.map((x) => (
                  <option key={x.id} value={x.id}>
                    {x.label}
                  </option>
                ))}
              </select>
            </label>
          ) : (
            <p>
              Run the complete production mission, including return and landing.
            </p>
          )}
          {movement && selectedTask !== "mission" && (
            <NumberField
              label="Height above home, metres"
              value={height}
              onChange={setHeight}
            />
          )}
          {selectedTask.startsWith("delivery_") && (
            <Field
              label="Target QR payload"
              value={target}
              onChange={setTarget}
            />
          )}
          {selectedTask === "mechanism" && (
            <label>
              Action
              <select
                value={action}
                onChange={(e) => setAction(e.target.value)}
              >
                {["lower", "release", "stow", "stop"].map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </label>
          )}
          {["avoidance_route", "delivery_gps"].includes(selectedTask) && (
            <>
              <label>
                GPS waypoints, latitude then longitude
                <textarea
                  value={routeText}
                  onChange={(e) => setRouteText(e.target.value)}
                  onBlur={() => {
                    try {
                      setWaypoints(points(routeText));
                    } catch (e) {
                      setError(String(e));
                    }
                  }}
                />
              </label>
              <button
                aria-pressed={pick}
                onClick={() => {
                  setPick(!pick);
                  setView("map");
                }}
              >
                {pick ? "Finish selecting" : "Select on map"}
              </button>
              <button onClick={() => setWaypoints([])}>Clear waypoints</button>
            </>
          )}
          <p className="task-note">
            {standalone
              ? "Use MAVProxy or your flight GCS for aircraft commands."
              : movement
                ? "Start checks readiness, arms and runs. Completion or Stop returns and lands."
                : "Observation and mechanism tasks do not arm the aircraft."}
          </p>
          {selectedTask === "avoidance_manual" && (
            <p>
              Fly with the transmitter. Its configured takeover switch releases
              companion control.
            </p>
          )}
          {review ? (
            <section className="review">
              <h3>Review start</h3>
              <p>
                {state?.tasks.find((x) => x.id === selectedTask)?.label} on{" "}
                {selectedProfile?.name || "selected vehicle"}
              </p>
              {movement && selectedTask !== "mission" && (
                <p>Height {height} m above home</p>
              )}
              {target && <p>Verify QR {target}</p>}
              {waypoints.length > 0 && <p>{waypoints.length} GPS waypoints</p>}
              <button
                disabled={
                  !executionAvailable ||
                  busy ||
                  active ||
                  !fresh ||
                  (movement && !t?.safety.ready)
                }
                onClick={() =>
                  void perform(async () => {
                    await command("start", {
                      task: selectedTask,
                      params: { height, target, action, waypoints },
                    });
                    setReview(false);
                  })
                }
              >
                Start
              </button>
              <button onClick={() => setReview(false)}>Cancel</button>
            </section>
          ) : (
            <button
              disabled={
                !executionAvailable ||
                busy ||
                active ||
                !fresh ||
                (movement && !t?.safety.ready)
              }
              onClick={() => setReview(true)}
            >
              Review start
            </button>
          )}
          <button
            disabled={busy || !active}
            onClick={() => void perform(() => command("stop"))}
          >
            Stop
            {(
              active
                ? state?.tasks.find((x) => x.id === run?.task)?.movement
                : movement
            )
              ? " and return"
              : ""}
          </button>
          {run && (
            <p role="status">
              {run.state}
              {run.reason ? `: ${run.reason}` : ""}
              {run.disarmed ? " · Disarm confirmed" : ""}
            </p>
          )}
          <details open>
            <summary>Readiness</summary>
            {t?.safety.ready_reasons?.map((r, i) => (
              <p key={i}>{r}</p>
            ))}
            {t?.safety.ready_waived?.length ? (
              <p>Waived: {t.safety.ready_waived.join(", ")}</p>
            ) : null}
            {t?.safety.ready_items?.map((i) => (
              <div className="readiness-row" key={i.key}>
                <span>{i.label}</span>
                <span>{i.ok ? "Ready" : i.reason || "Unavailable"}</span>
              </div>
            )) || <p>Readiness unavailable</p>}
          </details>
          <details>
            <summary>Organiser inputs</summary>
            <label>
              Delivery-zone corners, latitude then longitude
              <textarea
                value={zoneText}
                onChange={(e) => setZoneText(e.target.value)}
              />
            </label>
            <button
              disabled={!executionAvailable || active || busy}
              onClick={() =>
                void perform(() =>
                  command("set_delivery_zone", { vertices: points(zoneText) }),
                )
              }
            >
              Apply delivery zone
            </button>
            <label>
              Arena geofence vertices
              <textarea
                value={fenceText}
                onChange={(e) => setFenceText(e.target.value)}
              />
            </label>
            <button
              disabled={!executionAvailable || active || busy}
              onClick={() =>
                void perform(() =>
                  command("set_geofence", { vertices: points(fenceText) }),
                )
              }
            >
              Apply geofence
            </button>
          </details>
          <details>
            <summary>Aircraft controls</summary>
            <p>The transmitter and FCU failsafes retain priority.</p>
            <div className="actions">
              <button
                disabled={!executionAvailable || !fresh || active || busy}
                onClick={() => void perform(() => command("arm"))}
              >
                Arm
              </button>
              <button
                disabled={
                  !executionAvailable ||
                  !fresh ||
                  busy ||
                  (t?.mission.armed === true && t?.safety.on_ground !== true)
                }
                onClick={() => void perform(() => command("disarm"))}
              >
                Disarm
              </button>
              <button
                disabled={!executionAvailable || !fresh || busy}
                onClick={() => void perform(() => command("land"))}
              >
                Land
              </button>
              <button
                disabled={!executionAvailable || !fresh || busy}
                onClick={() => void perform(() => command("abort"))}
              >
                Abort
              </button>
            </div>
          </details>
        </aside>
      </main>
      <footer>
        <details open>
          <summary>Events</summary>
          <div className="event-log" aria-live="polite">
            {events.length
              ? events.map((e, i) => <div key={i}>{e}</div>)
              : "No events yet"}
          </div>
        </details>
        <details>
          <summary>Runtime log</summary>
          <button
            onClick={() =>
              void perform(async () => {
                const r = await fetch("/api/logs");
                setLogs(await r.text());
              })
            }
          >
            Refresh log
          </button>
          <pre>{logs || "Refresh to read the Pi runtime log."}</pre>
        </details>
      </footer>
    </div>
  );
}
function Datum({ label, value }: { label: string; value: string }) {
  return (
    <dl>
      <dt>{label}</dt>
      <dd>{value}</dd>
    </dl>
  );
}
function Field({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label>
      {label}
      <input value={value} onChange={(e) => onChange(e.target.value)} />
    </label>
  );
}
function NumberField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <label>
      {label}
      <input
        type="number"
        step="any"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </label>
  );
}
function Slam({ grid }: { grid: Grid }) {
  const c = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = c.current;
    if (!canvas) return;
    canvas.width = grid.w;
    canvas.height = grid.h;
    const ctx = canvas.getContext("2d")!;
    const data = ctx.createImageData(grid.w, grid.h);
    grid.data.forEach((v, i) => {
      const px =
        ((grid.h - 1 - Math.floor(i / grid.w)) * grid.w + (i % grid.w)) * 4;
      const shade = v < 0 ? 128 : 255 - Math.round(v * 2.55);
      data.data.set([shade, shade, shade, 255], px);
    });
    ctx.putImageData(data, 0, 0);
  }, [grid]);
  return (
    <div className="slam-view">
      <canvas
        ref={c}
        style={{ transform: `rotate(${-grid.yaw}rad)` }}
        aria-label={`SLAM grid in ${grid.frame}, origin ${grid.ox}, ${grid.oy}`}
      />
      <span>
        Origin {grid.ox}, {grid.oy} m · yaw{" "}
        {value((grid.yaw * 180) / Math.PI, "°")}
      </span>
    </div>
  );
}
