export type RunState =
  | "Submitted"
  | "Accepted"
  | "Running"
  | "Completed"
  | "Failed"
  | "Outcome unknown";
export interface ConnectionProfile {
  id: string;
  name: string;
  transport: "tcp" | "udp" | "serial";
  host: string;
  port: number;
  bind_port: number;
  device: string;
  baud: number;
  system_id: number;
  component_id: number;
  gateway: string;
  camera_device: string;
  lidar_port: string;
  lidar_yaw_deg: number;
  lidar_mirrored: boolean;
  venue_file: string;
  camera_hfov: number;
  marker_m: number;
  rc_config: Record<string, unknown>;
}
export interface Execution {
  command_id: string;
  task: string;
  state: RunState;
  reason: string;
  stage?: string;
  control_owner?: string;
  disarmed?: boolean;
}
export interface RuntimeState {
  standalone?: boolean;
  execution_available?: boolean;
  link_error?: string;
  profiles: ConnectionProfile[];
  profile_id: string | null;
  runtime: "Stopped" | "Running";
  fresh: boolean;
  can_disconnect: boolean;
  execution: Execution | null;
  tasks: { id: string; label: string; movement: boolean }[];
}
export interface Capability {
  key: string;
  ok: boolean;
  reason?: string;
  hz?: number;
  receipt_age_s?: number | null;
  capture_age_s?: number | null;
  value?: unknown;
}
export function commandId(): string {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return Array.from(a, (x) => x.toString(16).padStart(2, "0")).join("");
}
export const terminal = (r: Execution | null | undefined) =>
  !r || ["Completed", "Failed", "Outcome unknown"].includes(r.state);
export async function api<T>(path: string, body?: unknown): Promise<T> {
  const r = await fetch(
    "/api/" + path,
    body === undefined
      ? {}
      : {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        },
  );
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || `Request failed ${r.status}`);
  return data as T;
}
export function newProfile(): ConnectionProfile {
  return {
    id: "vehicle",
    name: "Vehicle",
    transport: "tcp",
    host: "",
    port: 5762,
    bind_port: 14555,
    device: "/dev/ttyAMA0",
    baud: 921600,
    system_id: 1,
    component_id: 1,
    gateway: "",
    camera_device: "/dev/video0",
    lidar_port: "/dev/ttyUSB0",
    lidar_yaw_deg: 0,
    lidar_mirrored: false,
    venue_file: "",
    camera_hfov: 0.851721,
    marker_m: 2.2,
    rc_config: {},
  };
}
