# Pi web GCS

The Pi runs the browser host and the production ROS stack. The laptop runs
Gazebo, ArduPilot SITL and the laptop gateway. Flight operations and Testing
select workflows independently of the connected vehicle.

## Build and start the Pi

Use Ubuntu 24.04 with ROS 2 Jazzy and the hardware dependencies described in
`STACK_AND_DEPLOYMENT.md`. Install `python3-aiohttp`. Build the production
packages without `sim_gazebo`; Gazebo is not a Pi dependency.

```bash
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install --base-paths src/aerothon_runtime \
  src/aerothon_mission src/aerothon_perception src/aerothon_avoidance \
  src/aerothon_payload src/aerothon_gcs/gcs_aggregator
cd src/aerothon_gcs/tauri_app
npm ci
npm run build
cd ../../..
bash scripts/run_pi_gcs.sh
```

Open `http://<Pi hostname or IP>:8899`. Browser telemetry and video use the
same origin. No desktop GCS installation is required. To enable the host at
boot, run `sudo bash scripts/install_pi_gcs_service.sh <Pi username>` after
building. The host starts idle. Connect starts device services; Start is a
separate aircraft action.

Set the measured camera HFOV and target-marker edge size in each connection
profile. Remote CameraInfo must agree with the configured optics.

Profiles and the command journal live in `~/.local/state/aerothon`. The
supervisor adopts its existing runtime after a web-service restart rather
than creating another commander. An interrupted command remains Outcome
unknown and is never automatically replayed.

## Start the laptop simulator

Build the laptop simulation dependencies and `aerothon_runtime`. Install
`python3-aiohttp` and `pymavlink` for the gateway interpreter. Set the actual
camera and winch servo channels and winch rate before launching. When the
system interpreter lacks `pymavlink`, create a ROS-compatible environment:

```bash
python3 -m venv --system-site-packages ~/.venvs/aerothon-gateway
~/.venvs/aerothon-gateway/bin/pip install aiohttp pymavlink
export AEROTHON_GATEWAY_PYTHON="$HOME/.venvs/aerothon-gateway/bin/python"
source /opt/ros/jazzy/setup.bash
source install/setup.bash
```

The launcher checks dependencies before starting the gateway. Set the
configured actuator outputs:

```bash
AEROTHON_CAMERA_CHANNEL=<configured channel> \
AEROTHON_WINCH_CHANNEL=<configured channel> \
AEROTHON_WINCH_RATE=<measured metres per second> \
bash scripts/launch_laptop_sim.sh
```

This launcher starts simulator services only. It neither serves the GCS nor
starts a mission controller. It disables the old broad process reaper.
The default gateway endpoints are MAVLink TCP 5762 and sensor HTTP 8090.
Use `AEROTHON_GATEWAY_MAVLINK_PORT` and `AEROTHON_GATEWAY_SENSOR_PORT` to
change them. Allow these TCP connections through the laptop firewall.

In the Pi GCS create a TCP profile using the laptop hostname/IP and gateway
URL `http://<laptop hostname or IP>:8090`. Connect and run Connection check.
Changing the laptop address requires editing this profile while stopped
and disarmed. Changing the Pi address only changes the browser URL.

SITL must support the configured mount and winch. The gateway checks live
FCU parameters, servo outputs and measured Gazebo joint feedback. It expects
Mount1 pitch output function 7 and winch output function 88. Configure the
SITL parameter file accordingly; do not assign these functions to arbitrary
physical aircraft outputs. Missing support blocks the relevant task.

## Production code and tests

The execution node owns a single production `Mav` commander. Full mission
calls the existing `build_root`. Component tasks instantiate the existing
banner alignment, QR centring, payload drop, fence and route components.
Passive QR/SLAM tasks do not arm. Movement tasks use production recovery and
wait for actual FCU disarm before reporting completion. A transmitter
takeover disables companion output without issuing a competing mode command.

Manual avoidance requires explicit transmitter calibration in the saved
profile. Each of `forward`, `left`, `yaw`, `climb` needs `channel`, `min`,
`trim`, `max` and optional `reversed`. `takeover` needs `channel`, `min`,
`max`, `active_above`. Set `max_speed`, `max_yaw_rate`, `max_climb_rate` in
metres per second and radians per second. No channel mapping is guessed.

Camera images use JPEG quality 95 on a separate WebSocket. Lidar, camera
calibration, measured joint states and clock use a separate sensor stream.
The gateway never exports payload truth, course geometry or grading topics.
Capture timestamps survive transport. Clock/session discontinuities fault
the connection; a steady-time watchdog remains active when ROS time pauses.

## HTTP interfaces

`GET /api/state` returns runtime, profiles, task registry and execution.
`POST /api/profiles` validates and saves a stopped/disarmed connection.
`POST /api/connect` starts production device services for `profile_id`.
`POST /api/disconnect` requires live disarm after flight commands. An unused
connection attempt can be cancelled without claiming any aircraft state.
`GET /api/check` returns separately measured capabilities and readiness.
`POST /api/commands` requires `command_id`, `cmd`, and task-specific `args`.
`GET /api/commands/<id>` returns the persisted outcome.
`GET /api/logs` returns the runtime log tail.
`/ws` sends telemetry, execution outcomes, maps and events to browsers.
`/video/stream` proxies the Pi video server.

Duplicate command IDs return the previous result. Reusing an ID with changed
parameters fails. Only one execution owns movement. Browser reconnects do
not replay requests. Cross-origin control requests are rejected.

## Verification boundaries

Keep offline tests, browser checks, local gateway tests, rendered missions
and physical Pi/aircraft verification as separate evidence. This GCS branch
does not qualify the frozen flight candidate. Record source hashes and
connection/calibration settings for every integrated run. Strong-gust and
artificial-delay failures remain unresolved and excluded from flight
qualification.

## Map imagery

The Pi serves `/satellite/<zoom>/<x>/<y>.jpg`. It uses bundled tiles first,
then `~/.local/state/aerothon/map-tiles`, and downloads missing Esri World
Imagery tiles when online. The browser stays on the Pi origin. Browsing a
region downloads its imagery and caches it for later offline access.

Set `AEROTHON_MAP_ONLINE=0` when starting the Pi service to disable provider
requests. For field use, preload imagery with `scripts/cache_map_tiles.py`
for the field coordinates and rebuild the browser assets to bundle those
tiles. Offline access requires cached coverage at the zoom levels in use.
The map starts with a world overview before receiving live vehicle GPS;
missing imagery produces an explicit message, not the React HTML fallback.

For the boot service, persist offline mode with `sudo systemctl edit
aerothon-gcs` and set `Environment=AEROTHON_MAP_ONLINE=0` under `[Service]`.
Restart the web host after updating that setting.

## Telemetry graphs

Open **Graphs** alongside Camera, SLAM and Map in either operating mode.
Flight shows altitude, ground speed and forward command, roll/pitch, heading,
battery voltage and remaining estimate. Navigation shows front lidar range,
gap bearing, banner angle and standoff. Perception shows detector rates,
capture-to-processing time, sensor receipt age and remote gateway rates and
capture ages. Payload shows measured winch travel separately from the
command-integrated estimate.

Select a 30-second, 2-minute or 10-minute window. **Pause view** freezes the
display while collection continues; **Resume live view** returns to current
data. **Export window CSV** downloads every trace in the selected window,
including its units, browser receipt UTC, elapsed steady time, Pi snapshot
time and mission stage. Missing values remain empty cells.

History collects while other monitoring tabs are active. It is limited to
ten minutes and five snapshots per second in this browser. Reloading or
changing vehicle profiles clears it. It is not a complete flight recording.
Graphs load separately from the initial webpage.

Source freshness is checked independently. Missing, non-finite, stale or
paused-clock vehicle measurements leave gaps. Reconnection inserts a gap.
Detector intervals use the ROS capture/processing clock, and freshness uses
the Pi snapshot clock, avoiding comparisons between unsynchronised browser
and Pi clocks. Gateway receipt rate uses steady time; capture age uses vehicle
time. Hardware profiles without gateway metrics show those charts unavailable.

Front range is not aircraft clearance. Measured travel is not physical release
confirmation. Speed magnitude and signed body-forward command are different
quantities and are labelled separately. No clearance qualification threshold
is added to a range graph.

For frontend graph regressions, use Node 24 and run `npm run test:graphs`
in `src/aerothon_gcs/tauri_app`, then `npm run build`.


### Vibration and magnetic diagnostics

The Sensors group shows FCU vibration X/Y/Z in m/s², cumulative clipping
counts for three IMUs, magnetic-field magnitude and axes in µT, and reported
battery current in A. Counter resets insert gaps. The magnetic sensor frame
is retained in the CSV.

**Capture magnetic reference** records the current field strength only with
fresh, connected FCU telemetry explicitly reporting disarmed. It observes
telemetry and sends no aircraft command. Subsequent field-strength change is
signed percent relative to that reference. Changing vehicle profiles or sensor
frames clears the reference. It does not backfill earlier samples.

Compare field strength with battery current when investigating electrical
interference. Motion, nearby magnetic material and sensor changes also affect
the indicator. This is not a CompassMot calibration or a measured motor-only
interference percentage. Missing compass/current sensors remain unavailable.

The aggregator consumes `/mavros/vibration/raw/vibration` and `/mavros/imu/mag`
using sensor-data QoS. MagneticField values arrive in tesla and are converted
to µT. Normal startup requests MAVLink VIBRATION (241) at 2 Hz; existing RAW_IMU
and control-stream rates stay unchanged. `mission_bringup` depends on
`mavros_extras`. If a deployment supplies its own MAVROS plugin denylist, it
must enable the vibration plugin; the normal bare-node launch enables it.

Measurement references: [ArduPilot vibration](https://ardupilot.org/copter/docs/common-measuring-vibration.html)
and [compass interference](https://ardupilot.org/copter/docs/common-compass-setup-advanced.html#compassmot-compensation-for-interference-from-the-power-wires-escs-and-motors).


## Standalone deployment

For a Pi without mission algorithms or ROS, use the receive-only distribution
described in [STANDALONE_GCS.md](STANDALONE_GCS.md). It can monitor router TCP/UDP
telemetry and blocks all execution/aircraft commands. The GPIO UART remains
owned by MAVLink Router or MAVProxy. The deployed Pi service is distinct from
the production ROS service described above.
