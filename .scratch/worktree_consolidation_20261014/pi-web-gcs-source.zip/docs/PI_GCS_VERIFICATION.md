# Pi web GCS implementation and verification

Status: implementation available for review; Pi deployment and rendered acceptance incomplete.

## Source and isolation

- Isolated checkout: `C:/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON`.
- Source manifest SHA-256: `9ce5234e42f59dc1bc23884a2c53a60a12294de2686557223b7d30d859197966` (963 files).
- Manifest: `.scratch/pi-web-gcs/integrated-source.json`.
- Changes relative to V23: `.scratch/pi-web-gcs/changes-from-v23.json` (50 added or changed files, including test fixtures and research/deployment docs).
- Frozen V23 archive SHA-256: `8b4af0bcf992a1b55ea4c55114d8cca1effd4d5e96e3154e0c3fbcaa67bb904c`.
- Neither V23 nor this GCS source is an accepted flight qualification source. No qualification result is transferred to this source.
- Primary checkout, its later flight candidates and qualification evidence remain separate. This work has not edited or stopped that qualification work.

## Implemented paths

The Pi serves the React build, HTTP API, telemetry WebSocket and video proxy on one browser origin. Its host starts idle, maintains connection profiles and a durable command journal, and starts one managed production ROS runtime. Runtime ownership survives web-host restarts. The laptop launcher starts Gazebo/SITL/device services and the gateway without a second mission controller.

The execution registry includes full mission, transmitter-controlled SLAM, QR detection, banner alignment, avoidance with transmitter intent or a GPS route, mechanism-only commands, and payload delivery here or at GPS coordinates. Components reuse production mission behaviours and the existing avoidance controller. Movement completion and Stop invoke production recovery and wait for FCU disarm. Transmitter takeover releases companion control without a competing mode request.

Camera, calibration, scan, joint feedback and clock cross the explicit gateway. Images have a separate connection from lidar/clock and MAVLink. Capture timestamps survive transport. Unsupported measured actuation blocks remote tasks. A mechanism release acknowledgement alone returns Outcome unknown; full delivery retains the existing production camera/FCU confirmation.

The browser has plain light/dark themes, aircraft status that stays visible when scrolling, Camera/SLAM/Map/Graphs tabs, task parameters, reviewed Start, event log and connection settings. SLAM includes its frame, origin and timestamp. Changing displayed video does not actuate the camera.

## Verification evidence

| Check | Result | Evidence |
|---|---|---|
| ROS package build | 13 packages built | `.scratch/pi-web-gcs/build_ros.sh`; command output in task history |
| Focused mission/GCS regressions | 226 passed before final startup/release refinements | `.scratch/pi-web-gcs/focused.sh`; task output |
| First complete offline unit run | 1,630 passed, 3 skipped in 805.74 s | `full-offline-before-launch-fix.log` |
| Final affected runtime tests | 33 passed, including one new release-feedback regression | `final-checks.log` |
| Complete offline suite before map fix | 1,631 passed, 3 skipped in 702.15 s; all gates passed | `full-offline.log` |
| Python/shell syntax after launch fix | Passed | `final_checks.sh`, exit 0 |
| Laptop launch description | Loads with configured upstream ArduPilot overlay | `laptop-launch-arguments.log` |
| Gateway CLI and interpreter preflight | Passed with ROS-compatible environment | `gateway-help.log`, `gateway_preflight.sh` |
| Local transport/DDS tests | Passed | `tests/test_pi_ros_runtime.py` |
| Managed startup with missing FCU/clock | Fresh execution heartbeat; no arming commands; FCU unavailable; readiness blocked | `startup-probe.log`, `startup-telemetry.json`, `startup-probe-runtime.log` |
| Browser controls | Both modes, tabs, profile save and unavailable connection checks verified | `gcs-testing.jpg`, `gcs-connections.jpg` |
| Pi access | Historical SSH endpoint timed out | Task history; deployment issue 02 |
| Pi-to-laptop rendered tests | Not run | Requires reachable Pi |

The network tests use controlled MAVLink packets and actual local ROS transport. They are not SITL flights or Gazebo movement evidence. Startup used an isolated network namespace, ROS domain 64, loopback-only DDS, absent FCU TCP `127.0.0.1:18997`, absent sensor endpoint `127.0.0.1:18996`, managed runtime, no RViz and no SLAM launch. No arming/takeoff command was submitted. The bootstrap `armed: false` telemetry value is not live FCU evidence; actual disarm was not measured.

The three skipped tests lack real QR/banner photographs. `corpus-skips.log` records their exact reasons. They do not count as passes.

## Configuration and rates

- Deployment browser port: 8899; local review preview: 18999.
- Managed aggregator: loopback 8765; video proxy target: loopback 8080.
- Gateway defaults: MAVLink TCP 5762, sensor HTTP 8090, SITL local UDP 14560.
- Profile FCU system/component IDs, IP/hostname, ports, serial devices, measured optics, venue file, lidar mount and RC calibration are configurable.
- Gateway camera/winch channels and full-scale winch rate must be configured from actual SITL outputs. A ROS-compatible gateway Python environment is selectable with `AEROTHON_GATEWAY_PYTHON`.
- Rendered camera/lidar/detector rates: **not measured for this GCS source**. The startup probe intentionally had no sensors. Browser capability rates remain unavailable in that preview. The GCS exposes live QR/banner/red-zone detector rates once capture data exists.
- No actuator rate, camera HFOV, marker size, RC mapping or payload release is certified by the browser preview.

## Recordings, telemetry and unresolved work

Startup telemetry is archived as `startup-telemetry.json`; browser screenshots and runtime logs are kept alongside it. No rendered flight recordings exist for this GCS source. Existing qualification recordings and telemetry remain in the primary checkout with their original source/configuration evidence.

1. **Pi deployment and second-device access:** current reachable Pi hostname/IP and SSH user are still needed. The historical endpoint `192.168.0.4` did not respond. No Pi service was installed.
2. **Native component tests:** run all nine task types through the physical Pi against laptop SITL/Gazebo. Verify actual movement, changing addresses, reconnects, wrong identity, paused clock, stale sensors, dropped links, transmitter takeover and duplicate commands.
3. **Actuator/delivery evidence:** validate configured mount/winch functions, camera movement, physical mechanism response, delivery and actual disarm. Gateway capability fixtures do not substitute for these tests.
4. **Full normal workflow:** run the complete production startup/mission through the same Pi runtime and archive its sensor/detector rates and recording.
5. **Shutdown:** controlled ROS smoke teardown still reports errors in existing nodes. The live-health probe exited with code 1 during teardown despite its successful health observation. A short 20-second probe also interrupted imports and is inconclusive. Those logs are preserved; shutdown is not claimed clean. The new runtime entrypoints handle interrupted spin without repeating shutdown.
6. **Environment/setup failures:** the first complete offline run failed its syntax gate because the laptop launch include had keyword/positional arguments in the wrong order. It was corrected and rechecked. A launch-description check initially lacked the upstream ArduPilot overlay; a standalone corpus check initially lacked the built workspace environment. Logs and the later successful checks distinguish setup errors from passes.
7. **Flight qualification:** rendered standard seeds 20261003/1001 and shipped/rotated/split acceptance, the reduced campaign and its consolidated flight evidence remain separate and incomplete for this GCS source. No thresholds were lowered and no thin obstacles were filtered away.
8. **Deferred cases:** strong-gust and artificial-delay failures remain unresolved and excluded. Their preserved failures are not qualification passes. New campaign count on this GCS source is **0**; there is no original 200-case qualification claim.

Use [PI_WEB_GCS.md](PI_WEB_GCS.md) for deployment and connection instructions and [GCS_DESIGN_RESEARCH.md](GCS_DESIGN_RESEARCH.md) for the primary-source design research. .scratch/pi-web-gcs/contrast.json records text/background contrast ratios from 6.70:1 through 14.85:1. The final browser screenshots include the status strip pinned while scrolling.

The evidence manifest and archive hashes are under `.scratch/pi-web-gcs/`.

## Map loading correction

The missing `/satellite/…jpg` route fell through to the React HTML page,
producing browser image-decoding errors. The map also opened at zoom 16,
latitude/longitude 0 without GPS, outside bundled Canberra imagery.

The Pi now serves bundled or downloaded cached JPEG tiles, fetches missing
imagery through the Pi, checks complete bounded image downloads, and reports
unavailable tiles explicitly. The map opens with a world overview and centres
on the aircraft only after live GPS. Provider attribution is visible.

The current map source passed **42 focused HTTP/runtime/frontend contract
tests**, including four map regressions. The browser frontend build passed and
actual satellite imagery rendered in the browser. Evidence: `map-final-tests.log`,
`map-build.log`, `map-red.log`, `map-chunk-red.log`, `gcs-map-fixed.jpg`.

The earlier 1,631-pass full-suite result belongs to source manifest
`c5cfff0e3f0f875ac08b490898731087b0777d7641548ef24232f1e82280b9fb`,
before this map correction. It is retained as prior evidence. The full offline
suite was not repeated for this map-only correction. Flight algorithms and
qualification evidence were not edited. Pi/native flight gaps remain open.

## Telemetry graphs

The preceding graph source 56147c252797efa98c2066d745699dbf47cbe82168d44e380195395627de7200 adds 22 plain charts in Flight, Navigation, Perception, Payload
and Sensors. Windows cover 30 seconds, 2 minutes and 10 minutes; pause freezes
the view while collection continues. CSV includes all traces, units, source
snapshot time, browser receipt time, steady elapsed time, mission stage and
magnetic sensor frame. Browser history is bounded to ten minutes at five
snapshots/s and resets on profile change or reload.

Missing, stale and non-finite measurements remain unavailable. Source receipt
freshness is independent; paused/stale gateway clock health gaps vehicle data.
Reconnects, heading wrap and clipping counter resets insert gaps. Front lidar
range is not minimum aircraft clearance. Gap bearing is displayed in degrees.
Winch measurement and command-integrated estimate remain distinct.

Sensors adds FCU XYZ vibration in m/s², three cumulative clipping counters,
magnetic magnitude/axes in µT, reported current in A, and signed percent change
from a freshly captured disarmed magnetic reference. Reference capture sends
no aircraft command, requires fresh connected and explicitly disarmed FCU
telemetry, and resets on sensor-frame or profile change. Field change is a
diagnostic indicator, not a CompassMot calibration or proof of motor-only
interference. Missing sensors remain unavailable.

Verification on that preceding graph source:

- 16 frontend history/CSV regressions passed, covering independent source
  ages, paused clocks, reconnects, heading/counter resets, bounded retention,
  units, reference eligibility/frame changes and formula escaping.
- 105 focused Python HTTP/runtime/aggregator/contract tests passed. A typed
  ROS transport test verifies actual Vibration/MagneticField messages on the
  MAVROS topics, including NumPy float32 clipping scalars, µT conversion,
  sensor frame and capture timestamp. This uses isolated local ROS publishers.
- TypeScript and production frontend build passed. ROS packages
  gcs_aggregator and mission_bringup built successfully; Python syntax passed.
- Browser graph groups, window controls, pause/resume, reference capture,
  signed negative deviation plotting, persistent legend selection and CSV
  download were verified. Final sensor CSV contains 145 rows and
  104 measured deviation samples, spanning -10.08% to
  0.59%. Missing values stay empty cells.
- Logs: graph-tests.log, graph-python-tests.log, graph-build.log and
  sensor-ros-build.log. Sensor CSV: graph-sensors-fixture-export.csv.
- Browser screenshots: gcs-sensors-fixture.jpg uses generated UI test data;
  gcs-sensors.jpg shows the actual GCS without a selected aircraft. The
  loopback fixture has no ROS, FCU or control endpoints and was closed after
  verification. Synthetic detector rates are UI evidence only.

The typed ROS test initially rejected NumPy clipping scalars and produced null
counters. Accepting finite numbers.Real values fixed it; the failure is
preserved in sensor-resolved-failure.txt and the rerun passed. Existing Vite
main-bundle and separate chart-bundle size warnings remain (approximately
983 kB and 525 kB before compression).

Prior source/verification archives are preserved with before-graphs- and
before-sensors- prefixes. The full offline suite was not repeated for these
GCS graph changes; older results remain tied to their own source. Pi deployment,
native flight verification and qualification remain incomplete. Strong gusts
and artificial control delay remain unresolved and excluded. No rendered
qualification cases or reduced-campaign cases were run for this GCS source.
Qualification thresholds, obstacle filtering and flight algorithms are unchanged.


## Standalone Pi deployment

Standalone GCS is deployed to pi5 at 192.168.137.131:8899. Debian 13/aarch64,
Python 3.13.5, aiohttp 3.14.4 and pymavlink 2.4.50 run only four backend files,
browser assets and a standalone launcher. No ROS, mission, perception,
avoidance or payload packages were shipped. The enabled system service runs
as pi5 and was verified active; reboot was not performed.

On the current source, 36 focused Python tests and 16 frontend graph tests
passed, along with TypeScript/production build. Tests cover identity mismatch,
missing/stale measurements, wire units, actual TCP/UDP reception without sends,
and backend command/serial-access refusal. The installed Pi MAVLink Router v4
also passed isolated TCP and UDP probes with generated system-245 packets.
Those probes opened no UART and count as transport evidence only.

Browser and API access from the laptop over the intranet were verified.
Profile selection, passive connect and check, waiting-for-FCU status and disabled
execution controls were verified. All 119 deployed input files matched hashes.
The service is listening on passive UDP 14570, expected identity 1/1 by default;
actual vehicle identity remains to be confirmed. It starts disconnected at boot.

The inspected /dev/serial0 points to ttyAMA10, the debug UART with an active
login console. No UART overlay, console, wiring, FCU parameters or persistent
router configuration was changed. Header-UART configuration, FCU baud and
physical telemetry remain unverified. MAVProxy is not installed; the guide
provides separate installation and serial-owner/router-client instructions.

Deployment manifest, bundle, logs, native probe output and screenshot are under
.scratch/pi-web-gcs. standalone-verification.json records exact dependencies,
source/bundle hashes and remaining gaps. The guide is docs/STANDALONE_GCS.md,
also served at /standalone-guide.txt on the Pi. Production deployment and
flight qualification remain incomplete. Earlier suite evidence stays tied to
its recorded source; it is not transferred to this standalone deployment.


## Physical FCU display streams and laptop forwarding

The confirmed Pixhawk TELEM3 connection on /dev/ttyAMA0 at 115200 initially
sent only heartbeats. The separate aerothon-telemetry-streams boot service now
requests nine display-message intervals via a loopback router endpoint14571,
after a matching heartbeat and every20 seconds. All nine requests were accepted.
No arming/mode commands or FCU parameter writes were sent. The web command
endpoint remains blocked and no algorithms or ROS were installed.

An8.08-second physical capture observed ATTITUDE62, RAW_IMU61,
GLOBAL_POSITION_INT31, VFR_HUD31, GPS_RAW_INT14, VIBRATION14,
BATTERY_STATUS14, SYS_STATUS7 and HEARTBEAT8 messages. Flight and sensor
charts were verified with real telemetry. Battery zero/unknown values leave
battery graphs unavailable. Independent attitude freshness is now supported.

Router forwarding to laptop192.168.0.103:14550 is configured. Mission Planner
already owns that port. An isolated temporary port14572 received408 datagrams,
12480 bytes from192.168.0.102 in five seconds, verifying laptop delivery without
stealing Mission Planner's socket. The temporary endpoint was removed. Direct
Mission Planner UI reception has not been verified.

Current local source passed37 focused Python checks and17 frontend checks,
plus production build. A subsequent label correction changed Local altitude to
Reported altitude and updated the CSV assertion; its rerun passed. The fully
assembled latest bundle could not finish transfer/hash checks because the
laptop Wi-Fi disconnected. The deployed functional stream/attitude fixes were
verified before network loss; latest altitude wording and null-battery cleanup
remain pending deployment. Current local source is not claimed fully deployed.
Reboot qualification remains unverified. Evidence: flight-data-verification.json,
pi-stream-request-probe.log, laptop-mavlink-reception.json, pi-flight-data.jpg,
pi-sensor-data.jpg and current graph/standalone test/build logs.
