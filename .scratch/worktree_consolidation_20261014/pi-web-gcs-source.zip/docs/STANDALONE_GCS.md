# Standalone GCS on the Pi

The deployed GCS contains browser assets, the web host, connection contracts and
a receive-only MAVLink adapter. It contains no mission, perception, avoidance,
payload or ROS packages. Python dependencies are aiohttp and pymavlink.
Mission, test, arming, mode, landing and mechanism commands are blocked by the
backend and disabled in the webpage. Adding algorithms later requires deploying
the production runtime and deliberately switching out of standalone mode.

## Open and use

Open `http://192.168.0.102:8899` or `http://pi5.local:8899` on the intranet.
The IP can change; use the Pi's current address. In Connections, select the
saved Router UDP profile, save any edits while disconnected, and click
Connect telemetry. The default listener is UDP 14570 with sender host
127.0.0.1, system ID 1 and component ID 1. Change the identity to your FCU's
actual values. Connection check must show a matching fresh FCU heartbeat.
Waiting for FCU is expected until the router forwards telemetry.

UDP is passive: the router must explicitly send to the selected Pi listen
port. The host field filters the sender IP; the MAVLink port field is unused
for passive UDP. TCP instead connects to the router's host and MAVLink port,
usually 127.0.0.1:5760. The browser/backend sends no aircraft commands or heartbeats. A separate
telemetry-only service requests display message intervals through a local router
endpoint, without ROS, algorithm packages or FCU parameter writes.

Graphs provide Flight and Sensors measurements when the FCU emits the relevant
messages. Vibration uses VIBRATION; compass uses RAW_IMU, converting milligauss
to µT. Power uses SYS_STATUS, attitude uses ATTITUDE, height above home and
ground speed use GLOBAL_POSITION_INT, and GPS fix/satellites use GPS_RAW_INT.
Missing, stale and sentinel measurements stay unavailable. Local X/Y, camera,
SLAM, lidar, detections and payload feedback are unavailable without additional
sensor/runtime services. This adapter does not generate those outputs.

Use Graphs, select a group and time window, hover over traces, toggle legends,
pause the view or export CSV. History remains in the browser for ten minutes.
For the magnetic indicator, capture a reference with a fresh disarmed FCU.
Field change is an investigation aid, not a CompassMot calibration result.
Online map tiles are fetched by the Pi; offline operation needs cached coverage.

## Share the GPIO FCU connection

Only one process opens the serial device. Either MAVLink Router or MAVProxy
owns it, then forwards network telemetry to this GCS and other clients.

```text
FCU TELEM UART -> Pi header UART -> MAVLink Router
                                      | UDP 127.0.0.1:14570 -> web GCS
                                      | TCP 127.0.0.1:5760 -> MAVProxy
                                      | UDP laptop-IP:14550 -> desktop GCS
```

The Pi 5 GPIO14/15 UART is now enabled as `/dev/ttyAMA0` with `uart0-pi5`.
The user confirmed Pixhawk TELEM3 at 115200 baud, TX to RX and RX to TX.
`/dev/serial0 -> ttyAMA10` still refers to the separate debug UART and is not
the flight-controller port. No FCU parameters or serial-console settings were
changed. The overlay is saved for boot, but has not been reboot tested.

For GPIO 14/15, the Pi's installed overlay documentation specifies
`dtoverlay=uart0-pi5` in `/boot/firmware/config.txt`. After deliberately enabling
it and rebooting, verify the resulting `/dev/ttyAMA*` device with `pinctrl get
14 15`, `ls -l /dev/serial* /dev/ttyAMA*`, and `sudo fuser -v /dev/REPLACE_WITH_VERIFIED_UART`.
Do not select a UART occupied by a login console. Keep the existing debug
console separate, or disable its getty and kernel console only if deliberately
repurposing that UART. Header pin 8 is GPIO14 TX to FCU RX; pin 10 is GPIO15 RX
from FCU TX; pin 6 is ground. Confirm compatible 3.3 V UART levels and the FCU
connector pinout. Do not attach the FCU's 5 V supply to a GPIO signal pin.

Use the verified UART device and the existing FCU TELEM baud below. These are
placeholders, not values determined during deployment. The FCU TELEM port must
emit MAVLink at the same baud. Do not run both serial-master examples together.

### MAVLink Router owns serial

```bash
FCU_DEVICE='/dev/REPLACE_WITH_VERIFIED_UART'
FCU_BAUD='REPLACE_WITH_CONFIGURED_FCU_BAUD'
mavlink-routerd -t 5760 -e 127.0.0.1:14570 "$FCU_DEVICE:$FCU_BAUD"
```

Add `-e <laptop-IP>:14550` if a laptop Mission Planner/QGroundControl client
also needs the stream. Its address is independent of the browser's address.
An existing router service can instead add a local UDP endpoint:

```ini
[UdpEndpoint standalone_gcs]
Mode=Normal
Address=127.0.0.1
Port=14570
```

MAVProxy was not installed on the inspected Pi. To add its CLI separately:

```bash
python3 -m venv ~/.venvs/mavproxy
~/.venvs/mavproxy/bin/pip install MAVProxy
source ~/.venvs/mavproxy/bin/activate
```

MAVProxy can connect beside the webpage through the router's TCP server:

```bash
mavproxy.py --master=tcp:127.0.0.1:5760 --streamrate=-1
```

It must not also open the FCU serial device. `--streamrate=-1` leaves existing
stream rates alone; request missing diagnostics explicitly if needed.

### MAVProxy owns serial

```bash
FCU_DEVICE='/dev/REPLACE_WITH_VERIFIED_UART'
FCU_BAUD='REPLACE_WITH_CONFIGURED_FCU_BAUD'
mavproxy.py --master="$FCU_DEVICE" --baudrate="$FCU_BAUD" \
  --streamrate=-1 --out=udp:127.0.0.1:14570
```

If MAVProxy is already running, add `output add 127.0.0.1:14570` in its console.
Use `output list` to inspect outputs. An additional `--out=udp:<laptop-IP>:14550`
can feed a desktop GCS. Keep the webpage's profile at local UDP 14570.

When VIBRATION or RAW_IMU is missing, these optional MAVProxy console commands
request VIBRATION at 2 Hz and RAW_IMU at 10 Hz from system/component 1/1.
Replace those IDs with the actual FCU identity. The webpage never sends these.

```text
module load message
message COMMAND_LONG 1 1 511 0 241 500000 0 0 0 0 0
message COMMAND_LONG 1 1 511 0 27 100000 0 0 0 0 0
```

## Service and files

Deployment lives in `/home/pi5/aerothon-gcs-standalone`; state and saved profiles
live in `/home/pi5/.local/state/aerothon-gcs-standalone`. The system service
`aerothon-gcs-standalone` runs as pi5 and starts at boot. It starts disconnected
and never starts a mission or opens a serial port. Select Router UDP and Connect
telemetry after a restart. `aerothon-mavlink-router` owns /dev/ttyAMA0 at 115200
and also starts at boot. `aerothon-telemetry-streams` requests the display
message intervals every 20 seconds after a matching heartbeat, covering FCU
reconnects without storing FCU parameters. It also starts at boot.

```bash
systemctl status aerothon-gcs-standalone
journalctl -u aerothon-gcs-standalone -n 50 --no-pager
sudo systemctl restart aerothon-gcs-standalone
sudo systemctl stop aerothon-gcs-standalone
```

The service runs independently of MAVLink Router/MAVProxy. Restarting it does
not stop their processes. Verify their forwarding when the page says Waiting
for FCU. A live web service is not proof of an FCU link or flight qualification.


## Current router and telemetry services

The router configuration is `/home/pi5/pixhawk-router.conf`. Its endpoints are:

- Pi GCS: UDP 127.0.0.1:14570.
- Telemetry-rate requester: UDP 127.0.0.1:14571, loopback only.
- This laptop: UDP 192.168.0.103:14550. Mission Planner already owns this port.

The installed router TCP server is disabled, so the saved TCP profile and
MAVProxy TCP example require deliberately enabling a router TCP server first.
For the current setup, use UDP. In Mission Planner choose UDP and port 14550.
In QGroundControl create a UDP communication link listening on 14550. Run one
laptop listener on that port; close Mission Planner before using another client.

If the laptop address changes, update the laptop_gcs endpoint Address in the
router config and run `sudo systemctl restart aerothon-mavlink-router`. The Pi
GCS's 127.0.0.1 endpoint is unaffected by intranet address changes.

The telemetry service sends only MAV_CMD_SET_MESSAGE_INTERVAL, targeting the
confirmed identity1/1. Requested IDs/rates are SYS_STATUS1Hz, GPS_RAW_INT2Hz,
RAW_IMU10Hz, ATTITUDE10Hz, LOCAL_POSITION_NED5Hz, GLOBAL_POSITION_INT5Hz,
VFR_HUD5Hz, BATTERY_STATUS2Hz and VIBRATION2Hz. All nine requests were accepted.
LOCAL_POSITION_NED was not observed during the first capture. Battery voltage
was reported as zero and remaining/current as unknown, so valid battery graphs
remain unavailable. These requests do not arm, change modes or run algorithms.

```bash
systemctl status aerothon-mavlink-router aerothon-telemetry-streams
journalctl -u aerothon-telemetry-streams -n 10 --no-pager
```

The webpage has separate attitude freshness, so missing position data does not
hide a fresh roll/pitch/heading stream. Standalone altitude is FCU relative
altitude above home; it can be negative as the reported reference changes.
