import asyncio
import socket
import sys

import pytest
from aiohttp.test_utils import TestClient, TestServer
from pymavlink.dialects.v20 import ardupilotmega as mav

from aerothon_runtime.contracts import profile
from aerothon_runtime.standalone import Measurements, StandaloneHost
from aerothon_runtime.web import application


def connection(**kwargs):
    return profile(dict(id='monitor', transport='udp', host='127.0.0.1') | kwargs, require_gateway=False)


def message(kind, *args, system=1):
    encoder = mav.MAVLink(None, srcSystem=system, srcComponent=1)
    frame = getattr(mav, 'MAVLink_' + kind + '_message')(*args).pack(encoder)
    return mav.MAVLink(None).parse_char(frame)


def heartbeat(system=1):
    return message('heartbeat', 2, 3, 0, 0, 4, 3, system=system)


def test_identity_and_heartbeat_staleness():
    measurements = Measurements(connection())
    measurements.accept(heartbeat(system=2), now=0)
    assert measurements.snapshot(now=0)['mission']['armed'] is None
    assert not measurements.snapshot(now=0)['devices']['identity']['ok']
    measurements.accept(heartbeat(), now=0)
    assert measurements.snapshot(now=0)['mission']['armed'] is False
    assert measurements.snapshot(now=0)['devices']['identity']['ok']
    assert measurements.snapshot(now=4)['mission']['armed'] is None
    assert not measurements.snapshot(now=4)['safety']['fcu_connected']


def test_real_wire_sensor_units_and_independent_ages():
    measurements = Measurements(connection())
    measurements.accept(message('vibration', 1000000, 3, 4, 5, 1, 2, 3), now=0)
    measurements.accept(message('raw_imu', 1000000, 0, 0, 0, 0, 0, 0, 300, 400, 0), now=0)
    measurements.accept(message('sys_status', 0, 0, 0, 0, 12000, 123, 50, 0, 0, 0, 0, 0, 0), now=0)
    data = measurements.snapshot(now=0)
    assert data['sensor_diagnostics']['vibration_mps2'] == [3, 4, 5]
    assert data['sensor_diagnostics']['clipping'] == [1, 2, 3]
    assert data['sensor_diagnostics']['magnetic_ut'] == [30, 40, 0]
    assert data['sensor_diagnostics']['magnetic_strength_ut'] == 50
    assert data['power']['current_a'] == 1.23
    measurements.accept(heartbeat(), now=4)
    data = measurements.snapshot(now=4)
    assert data['power']['volt'] is None
    assert data['sample_age_s']['magnetic'] == 4
    assert data['sample_age_s']['state'] == 0


def test_missing_attitude_and_gps_never_report_zero():
    data = Measurements(connection()).snapshot(now=0)
    assert data['flight']['roll_deg'] is None
    assert data['gps']['lat'] is None
    assert data['gps']['sats'] is None


def test_no_ros_or_algorithms_imported():
    assert not any(k == 'rclpy' or k.startswith('mission_bt') for k in sys.modules)


def test_http_commands_blocked_even_with_matching_disarmed_fcu(tmp_path):
    async def run():
        host = StandaloneHost(tmp_path, tmp_path / 'state')
        host.measurements = Measurements(connection())
        host.measurements.accept(heartbeat())
        client = TestClient(TestServer(application(host)))
        await client.start_server()
        try:
            state = await (await client.get('/api/state')).json()
            assert state['standalone'] and state['execution_available'] is False
            for cmd in ['arm', 'disarm', 'start', 'stop', 'land', 'set_mode']:
                response = await client.post('/api/commands', json={'command_id': 'unique-id-' + cmd, 'cmd': cmd})
                assert response.status == 400
                assert 'receive-only' in (await response.json())['error']
            response = await client.post('/api/profiles', json={'id': 'gpio', 'transport': 'serial', 'device': '/dev/serial0'})
            assert response.status == 400
            response = await client.post('/api/profiles', json={'id': 'router', 'transport': 'udp', 'host': '127.0.0.1', 'bind_port': 14570})
            assert response.status == 200
        finally:
            await client.close()
    asyncio.run(run())


def test_udp_real_packets_received_without_transmitting(tmp_path):
    async def run():
        host = StandaloneHost(tmp_path, tmp_path / 'state')
        sender = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sender.settimeout(.1)
        sender.bind(('127.0.0.1', 0))
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.bind(('127.0.0.1', 0)); port = probe.getsockname()[1]; probe.close()
        await host.connect_profile(connection(bind_port=port))
        try:
            packet = heartbeat().pack(mav.MAVLink(None, srcSystem=1, srcComponent=1))
            for _ in range(30):
                sender.sendto(packet, ('127.0.0.1', port))
                await asyncio.sleep(.02)
                if host.measurements.snapshot()['safety']['fcu_connected']:
                    break
            assert host.measurements.snapshot()['safety']['fcu_connected']
            with pytest.raises(socket.timeout):
                sender.recvfrom(4096)
        finally:
            await host.disconnect_profile(); sender.close()
        assert host.stopped() and host.telemetry is None
    asyncio.run(run())


def test_tcp_received_without_heartbeat_or_commands_sent(tmp_path):
    async def run():
        received = []
        packet = heartbeat().pack(mav.MAVLink(None, srcSystem=1, srcComponent=1))
        async def router(reader, writer):
            writer.write(packet); await writer.drain()
            try:
                received.append(await asyncio.wait_for(reader.read(1024), .1))
            except asyncio.TimeoutError:
                received.append(b'')
            finally:
                writer.close(); await writer.wait_closed()
        server = await asyncio.start_server(router, '127.0.0.1', 0)
        host = StandaloneHost(tmp_path, tmp_path / 'state')
        await host.connect_profile(connection(transport='tcp', port=server.sockets[0].getsockname()[1]))
        try:
            for _ in range(30):
                await asyncio.sleep(.02)
                if received:
                    break
            assert host.measurements.snapshot()['safety']['fcu_connected']
            assert received == [b'']
        finally:
            await host.disconnect_profile(); server.close(); await server.wait_closed()
    asyncio.run(run())


def test_stream_request_allowlist_cannot_send_aircraft_commands():
    from aerothon_runtime.telemetry_streams import request_packets, STREAMS
    assert set(STREAMS) == {1, 24, 27, 30, 32, 33, 74, 147, 241}
    for message_id, packet in request_packets(1, 1):
        decoded = mav.MAVLink(None).parse_char(packet)
        assert decoded.get_type() == 'COMMAND_LONG'
        assert decoded.command == mav.MAV_CMD_SET_MESSAGE_INTERVAL
        assert decoded.target_system == decoded.target_component == 1
        assert decoded.param1 == message_id
        assert decoded.param2 == 1_000_000 / STREAMS[message_id]
        assert 1 <= STREAMS[message_id] <= 10
