"""Exercise actual HTTP map requests, including missing tiles and offline reuse."""
import io
import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
from PIL import Image
from aerothon_runtime.web import Host, application


def jpeg():
    body=io.BytesIO();Image.new('RGB',(256,256),(80,100,120)).save(body,format='JPEG')
    return body.getvalue()

@pytest.mark.asyncio
async def test_map_cache_miss_returns_an_image_then_works_offline(tmp_path):
    body=jpeg();calls=[]
    async def tile(request):
        calls.append(request.path)
        return web.Response(body=body,content_type='image/jpeg')
    upstream=web.Application();upstream.router.add_get('/tile/{z}/{y}/{x}',tile)
    (tmp_path/'index.html').write_text('<html>GCS</html>')
    async with TestServer(upstream) as provider:
        h=Host(tmp_path,tmp_path/'state',aggregator='http://127.0.0.1:1')
        h.tile_origin=str(provider.make_url('/tile')).rstrip('/')
        async with TestClient(TestServer(application(h))) as client:
            r=await client.get('/satellite/2/3/2.jpg')
            assert r.status==200 and r.content_type=='image/jpeg'
            assert await r.read()==body
            assert calls==['/tile/2/2/3']
            h.map_online=False
            r=await client.get('/satellite/2/3/2.jpg')
            assert r.status==200 and await r.read()==body and len(calls)==1

@pytest.mark.asyncio
async def test_missing_offline_tile_never_returns_the_react_html(tmp_path):
    (tmp_path/'index.html').write_text('<html>GCS</html>')
    h=Host(tmp_path,tmp_path/'state',aggregator='http://127.0.0.1:1');h.map_online=False
    async with TestClient(TestServer(application(h))) as client:
        r=await client.get('/satellite/2/3/2.jpg')
        assert r.status==404 and r.content_type!='text/html'
        r=await client.get('/satellite/2/99/2.jpg')
        assert r.status==400

@pytest.mark.asyncio
async def test_provider_html_error_is_not_cached_as_imagery(tmp_path):
    async def tile(request):return web.Response(text='<html>upstream error</html>',content_type='text/html')
    upstream=web.Application();upstream.router.add_get('/tile/{z}/{y}/{x}',tile)
    async with TestServer(upstream) as provider:
        h=Host(tmp_path,tmp_path/'state',aggregator='http://127.0.0.1:1');h.tile_origin=str(provider.make_url('/tile')).rstrip('/')
        async with TestClient(TestServer(application(h))) as client:
            r=await client.get('/satellite/2/3/2.jpg')
            assert r.status==502 and r.content_type!='text/html'
            assert not (tmp_path/'state/map-tiles/2/3/2.jpg').exists()


@pytest.mark.asyncio
async def test_map_download_waits_for_the_complete_image_across_network_chunks(tmp_path):
    import asyncio
    body=jpeg()
    async def tile(request):
        response=web.StreamResponse(headers={'Content-Type':'image/jpeg'})
        await response.prepare(request)
        await response.write(body[:len(body)//2])
        await asyncio.sleep(.03)
        await response.write(body[len(body)//2:])
        await response.write_eof()
        return response
    upstream=web.Application();upstream.router.add_get('/tile/{z}/{y}/{x}',tile)
    async with TestServer(upstream) as provider:
        h=Host(tmp_path,tmp_path/'state',aggregator='http://127.0.0.1:1');h.tile_origin=str(provider.make_url('/tile')).rstrip('/')
        async with TestClient(TestServer(application(h))) as client:
            r=await client.get('/satellite/2/3/2.jpg')
            assert r.status==200 and await r.read()==body
