#!/bin/bash
set -eo pipefail
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
export PYTHONPATH="$PWD/src/aerothon_runtime"
python -m pytest tests/test_gcs_standalone.py tests/test_pi_runtime.py tests/test_pi_map.py -q | tee .scratch/pi-web-gcs/standalone-tests.log
