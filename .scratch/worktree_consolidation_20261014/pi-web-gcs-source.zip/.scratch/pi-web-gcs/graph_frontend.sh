#!/bin/bash
set -eo pipefail
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON/src/aerothon_gcs/tauri_app
export PATH=/home/sarthak/.nvm/versions/node/v24.18.0/bin:/usr/bin:/bin
npm exec --yes --package=prettier -- prettier --write src/App.tsx src/Graphs.tsx src/telemetryHistory.ts src/types.ts src/gcs.css tests/telemetryHistory.test.mjs
npm run test:graphs | tee ../../../.scratch/pi-web-gcs/graph-tests.log
npm run build | tee ../../../.scratch/pi-web-gcs/graph-build.log
