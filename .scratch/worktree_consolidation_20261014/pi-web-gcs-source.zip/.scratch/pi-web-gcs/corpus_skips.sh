#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
source install/setup.bash
export PYTHONPATH="$PWD/src/aerothon_perception/perception_qr:$PWD/src/aerothon_perception/perception_banner:$PYTHONPATH"
python -m pytest tests/perception/test_real_corpus.py -q -rs
