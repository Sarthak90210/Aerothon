#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
colcon build --symlink-install --executor sequential --base-paths src/aerothon_runtime src/aerothon_mission src/aerothon_perception src/aerothon_avoidance src/aerothon_payload src/aerothon_gcs/gcs_aggregator src/aerothon_sim --event-handlers console_cohesion+
