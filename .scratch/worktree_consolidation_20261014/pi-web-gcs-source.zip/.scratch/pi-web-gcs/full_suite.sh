#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
export PATH=/home/sarthak/.venvs/aerothon-gcs/bin:/home/sarthak/.nvm/versions/node/v24.18.0/bin:/usr/bin:/bin
export ROS_DOMAIN_ID=63 ROS_LOCALHOST_ONLY=1
bash scripts/run_tests.sh > .scratch/pi-web-gcs/full-offline.log 2>&1
