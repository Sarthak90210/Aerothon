#!/bin/bash
set -eo pipefail
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
export PYTHONPATH="$PWD/src/aerothon_runtime"
exec python -m aerothon_runtime.web --static "$PWD/src/aerothon_gcs/tauri_app/dist" --state-dir "$PWD/.scratch/pi-web-gcs/preview-state" --port 18999 --aggregator http://127.0.0.1:18998
