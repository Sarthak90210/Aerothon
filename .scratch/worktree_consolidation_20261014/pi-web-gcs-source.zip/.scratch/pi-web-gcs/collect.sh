#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
export PATH=/home/sarthak/.venvs/aerothon-gcs/bin:/home/sarthak/.nvm/versions/node/v24.18.0/bin:/usr/bin:/bin
export ROS_DOMAIN_ID=63 ROS_LOCALHOST_ONLY=1
export PYTHONPATH="$PWD/src/aerothon_runtime:$PWD/src/aerothon_mission/mission_bt:$PWD/src/aerothon_gcs/gcs_aggregator:$PWD/src/aerothon_perception/camera_ctrl:$PWD/src/aerothon_avoidance/avoidance:$PWD/src/aerothon_payload/winch_ctrl:$PYTHONPATH"
python -m pytest sim/ tests/ --collect-only -q > .scratch/pi-web-gcs/collected.txt
