#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
export ROS_DOMAIN_ID=63 ROS_LOCALHOST_ONLY=1
export PYTHONPATH="$PWD/src/aerothon_runtime:$PWD/src/aerothon_mission/mission_bt:$PWD/src/aerothon_gcs/gcs_aggregator:$PWD/src/aerothon_perception/camera_ctrl:$PWD/src/aerothon_avoidance/avoidance:$PWD/src/aerothon_payload/winch_ctrl:$PYTHONPATH"
python -m pytest tests/test_pi_runtime.py tests/test_pi_ros_runtime.py sim/test_gcs_contract.py sim/test_gcs_aggregator.py sim/test_camera_ctrl.py sim/test_phase0_rails.py sim/test_behavior_tree.py sim/test_gate_braking.py sim/test_gate_capture_pause.py sim/test_corridor_recovery.py sim/test_corridor_yaw_alignment.py -q

