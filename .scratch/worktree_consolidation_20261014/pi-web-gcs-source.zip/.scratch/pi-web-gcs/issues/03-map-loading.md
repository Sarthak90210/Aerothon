# Map loading

Status: ready-for-human

Fixed missing-tile requests returning React HTML and the uncached initial
zoom/location. Added a Pi-side cache-first tile route with online fetch,
complete bounded image reads, attribution and explicit errors. Verified
42 focused tests, frontend build, live JPEG responses and rendered imagery.
Source/evidence records preserve the prior full-suite version separately.
