# Runtime, transport and browser implementation

Status: ready-for-human

Implementation and local verification are complete for review. The full offline suite before the map correction passed 1,631 tests with three missing real-photo corpus
skips. Source hashes, screenshots and logs are recorded in
`docs/PI_GCS_VERIFICATION.md`. Pi deployment and every native component/flight
verification remain pending in issue 02; this is not flight qualification. The map follow-up passed 42 focused checks;
see issue 03 and the updated source/evidence report.
