# Pixhawk GPIO telemetry connection

Status: ready-for-human
Type: task

User confirmed TELEM3, 115200 baud, GPIO14 TX to FCU RX and GPIO15 RX to FCU TX.
Enabled uart0-pi5 live and persistently. /dev/ttyAMA0 mapped to TXD0/RXD0.
MAVLink Router service enabled and running, forwarding to local UDP14570.
Real FCU heartbeat identity1/1 received in GCS: STABILIZE, disarmed.

## Comments

No aircraft commands or FCU parameter changes sent. No reboot required for
live overlay. Persistent configuration has not been reboot tested. Battery,
attitude, GPS and sensor streams not received in observation window.
Evidence: pi-pixhawk-verification.json, pi-real-fcu-status.log,
pi-pixhawk-router-final.log and pi-pixhawk-live.jpg. This establishes telemetry
heartbeat reception only and does not establish flight qualification.
