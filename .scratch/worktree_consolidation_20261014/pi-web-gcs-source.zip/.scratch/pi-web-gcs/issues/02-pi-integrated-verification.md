# Pi deployment and rendered workflow verification

Status: needs-info

Requires the current reachable Pi hostname/IP and SSH username. Historical
SSH configuration was checked and its host timed out. Deploy the built Pi
web/runtime services, connect to laptop SITL/Gazebo, and verify every task,
actuator motion, transmitter takeover, full workflow, delivery and actual
disarm. Preserve all failed runs. Do not substitute local transport checks
for this hardware topology test.
