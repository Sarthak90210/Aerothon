# Standalone Pi GCS deployment

Status: ready-for-human
Type: task

Deployed receive-only GCS and passive TCP/UDP MAVLink adapter on the Pi without
ROS or flight algorithm packages. Boot service enabled/active, laptop intranet
browser and API verified. 36 Python + 16 frontend checks passed; native router
UDP/TCP probes passed using isolated generated packets. Hashes verified.

## Comments

Guide: docs/STANDALONE_GCS.md. Physical FCU/header UART configuration remains
pending confirmed controller, TELEM port, baud and wiring. No UART or FCU
settings were changed. Flight qualification remains separate and incomplete.
