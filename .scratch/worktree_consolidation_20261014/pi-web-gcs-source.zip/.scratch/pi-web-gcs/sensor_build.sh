#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
colcon build --packages-select gcs_aggregator mission_bringup --symlink-install | tee .scratch/pi-web-gcs/sensor-ros-build.log
python3 -m py_compile src/aerothon_gcs/gcs_aggregator/gcs_aggregator/aggregator.py src/aerothon_mission/mission_bringup/mission_bringup/stream_rate_keeper.py scripts/set_stream_rates.py
