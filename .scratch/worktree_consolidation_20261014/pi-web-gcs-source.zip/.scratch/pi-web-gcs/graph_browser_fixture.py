"""Loopback UI fixture only. No ROS, FCU, commands, or qualification evidence."""
import asyncio
import math
import time
from pathlib import Path
from aiohttp import web

root = Path(__file__).resolve().parents[2]
dist = root / 'src/aerothon_gcs/tauri_app/dist'
started = time.monotonic()

async def state(request):
    return web.json_response({'profiles': [{'id': 'fixture', 'name': 'UI fixture, no aircraft'}],
                             'profile_id': 'fixture', 'runtime': 'Stopped', 'fresh': True,
                             'can_disconnect': False, 'execution': None, 'tasks': []})

async def stream(request):
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    try:
        while not ws.closed:
            s = time.monotonic() - started
            phase = s % 30
            if 10 < phase < 14:
                await ws.close()
                break
            now = time.time()
            stale = 5 < phase < 8
            data = {
                'mission': {'selected': None, 'state': 'UI FIXTURE ONLY', 'armed': False, 'mode': 'NO AIRCRAFT'},
                'flight': {'x': 0, 'y': 0, 'alt': 5 + .4*math.sin(s), 'gs': 1+.3*math.cos(s), 'roll_deg': 4*math.sin(s), 'pitch_deg': 3*math.cos(s), 'yaw_deg': (s*15+180)%360-180},
                'gps': {'lat': 0, 'lon': 0, 'sats': None, 'fix': 'NO'},
                'power': {'volt': 12.4, 'pct': 75, 'current_a': 4+2*math.sin(s)},
                'nav': {'front_m': 3+.7*math.sin(s), 'centering_err': .2*math.sin(s), 'cmd_vx': .5+.2*math.cos(s)},
                'percep': {'start_qr': '', 'target_match': False, 'banner': False, 'redzone_visible': False, 'square_angle_deg': 4*math.cos(s), 'square_standoff_m': 2+.2*math.sin(s)},
                'safety': {'ready': False, 'fcu_connected': True}, 'checklist': {}, 'scans': [],
                'sample_age_s': {k: 4 if stale else .1 for k in ['pose','velocity','avoidance','power','square','winch','devices','lidar','state','magnetic','vibration']},
                'sensor_diagnostics': {'vibration_mps2': [8+3*math.sin(s),7+2*math.cos(s),10+3*math.cos(s)], 'clipping': [int(s),int(s/2),0], 'magnetic_ut': [30+2*math.sin(s),40+2*math.sin(s),0], 'magnetic_strength_ut': math.hypot(30+2*math.sin(s),40+2*math.sin(s)), 'magnetic_frame': 'base_link', 'magnetic_capture_stamp': s},
                'detector_rates': {k: {'hz': hz+math.sin(s), 'capture_stamp': s, 'processed_stamp': s+.03, 'received': now-4 if stale else now} for k,hz in [('qr',8),('banner',6),('red',5)]},
                'devices': {'clock': {'ok': not stale}, 'camera': {'ok': True, 'hz': 10, 'receipt_age_s': .1, 'capture_age_s': .04}, 'lidar': {'ok': True, 'hz': 12, 'receipt_age_s': .1, 'capture_age_s': .03}},
                'winch': {'payout_estimate_m': 2+.1*math.sin(s), 'measured_payout_m': 1.95+.1*math.sin(s), 'measurement_age_s': .1, 'release_requested': False},
            }
            await ws.send_json({'v': 1, 'kind': 'telemetry', 't': now, 'data': data})
            await asyncio.sleep(.2)
    except (ConnectionResetError, RuntimeError):
        pass
    return ws

async def index(request):
    return web.FileResponse(dist / 'index.html')

app = web.Application()
app.router.add_get('/api/state', state)
app.router.add_get('/ws', stream)
app.router.add_static('/assets/', dist / 'assets')
app.router.add_get('/', index)
web.run_app(app, host='127.0.0.1', port=18997, handle_signals=True)
