# Pi browser GCS and shared flight runtime

Status: ready-for-agent

Implement the approved Pi-hosted browser GCS and production execution runtime.
Laptop services provide SITL, Gazebo and standard device transport only.
Keep Flight operations and Testing independent of the vehicle connection.
Use the same production mission/perception/avoidance/payload modules.
Provide plain light/dark UI, stable telemetry/view positions, one execution
owner, transmitter priority, configurable profiles and durable command IDs.

This worktree starts from frozen V23, archive
`8b4af0bcf992a1b55ea4c55114d8cca1effd4d5e96e3154e0c3fbcaa67bb904c`.
The original checkout and its live qualification runner remain independent.
V23 is not accepted flight qualification. Strong-gust and artificial-delay
failures remain unresolved and excluded.

Implementation/deployment guide: `docs/PI_WEB_GCS.md`.
Primary-source design research: `docs/GCS_DESIGN_RESEARCH.md`.

Final verification requires offline suite, browser checks, network/device
tests, then an actual Pi-to-laptop rendered workflow. The configured historical
SSH host `192.168.0.4` timed out on 8 October. Current Pi hostname/SSH username
has been requested. No deployment or physical aircraft test is claimed.
