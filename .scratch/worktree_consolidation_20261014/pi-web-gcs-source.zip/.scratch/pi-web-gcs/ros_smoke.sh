#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
export ROS_DOMAIN_ID=63 ROS_LOCALHOST_ONLY=1
export PYTHONPATH="$PWD/src/aerothon_runtime:$PWD/src/aerothon_mission/mission_bt:$PWD/src/aerothon_gcs/gcs_aggregator:$PWD/src/aerothon_perception/camera_ctrl:$PWD/src/aerothon_avoidance/avoidance:$PWD/src/aerothon_payload/winch_ctrl:$PYTHONPATH"
python - <<'PY'
import rclpy
from aerothon_runtime.execution_node import ExecutionNode
rclpy.init()
n = ExecutionNode()
assert n.tree is None and n.run is None and n.mav._sp is None
print('Execution node boots idle with one commander')
n.destroy_node();rclpy.shutdown()
PY
