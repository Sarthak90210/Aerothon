#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
source /home/sarthak/aerothon_stack/install/setup.bash
source install/setup.bash
export ROS_DOMAIN_ID=64 ROS_LOCALHOST_ONLY=1
export PYTHONPATH="$PWD/src/aerothon_runtime:$PWD/src/aerothon_mission/mission_bt:$PWD/src/aerothon_gcs/gcs_aggregator:$PWD/src/aerothon_perception/camera_ctrl:$PWD/src/aerothon_avoidance/avoidance:$PWD/src/aerothon_payload/winch_ctrl:$PWD/src/aerothon_perception/perception_qr:$PWD/src/aerothon_perception/perception_banner:$PYTHONPATH"
python -m pytest tests/test_pi_runtime.py tests/test_pi_ros_runtime.py -q
find src scripts sim -name '*.py' -not -path '*/node_modules/*' -not -path '*/__pycache__/*' -print0 | xargs -0 python -m py_compile
for f in scripts/*.sh; do bash -n "$f"; done
ros2 launch sim_gazebo sim_full.launch.py --show-args > .scratch/pi-web-gcs/laptop-launch-arguments.log
python -m aerothon_runtime.gateway --help > .scratch/pi-web-gcs/gateway-help.log
