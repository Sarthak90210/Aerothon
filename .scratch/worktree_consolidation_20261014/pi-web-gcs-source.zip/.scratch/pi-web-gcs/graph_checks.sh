#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
source install/setup.bash
export ROS_DOMAIN_ID=195 ROS_LOCALHOST_ONLY=1
export PYTHONPATH="$PWD/src/aerothon_runtime:$PWD/src/aerothon_gcs/gcs_aggregator:$PYTHONPATH"
python -m pytest tests/test_pi_map.py tests/test_pi_runtime.py tests/test_pi_ros_runtime.py sim/test_gcs_contract.py sim/test_gcs_aggregator.py sim/test_stream_rate_coverage.py -q | tee .scratch/pi-web-gcs/graph-python-tests.log
