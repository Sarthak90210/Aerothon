#!/bin/bash
set -eo pipefail
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON/src/aerothon_gcs/tauri_app
export PATH=/home/sarthak/.nvm/versions/node/v24.18.0/bin:/usr/bin:/bin
npm exec --yes --package=prettier -- prettier --write src/App.tsx src/runtime.ts src/gcs.css src/types.ts
npm run build
