#!/bin/bash
set -e
source /opt/ros/jazzy/setup.bash
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
source install/setup.bash
bash -n scripts/launch_laptop_sim.sh scripts/run_pi_gcs.sh scripts/install_pi_gcs_service.sh
/home/sarthak/.venvs/aerothon-gcs/bin/python -m aerothon_runtime.gateway --help
