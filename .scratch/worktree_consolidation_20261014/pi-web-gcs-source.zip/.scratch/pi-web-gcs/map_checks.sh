#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/sarthak/.venvs/aerothon-gcs/bin/activate
cd /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON
source install/setup.bash
export ROS_DOMAIN_ID=64 ROS_LOCALHOST_ONLY=1
python -m pytest tests/test_pi_map.py tests/test_pi_runtime.py sim/test_gcs_contract.py -q
