#!/bin/bash
set -eo pipefail
ip link set lo up
source /opt/ros/jazzy/setup.bash
source /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON/install/setup.bash
export ROS_DOMAIN_ID=64 ROS_LOCALHOST_ONLY=1 ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
ros2 launch mission_bringup mission2.launch.py managed:=true use_sim:=true rviz:=false slam:=false remote_gateway:=http://127.0.0.1:18996 fcu_url:=tcp://127.0.0.1:18997 camera_backend:=mavlink winch_backend:=mavlink > /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON/.scratch/pi-web-gcs/startup-probe-runtime.log 2>&1 &
probe_pid=$!
trap 'kill -INT "$probe_pid" 2>/dev/null || true; wait "$probe_pid" || true' EXIT
python3 - <<'PY'
import asyncio,json,time
from pathlib import Path
from aiohttp import ClientSession,ClientTimeout
async def main():
    end=time.monotonic()+50
    async with ClientSession(timeout=ClientTimeout(total=4)) as client:
        while time.monotonic()<end:
            try:
                async with client.ws_connect('http://127.0.0.1:8765',heartbeat=2) as ws:
                    while time.monotonic()<end:
                        m=await asyncio.wait_for(ws.receive(),3)
                        envelope=json.loads(m.data)
                        if envelope.get('kind')=='telemetry' and envelope['data'].get('runtime_health',{}).get('fresh'):
                            d=envelope['data']
                            assert d['mission']['armed'] is False
                            assert not d['safety']['ready']
                            Path('/mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON/.scratch/pi-web-gcs/startup-telemetry.json').write_text(json.dumps(d,indent=2))
                            print('PASS: managed production startup reports fresh execution health, unarmed aircraft and unavailable FCU readiness on steady time')
                            return
            except (OSError,TimeoutError,ValueError):
                await asyncio.sleep(.2)
    raise RuntimeError('managed startup health not observed within 50 seconds')
asyncio.run(main())
PY
