import asyncio, tempfile, socket, subprocess, json
from pathlib import Path
from pymavlink.dialects.v20 import ardupilotmega as mav
from aerothon_runtime.standalone import StandaloneHost
from aerothon_runtime.contracts import profile

def free_port(kind):
    sock=socket.socket(socket.AF_INET,kind);sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();return port

async def main():
    with tempfile.TemporaryDirectory(prefix='aerothon-router-probe-') as temp:
        root=Path(temp);conf=root/'router.conf';conf.write_text('[General]\n')
        ingress=free_port(socket.SOCK_DGRAM);udp_port=free_port(socket.SOCK_DGRAM);tcp_port=free_port(socket.SOCK_STREAM)
        router=subprocess.Popen(['/usr/local/bin/mavlink-routerd','-c',str(conf),'-d',temp,'-t',str(tcp_port),'-e',f'127.0.0.1:{udp_port}',f'127.0.0.1:{ingress}'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        sender=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        outputs=[]
        try:
            await asyncio.sleep(.5)
            assert router.poll() is None, 'test router did not start'
            for transport in ['udp','tcp']:
                host=StandaloneHost(root,root/transport)
                p=profile(dict(id='isolated-probe',transport=transport,host='127.0.0.1',port=tcp_port,bind_port=udp_port,system_id=245,component_id=1),require_gateway=False)
                await host.connect_profile(p)
                encoder=mav.MAVLink(None,srcSystem=245,srcComponent=1)
                frames=[mav.MAVLink_heartbeat_message(2,3,0,0,4,3).pack(encoder),mav.MAVLink_vibration_message(1000000,3,4,5,1,2,3).pack(encoder),mav.MAVLink_raw_imu_message(1000000,0,0,0,0,0,0,300,400,0).pack(encoder)]
                try:
                    for attempt in range(50):
                        for frame in frames:sender.sendto(frame,('127.0.0.1',ingress))
                        await asyncio.sleep(.04)
                        data=host.measurements.snapshot()
                        if data['safety']['fcu_connected'] and data['sensor_diagnostics'].get('magnetic_strength_ut')==50:break
                    assert data['safety']['fcu_connected'],host.link_error
                    assert data['sensor_diagnostics']['vibration_mps2']==[3,4,5]
                    assert data['sensor_diagnostics']['magnetic_strength_ut']==50
                    try:await host.command({'cmd':'arm','command_id':'probe-arm'})
                    except ValueError as exc:assert 'receive-only' in str(exc)
                    else:raise AssertionError('command accepted')
                    outputs.append({'transport':transport,'router_forwarding':'passed','vibration':[3,4,5],'magnetic_ut':50,'commands':'blocked','physical_fcu':False})
                finally:await host.disconnect_profile();host.db.close()
        finally:
            sender.close();router.terminate();router.wait(timeout=5)
        print(json.dumps(outputs,indent=2))
asyncio.run(main())
