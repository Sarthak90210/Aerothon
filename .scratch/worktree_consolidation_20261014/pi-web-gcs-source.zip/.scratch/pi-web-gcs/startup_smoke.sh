#!/bin/bash
set -eo pipefail
ip link set lo up
source /opt/ros/jazzy/setup.bash
source /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON/install/setup.bash
export ROS_DOMAIN_ID=64 ROS_LOCALHOST_ONLY=1 ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
ros2 launch mission_bringup mission2.launch.py managed:=true use_sim:=true rviz:=false slam:=false remote_gateway:=http://127.0.0.1:18996 fcu_url:=tcp://127.0.0.1:18997 camera_backend:=mavlink winch_backend:=mavlink
