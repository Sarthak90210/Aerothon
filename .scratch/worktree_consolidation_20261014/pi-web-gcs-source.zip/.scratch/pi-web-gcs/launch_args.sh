#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON/install/setup.bash
ros2 launch mission_bringup mission2.launch.py --show-args > /mnt/c/Users/sarth/.codex/worktrees/pi-web-gcs/AEROTHON/.scratch/pi-web-gcs/launch-arguments.log
