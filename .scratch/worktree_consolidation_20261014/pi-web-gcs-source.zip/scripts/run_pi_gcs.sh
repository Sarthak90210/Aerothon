#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source /opt/ros/jazzy/setup.bash
source "$ROOT/install/setup.bash"
export ROS_LOCALHOST_ONLY=1 ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
exec ros2 run aerothon_runtime web_host --static "$ROOT/src/aerothon_gcs/tauri_app/dist" \
    --state-dir "${AEROTHON_STATE_DIR:-$HOME/.local/state/aerothon}" \
    --port "${AEROTHON_GCS_PORT:-8899}"
