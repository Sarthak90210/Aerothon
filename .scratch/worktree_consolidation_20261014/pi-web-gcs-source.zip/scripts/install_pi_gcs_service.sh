#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
USER_NAME="${1:-${SUDO_USER:-$USER}}"
if [[ "$EUID" != 0 ]]; then
    echo "Install with sudo bash scripts/install_pi_gcs_service.sh <Pi username>"
    exit 1
fi
id "$USER_NAME" >/dev/null
[[ -f "$ROOT/install/setup.bash" && -f "$ROOT/src/aerothon_gcs/tauri_app/dist/index.html" ]] || {
    echo "Build the ROS workspace and browser GCS first."; exit 1;
}
python3 - "$ROOT" "$USER_NAME" <<'PY'
from pathlib import Path
import sys
root,user=sys.argv[1:]
path=(root+'/scripts/run_pi_gcs.sh').replace('%','%%').replace('"','\\"')
Path('/etc/systemd/system/aerothon-gcs.service').write_text(f'''[Unit]
Description=AeroTHON Pi browser GCS
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User={user}
ExecStart=/bin/bash "{path}"
Restart=on-failure
RestartSec=3
KillMode=process
TimeoutStopSec=10

[Install]
WantedBy=multi-user.target
''')
PY
systemctl daemon-reload
systemctl enable --now aerothon-gcs.service
echo "GCS enabled at http://<Pi hostname or IP>:8899. Boot does not arm or start a mission."
