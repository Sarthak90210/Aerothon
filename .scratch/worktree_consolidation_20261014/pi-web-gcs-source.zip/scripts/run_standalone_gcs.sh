#!/usr/bin/env bash
set -eo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$ROOT/python${PYTHONPATH:+:$PYTHONPATH}"
exec "${AEROTHON_GCS_PYTHON:-$HOME/.venvs/aerothon-gcs-standalone/bin/python}" \
  -m aerothon_runtime.web --standalone --static "$ROOT/web" \
  --state-dir "${AEROTHON_GCS_STATE:-$HOME/.local/state/aerothon-gcs-standalone}" \
  --port "${AEROTHON_GCS_PORT:-8899}"
